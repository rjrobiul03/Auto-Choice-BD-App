# How to Convert Auto Choice BD into an Android APK

An `.apk` binary could not be compiled directly inside the AI sandbox because the Android SDK and Gradle are not installed there. Everything needed to build the APK is included in this project via **Capacitor**.

## Option 1: Cloud Build via GitHub Actions (Recommended for Low-Spec PCs)
1. Push the `auto-choice-bd` folder to a private GitHub repository.
2. In **GitHub Repo → Settings → Secrets and variables → Actions**, add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
3. Go to **Actions → Build Android APK → Run workflow**.
4. Download `auto-choice-bd-debug-apk` from the completed workflow run and install `app-debug.apk` on your Android phone.

## Option 2: Local Build on Windows 10 (with Android Studio)
1. Install **Node.js 18+** and **Android Studio** (with Android SDK & JDK 17).
2. Copy `.env.example` to `.env` and fill in `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
3. Run in Command Prompt / PowerShell inside `auto-choice-bd`:
   ```cmd
   npm install
   npm run build
   npx cap add android
   npx cap sync android
   cd android
   gradlew.bat assembleDebug
   ```
4. Your APK will be generated at:
   `android\app\build\outputs\apk\debug\app-debug.apk`
