# Database Backup, Restore & Recovery Guide

## 1. Automated Backups (Supabase)
- **Important**: Automated daily backups and Point-in-Time Recovery (PITR) are **not** active on Supabase Free tier unless you upgrade to Pro or configure an external scheduled `pg_dump` job.
- Do not assume automatic backups are running until verified in **Supabase Dashboard → Database → Backups**.

## 2. Manual Logical Backup (`pg_dump`)
Run from a trusted machine with PostgreSQL client tools installed:

```bash
pg_dump "$SUPABASE_DB_URL" \
  --no-owner \
  --no-privileges \
  --format=custom \
  --file="auto_choice_bd_$(date +%Y%m%d_%H%M).dump"
```

Store backup files encrypted at rest (never commit `.dump` or `.sql` backups with production data to Git).

## 3. Restore Procedure
1. Create a clean target PostgreSQL/Supabase database.
2. Restore schema & data:
   ```bash
   pg_restore --no-owner --no-privileges --dbname="$TARGET_DB_URL" auto_choice_bd_YYYYMMDD_HHMM.dump
   ```
3. Verify `profiles`, `products`, `customers`, `orders`, `order_items`, `payments`, and `audit_logs` row counts.
4. Re-verify RLS is enabled on all tables (`002_rls_policies.sql`).

## 4. Security Incident Recovery
- If an Admin or SR account is compromised:
  1. Immediately pause or deactivate the account in **SR Team** (or via Supabase Auth → Ban User for an Admin).
  2. Rotate passwords and revoke active sessions.
  3. Inspect **Reports → Audit Logs** for unauthorized price, order, or payment changes.
