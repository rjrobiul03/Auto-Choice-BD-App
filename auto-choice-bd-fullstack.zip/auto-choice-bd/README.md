# Auto Choice BD — Business Management Application

Upgraded full-stack React + TypeScript + Vite + Supabase application preserving the **Auto Choice BD – Neumorphic Electric UI** while enforcing strict business rules:
- **Manual Stock Control Only**: Admin enters and edits `stock_quantity` manually; orders never deduct or modify stock automatically.
- **No Profit/Loss Analytics**: No purchase costs, profit margins, or inventory valuation.
- **Real Authentication & RBAC**: Supabase Auth + PostgreSQL Row Level Security (RLS) + server-side Edge Functions.

---

## 1. Local Installation

Prerequisites: Node.js 18+ and npm 9+.

```bash
cd auto-choice-bd
cp .env.example .env
# Fill VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in .env
npm install
npm run dev
```

---

## 2. Supabase Configuration

1. Create a new project in [Supabase](https://supabase.com).
2. In **SQL Editor**, run the migration files in order:
   1. `supabase/migrations/001_schema.sql`
   2. `supabase/migrations/002_rls_policies.sql`
   3. `supabase/migrations/003_functions_triggers.sql`
3. In **Authentication → Providers → Email**:
   - Enable Email provider.
   - Configure Password Policy (minimum 8 characters recommended).
4. Deploy the three Edge Functions using Supabase CLI:
   ```bash
   supabase login
   supabase link --project-ref <your-project-ref>
   supabase functions deploy admin-create-sr
   supabase functions deploy admin-reset-sr-password
   supabase functions deploy admin-update-sr-status
   ```
   (Supabase automatically injects `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY` into Edge Functions — **never** place `SUPABASE_SERVICE_ROLE_KEY` in `.env` or frontend code.)

---

## 3. Secure First-Admin Creation

Do **not** hardcode Admin passwords in source code. Create your first Admin securely via Supabase Dashboard:

1. Go to **Authentication → Users → Add user → Create new user**.
2. Enter your Admin email and a strong password, and check **Auto Confirm User**.
3. Copy the newly created user's **UUID**.
4. Run this SQL in **SQL Editor** (replacing `<ADMIN_UUID>`, `<ADMIN_NAME>`, and `<ADMIN_EMAIL>`):
   ```sql
   insert into public.profiles (id, full_name, email, role, status)
   values ('<ADMIN_UUID>', '<ADMIN_NAME>', '<ADMIN_EMAIL>', 'admin', 'active');
   ```
5. Sign in via the app's Sign In screen using your Admin email and password.

---

## 4. SR Account Creation & Password Reset

- **Create SR**: Admin opens **SR Team → Create SR Account**. The `admin-create-sr` Edge Function creates the user with a one-time temporary password and sets `must_change_password = true`.
- **Reset SR Password**: Admin opens **SR Team → Reset Password** for a selected SR, confirms, and chooses either:
  - **Temporary Password** (forces the SR to change it on next login), or
  - **Email Reset Link** (sends a recovery link to the SR's verified email).
- **Own Password Change**: Both Admin and SR can change their own password in **Settings → Change Password** (verifies current password first, checks password policy, and logs out other sessions).

---

## 5. Production Build & Deployment

```bash
npm run typecheck
npm run build
```

Deploy the generated `dist/` folder to Vercel, Netlify, or Cloudflare Pages, setting `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in the hosting provider's environment variables.
