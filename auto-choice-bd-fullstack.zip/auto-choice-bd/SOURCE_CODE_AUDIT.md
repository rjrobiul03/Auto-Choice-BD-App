# Source-Code Audit: `Auto Choice BD – Neumorphic Electric UI.html`

## 1. Features Already Implemented and Working (Client-Side)
- Neumorphic Electric UI styling: light `#e7ebf0` palette, outer/inner shadows, floating background circles, rotating conic-gradient electric input borders, gradient-sweep `.main-btn`, splash progress screen, 3D flip auth card, bottom navigation bar, reusable modal, and toast notifications.
- Local-only UI interactions: brand/search filtering on 8 sample products, SR cart add/increment/decrement/remove, client-side order submission into `localStorage`, Admin order status button toggles (`Pending` → `Approved` → `Delivered` / `Cancelled`), `+10` stock increment button, add product/customer modals, and SR pause/activate toggle.

## 2. Features Present Only as UI or Simulated Behavior
- **Authentication & Signup**: `loginForm` accepts any email/password without verification; `signupForm` logs the user in locally without a backend; `selectedLoginRole` and `switchRoleBtn` let any user switch freely between SR and Admin portals.
- **Password Recovery**: `Forgot Password?` opens a modal and displays `"Password reset link sent to your email!"` without sending any email or calling any backend.
- **Cloud Sync**: `runSyncBtn` runs a `setTimeout(..., 1300)` and displays `"All records synced successfully!"` while only reading/writing `localStorage`.

## 3. Features Missing Entirely
- Real authentication provider (Supabase Auth) and trusted server-side RBAC / RLS.
- Password management: own password change with current-password verification, password policy, Admin-initiated SR password reset, and forced temporary-password change.
- Real cloud database persistence across devices.
- Motorcycle Parts Finder (bike brand → model → category, bearing/part number, fitment verification status).
- Product price history, customer-specific pricing, and immutable order unit-price snapshots.
- Full order workflow (`Processing`, `Ready/Shipped`, `Rejected`, rejection/cancellation reasons, status history).
- Customer ledger, payments/dues/collections (Cash/MFS/Bank), partial payments, receipts, and audit-safe payment reversals.
- Printable/PDF invoices with configurable business settings, Bengali/English language toggle, and dark theme.
- Reports & CSV/Excel exports, barcode/QR lookup, WhatsApp sharing, in-app notifications, and audit logs.

## 4. Bugs, Security Issues & Data-Integrity Problems
- **Hardcoded Demo Credentials**: `value="sr@autochoicebd.com"` and `value="123456"` prefilled in HTML; `selectedLoginRole` auto-fills `admin@autochoicebd.com`.
- **Client-Side Role Spoofing**: `state.role` is stored in `localStorage` and toggled by a visible `Switch Role` button (`switchRoleBtn`) with zero backend authorization.
- **Plaintext Local Storage**: All business state is stored unauthenticated in `localStorage` under `autochoicebd_neu_ui_v1`.
- **Predictable Client-Side Order IDs**: `ORD-` + `(2602 + state.orders.length)` collides across devices/users.
- **Hardcoded Order Dates**: New orders hardcode `date: "19 Nov 2026"` instead of server timestamps.
- **Stock Adjustment Limitation**: Admin product UI only has a `+10 Stock` button (`data-restock`) rather than arbitrary manual quantity input.
- **XSS Risk**: User-entered strings (product/customer names) are interpolated directly into `innerHTML` templates without escaping.
