import React, { useEffect, useState } from 'react';
import {
  LayoutDashboard,
  Package,
  ClipboardList,
  Store,
  CreditCard,
  Users,
  BarChart3,
  Settings,
  LogOut,
  Wifi,
  WifiOff,
  Bike,
  Zap,
} from 'lucide-react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SplashScreen } from './components/SplashScreen';
import { AuthScreen } from './components/AuthScreen';
import { ForcePasswordChangeModal } from './components/ChangePasswordPanel';
import { DashboardPage } from './pages/DashboardPage';
import { CatalogAndFinderPage } from './pages/CatalogAndFinderPage';
import { CartLine, OrdersPage } from './pages/OrdersPage';
import { CustomersPage } from './pages/CustomersPage';
import { PaymentsPage } from './pages/PaymentsPage';
import { SrManagementPage } from './pages/SrManagementPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';
import { Lang, t } from './lib/i18n';
import { getOfflineQueue, syncOfflineQueue } from './lib/offlineQueue';
import { Announcement, Product } from './types/database';
import { supabase } from './lib/supabase';

function AppInner() {
  const { session, profile, loading, signOut } = useAuth();
  const [showSplash, setShowSplash] = useState(true);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [cart, setCart] = useState<CartLine[]>([]);
  const [toast, setToast] = useState<string | null>(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [lang, setLang] = useState<Lang>('en');
  const [banner, setBanner] = useState<Announcement | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(null), 2800);
  };

  useEffect(() => {
    if (profile) {
      setTheme(profile.theme || 'light');
      setLang(profile.language || 'en');
      supabase.from('announcements').select('*').eq('is_active', true).order('created_at', { ascending: false }).limit(1).maybeSingle().then(({ data }) => setBanner((data as Announcement) || null));
    }
  }, [profile]);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
    const onOnline = async () => {
      setIsOnline(true);
      if (profile && getOfflineQueue(profile.id).length > 0) {
        const res = await syncOfflineQueue(profile.id);
        if (res.syncedCount > 0) {
          showToast(`Back online: ${res.syncedCount} queued item(s) synced.`);
        }
      }
    };
    const onOffline = () => setIsOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, [profile]);

  if (showSplash) {
    return <SplashScreen onDone={() => setShowSplash(false)} />;
  }

  if (loading) {
    return (
      <div className="center-screen">
        <div className="neu-card">Loading session...</div>
      </div>
    );
  }

  if (!session || !profile) {
    return <AuthScreen />;
  }

  const isAdmin = profile.role === 'admin';
  const cartCount = cart.reduce((s, c) => s + c.quantity, 0);

  const navItems = [
    { id: 'dashboard', label: t(lang, 'dashboard'), icon: <LayoutDashboard size={17} /> },
    { id: 'catalog', label: t(lang, 'catalog'), icon: <Package size={17} /> },
    { id: 'orders', label: t(lang, 'orders'), icon: <ClipboardList size={17} />, badge: cartCount },
    { id: 'customers', label: t(lang, 'customers'), icon: <Store size={17} /> },
    { id: 'payments', label: t(lang, 'payments'), icon: <CreditCard size={17} /> },
    ...(isAdmin ? [{ id: 'srs', label: t(lang, 'srs'), icon: <Users size={17} /> }] : []),
    { id: 'reports', label: t(lang, 'reports'), icon: <BarChart3 size={17} /> },
    { id: 'settings', label: t(lang, 'settings'), icon: <Settings size={17} /> },
  ];

  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.product.id === product.id);
      if (existing) {
        return prev.map((c) => (c.product.id === product.id ? { ...c, quantity: c.quantity + 1 } : c));
      }
      return [...prev, { product, quantity: 1 }];
    });
    showToast(`Added ${product.name} to Order Cart`);
  };

  return (
    <div className="app-shell">
      {toast && (
        <div className="toast">
          <Zap size={15} color="var(--blue)" />
          <span>{toast}</span>
        </div>
      )}

      {profile.must_change_password && <ForcePasswordChangeModal />}

      {!isOnline && (
        <div
          className="neu-inset no-print"
          style={{
            padding: '10px 14px',
            marginBottom: 12,
            fontSize: 12.5,
            color: 'var(--warning)',
            display: 'flex',
            alignItems: 'center',
            gap: 8,
          }}
        >
          <WifiOff size={16} />
          <span>{t(lang, 'offlineBanner')}</span>
        </div>
      )}

      <header className="top-bar no-print">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div
            className="neu-card-sm"
            style={{ width: 46, height: 46, padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--blue)' }}
          >
            <img src="/logo.jpg" alt="Auto Choice BD" style={{ width: "100%", height: "100%", objectFit: "contain", borderRadius: 12 }} />
          </div>
          <div>
            <div style={{ fontSize: 16, fontWeight: 700 }}>{t(lang, 'appName')}</div>
            <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>
              {profile.full_name} • {profile.email}
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
          <span className="status-pill st-blue">
            {isAdmin ? 'ADMIN' : 'SR'}
          </span>
          <span className={`status-pill ${isOnline ? 'st-ok' : 'st-warn'}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            {isOnline ? <Wifi size={12} /> : <WifiOff size={12} />}
            {isOnline ? 'Online' : 'Offline'}
          </span>
          <button type="button" className="neu-btn-sm danger" onClick={signOut}>
            <LogOut size={14} /> {t(lang, 'logout')}
          </button>
        </div>
      </header>

      {banner && (
        <div className="neu-inset no-print" style={{ padding: "10px 14px", marginBottom: 14, fontSize: 12.5, borderLeft: "4px solid var(--blue)" }}>
          <strong>{banner.title}:</strong> {banner.message}
        </div>
      )}
      <main>
        {activeTab === 'dashboard' && <DashboardPage onNavigate={setActiveTab} />}
        {activeTab === 'catalog' && <CatalogAndFinderPage onAddToCart={handleAddToCart} onToast={showToast} />}
        {activeTab === 'orders' && <OrdersPage cart={cart} setCart={setCart} onToast={showToast} />}
        {activeTab === 'customers' && <CustomersPage onToast={showToast} />}
        {activeTab === 'payments' && <PaymentsPage onToast={showToast} />}
        {activeTab === 'srs' && isAdmin && <SrManagementPage onToast={showToast} />}
        {activeTab === 'reports' && <ReportsPage />}
        {activeTab === 'settings' && (
          <SettingsPage theme={theme} setTheme={setTheme} lang={lang} setLang={setLang} onToast={showToast} />
        )}
      </main>

      <nav className="bottom-nav no-print">
        {navItems.map((item) => (
          <button
            key={item.id}
            type="button"
            className={`nav-btn ${activeTab === item.id ? 'active' : ''}`}
            onClick={() => setActiveTab(item.id)}
          >
            {item.icon}
            <span>{item.label}</span>
            {item.badge ? <span className="nav-badge">{item.badge}</span> : null}
          </button>
        ))}
      </nav>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <div className="bg-circle bg1" />
      <div className="bg-circle bg2" />
      <div className="bg-circle bg3" />
      <AppInner />
    </AuthProvider>
  );
}
