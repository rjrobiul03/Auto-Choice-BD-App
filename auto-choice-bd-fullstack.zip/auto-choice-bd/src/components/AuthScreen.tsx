import React, { useState } from 'react';
import { Lock, KeyRound, ArrowLeft, AlertTriangle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { ElectricInput } from './ElectricInput';

export function AuthScreen() {
  const { signIn, authError } = useAuth();
  const [flipped, setFlipped] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [resetEmail, setResetEmail] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [msg, setMsg] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    if (!isSupabaseConfigured) {
      setMsg({ type: 'error', text: 'Supabase environment variables are not configured.' });
      return;
    }
    setSubmitting(true);
    const { error } = await signIn(email, password);
    setSubmitting(false);
    if (error) setMsg({ type: 'error', text: error });
  };

  const handleRecovery = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    setSubmitting(true);
    const { error } = await supabase.auth.resetPasswordForEmail(resetEmail.trim().toLowerCase(), {
      redirectTo: window.location.origin,
    });
    setSubmitting(false);
    if (error) {
      setMsg({ type: 'error', text: error.message });
    } else {
      setMsg({
        type: 'success',
        text: 'If this email is registered, a password recovery link has been sent.',
      });
    }
  };

  return (
    <section className="center-screen">
      <div className="auth-wrapper">
        <div className={`auth-card ${flipped ? 'flipped' : ''}`}>
          {/* Login Panel — Zero demo credentials, zero role selector */}
          <div className="form-panel">
            <div className="logo-circle">
              <Lock size={30} />
            </div>
            <h1 style={{ textAlign: 'center', fontSize: 24, fontWeight: 700, marginBottom: 4 }}>
              Auto Choice BD
            </h1>
            <p style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 12.5, marginBottom: 18 }}>
              Sign in with your individual account
            </p>

            {!isSupabaseConfigured && (
              <div
                className="neu-inset"
                style={{ padding: '10px 12px', marginBottom: 14, fontSize: 12, color: 'var(--warning)', display: 'flex', gap: 8, alignItems: 'center' }}
              >
                <AlertTriangle size={16} />
                <span>Configure VITE_SUPABASE_URL & VITE_SUPABASE_ANON_KEY in .env</span>
              </div>
            )}

            {(msg || authError) && (
              <div
                className="neu-inset"
                style={{
                  padding: '10px 12px',
                  marginBottom: 14,
                  fontSize: 12,
                  color: msg?.type === 'success' ? 'var(--success)' : 'var(--danger)',
                }}
              >
                {msg?.text || authError}
              </div>
            )}

            <form onSubmit={handleLogin}>
              <ElectricInput
                id="login-email"
                type="email"
                label="Email Address"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <ElectricInput
                id="login-password"
                type="password"
                label="Password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />

              <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
                <button
                  type="button"
                  onClick={() => {
                    setMsg(null);
                    setResetEmail(email);
                    setFlipped(true);
                  }}
                  style={{
                    border: 'none',
                    background: 'transparent',
                    color: 'var(--blue)',
                    fontSize: 12.5,
                    fontWeight: 600,
                    cursor: 'pointer',
                  }}
                >
                  Forgot Password?
                </button>
              </div>

              <button type="submit" className="main-btn" disabled={submitting}>
                {submitting ? 'SIGNING IN...' : 'SIGN IN'}
              </button>
            </form>

            <p style={{ textAlign: 'center', fontSize: 11.5, color: 'var(--muted)', marginTop: 18 }}>
              Need an SR account? Contact your Admin.
            </p>
          </div>

          {/* Password Recovery Panel */}
          <div className="form-panel signup-panel">
            <div className="logo-circle">
              <KeyRound size={30} />
            </div>
            <h1 style={{ textAlign: 'center', fontSize: 22, fontWeight: 700, marginBottom: 4 }}>
              Password Recovery
            </h1>
            <p style={{ textAlign: 'center', color: 'var(--muted)', fontSize: 12.5, marginBottom: 18 }}>
              Receive a secure reset link via email
            </p>

            {msg && (
              <div
                className="neu-inset"
                style={{
                  padding: '10px 12px',
                  marginBottom: 14,
                  fontSize: 12,
                  color: msg.type === 'success' ? 'var(--success)' : 'var(--danger)',
                }}
              >
                {msg.text}
              </div>
            )}

            <form onSubmit={handleRecovery}>
              <ElectricInput
                id="recovery-email"
                type="email"
                label="Registered Email"
                autoComplete="email"
                value={resetEmail}
                onChange={(e) => setResetEmail(e.target.value)}
                required
              />
              <button type="submit" className="main-btn" disabled={submitting}>
                {submitting ? 'SENDING...' : 'SEND RESET LINK'}
              </button>
            </form>

            <div style={{ display: 'flex', justifyContent: 'center', marginTop: 18 }}>
              <button
                type="button"
                className="neu-btn-sm"
                onClick={() => {
                  setMsg(null);
                  setFlipped(false);
                }}
              >
                <ArrowLeft size={14} /> Back to Sign In
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
