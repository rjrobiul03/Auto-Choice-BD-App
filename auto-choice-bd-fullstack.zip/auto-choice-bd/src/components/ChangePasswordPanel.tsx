import React, { useState } from 'react';
import { ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { ElectricInput } from './ElectricInput';

export function ChangePasswordPanel({ onSuccess }: { onSuccess?: (msg: string) => void }) {
  const { changeOwnPassword, businessSettings } = useAuth();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [saving, setSaving] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'error' | 'success'; text: string } | null>(null);

  const minLen = businessSettings?.password_min_length || 8;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    setSaving(true);
    const { error } = await changeOwnPassword(currentPassword, newPassword, confirmPassword);
    setSaving(false);

    if (error) {
      setFeedback({ type: 'error', text: error });
    } else {
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
      const okMsg = 'Password updated securely. Other active sessions have been signed out.';
      setFeedback({ type: 'success', text: okMsg });
      onSuccess?.(okMsg);
    }
  };

  return (
    <div className="neu-card">
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
        <ShieldCheck size={20} color="var(--blue)" />
        <h3 style={{ fontSize: 16, fontWeight: 700 }}>Change Password</h3>
      </div>
      <p style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 16 }}>
        Minimum {minLen} characters with uppercase, lowercase, and a number.
      </p>

      {feedback && (
        <div
          className="neu-inset"
          style={{
            padding: '10px 14px',
            marginBottom: 14,
            fontSize: 12.5,
            color: feedback.type === 'success' ? 'var(--success)' : 'var(--danger)',
          }}
        >
          {feedback.text}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <ElectricInput
          id="cp-current"
          type="password"
          label="Current Password"
          autoComplete="current-password"
          value={currentPassword}
          onChange={(e) => setCurrentPassword(e.target.value)}
          required
        />
        <ElectricInput
          id="cp-new"
          type="password"
          label="New Password"
          autoComplete="new-password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
          required
        />
        <ElectricInput
          id="cp-confirm"
          type="password"
          label="Confirm New Password"
          autoComplete="new-password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
        />
        <button type="submit" className="main-btn" disabled={saving}>
          {saving ? 'UPDATING...' : 'UPDATE PASSWORD'}
        </button>
      </form>
    </div>
  );
}

export function ForcePasswordChangeModal() {
  const { completeForcedPasswordChange, signOut, businessSettings } = useAuth();
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const minLen = businessSettings?.password_min_length || 8;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSaving(true);
    const { error: err } = await completeForcedPasswordChange(newPassword, confirmPassword);
    setSaving(false);
    if (err) setError(err);
  };

  return (
    <div className="modal-backdrop">
      <div className="modal-box">
        <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 6 }}>
          Set Your New Password
        </h3>
        <p style={{ fontSize: 12.5, color: 'var(--muted)', marginBottom: 16 }}>
          Your account has a temporary password. You must set a personal password (min {minLen} chars,
          uppercase, lowercase, number) before continuing.
        </p>

        {error && (
          <div className="neu-inset" style={{ padding: '10px 12px', marginBottom: 14, fontSize: 12, color: 'var(--danger)' }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <ElectricInput
            id="force-new-pwd"
            type="password"
            label="New Password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            required
          />
          <ElectricInput
            id="force-confirm-pwd"
            type="password"
            label="Confirm New Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
          <button type="submit" className="main-btn" disabled={saving}>
            {saving ? 'SAVING...' : 'SAVE NEW PASSWORD'}
          </button>
        </form>

        <button type="button" className="neu-btn-sm" style={{ marginTop: 12 }} onClick={signOut}>
          Sign Out
        </button>
      </div>
    </div>
  );
}
