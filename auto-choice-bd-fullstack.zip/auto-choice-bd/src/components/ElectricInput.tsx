import React, { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface ElectricInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  id: string;
  leftIcon?: React.ReactNode;
}

export function ElectricInput({ label, id, type = 'text', leftIcon, className = '', ...rest }: ElectricInputProps) {
  const [showPwd, setShowPwd] = useState(false);
  const isPassword = type === 'password';
  const inputType = isPassword ? (showPwd ? 'text' : 'password') : type;

  return (
    <div className={`input-group ${className}`}>
      <div className="electric-glow" />
      <div className="electric-border" />
      {leftIcon && (
        <span
          style={{
            position: 'absolute',
            left: 15,
            top: 17,
            zIndex: 30,
            color: 'var(--muted)',
            pointerEvents: 'none',
            display: 'flex',
          }}
        >
          {leftIcon}
        </span>
      )}
      <input
        id={id}
        type={inputType}
        placeholder=" "
        className={leftIcon ? 'has-left-icon' : ''}
        {...rest}
      />
      <label htmlFor={id} style={leftIcon ? { left: 42 } : undefined}>
        {label}
      </label>
      {isPassword && (
        <button
          type="button"
          className="password-toggle"
          onClick={() => setShowPwd((v) => !v)}
          aria-label={showPwd ? 'Hide password' : 'Show password'}
        >
          {showPwd ? <EyeOff size={16} /> : <Eye size={16} />}
        </button>
      )}
    </div>
  );
}

interface ElectricSelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  id: string;
  children: React.ReactNode;
}

export function ElectricSelect({ label, id, children, className = '', ...rest }: ElectricSelectProps) {
  return (
    <div className={`input-group ${className}`}>
      <div className="electric-glow" />
      <div className="electric-border" />
      <select id={id} {...rest}>
        {children}
      </select>
      <label htmlFor={id}>{label}</label>
    </div>
  );
}
