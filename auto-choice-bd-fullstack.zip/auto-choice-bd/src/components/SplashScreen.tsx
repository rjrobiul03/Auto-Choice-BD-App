import React, { useEffect, useState } from 'react';
import { ArrowRight } from 'lucide-react';

export function SplashScreen({ onDone }: { onDone: () => void }) {
  const [pct, setPct] = useState(25);

  useEffect(() => {
    const timer = setInterval(() => {
      setPct((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onDone, 260);
          return 100;
        }
        return prev + 25;
      });
    }, 260);
    return () => clearInterval(timer);
  }, [onDone]);

  return (
    <section className="center-screen">
      <div className="splash-card" style={{ animation: 'floating 3.5s ease-in-out infinite' }}>
        <div
          className="splash-logo"
          style={{
            width: 118,
            height: 118,
            padding: 8,
            overflow: 'hidden',
            background: '#ffffff',
          }}
        >
          <img
            src="/logo.jpg"
            alt="Auto Choice BD Logo"
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'contain',
              borderRadius: '50%',
            }}
          />
        </div>
        <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 4 }}>Auto Choice BD</h1>
        <p style={{ fontSize: 12.5, color: 'var(--muted)' }}>Buy And Feel Like A King</p>
        <div className="splash-progress">
          <div className="splash-progress-bar" style={{ width: `${pct}%` }} />
        </div>
        <p style={{ fontSize: 11.5, color: 'var(--blue)', fontWeight: 600 }}>
          {pct < 60 ? 'Connecting Cloud Session...' : 'Loading Neumorphic Electric UI...'}
        </p>
        <button type="button" className="neu-btn-sm" style={{ marginTop: 16 }} onClick={onDone}>
          Continue <ArrowRight size={14} />
        </button>

        <div
          style={{
            marginTop: 24,
            paddingTop: 12,
            borderTop: '1px solid var(--border-subtle)',
            fontSize: 11.5,
            fontWeight: 600,
            color: 'var(--muted)',
            letterSpacing: '0.4px',
          }}
        >
          Powered by <span style={{ color: 'var(--blue)', fontWeight: 700 }}>EwR Robiul</span>
        </div>
      </div>
    </section>
  );
}
