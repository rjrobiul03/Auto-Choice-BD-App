import React, { createContext, useContext, useEffect, useState } from 'react';
import { Session } from '@supabase/supabase-js';
import { supabase, isSupabaseConfigured } from '../lib/supabase';
import { loadLocalCache, saveLocalCache } from '../lib/localCache';
import { BusinessSettings, Profile } from '../types/database';

interface AuthContextValue {
  session: Session | null;
  profile: Profile | null;
  businessSettings: BusinessSettings | null;
  loading: boolean;
  authError: string | null;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  refreshSettings: () => Promise<void>;
  changeOwnPassword: (
    currentPassword: string,
    newPassword: string,
    confirmPassword: string
  ) => Promise<{ error: string | null }>;
  completeForcedPasswordChange: (
    newPassword: string,
    confirmPassword: string
  ) => Promise<{ error: string | null }>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function validatePasswordPolicy(password: string, minLength = 8): string | null {
  if (password.length < minLength) {
    return `Password must be at least ${minLength} characters long.`;
  }
  if (!/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/[0-9]/.test(password)) {
    return 'Password must include uppercase, lowercase, and at least one number.';
  }
  return null;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [businessSettings, setBusinessSettings] = useState<BusinessSettings | null>(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);

  const loadUserContext = async (userId: string) => {
    const [{ data: prof, error: profErr }, { data: settings }] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', userId).single(),
      supabase.from('business_settings').select('*').eq('id', 1).maybeSingle(),
    ]);

    if (profErr || !prof) {
      if (!navigator.onLine) {
        const cachedProf = loadLocalCache<Profile | null>('profile', null);
        const cachedSet = loadLocalCache<BusinessSettings | null>('settings', null);
        if (cachedProf && cachedProf.id === userId && cachedProf.status === 'active') {
          setProfile(cachedProf);
          if (cachedSet) setBusinessSettings(cachedSet);
          return;
        }
      }
      setAuthError('User profile not found. Contact Admin.');
      setProfile(null);
      return;
    }

    if (prof.status !== 'active') {
      setAuthError(
        prof.status === 'paused'
          ? 'Your account is currently paused by Admin.'
          : 'Your account has been deactivated.'
      );
      await supabase.auth.signOut();
      setProfile(null);
      setSession(null);
      return;
    }

    setAuthError(null);
    setProfile(prof as Profile);
    saveLocalCache('profile', prof);
    if (settings) {
      setBusinessSettings(settings as BusinessSettings);
      saveLocalCache('settings', settings);
    }
  };

  useEffect(() => {
    if (!isSupabaseConfigured) {
      setLoading(false);
      return;
    }

    supabase.auth.getSession().then(async ({ data }) => {
      setSession(data.session);
      if (data.session?.user) {
        await loadUserContext(data.session.user.id);
      }
      setLoading(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange(async (_event, newSession) => {
      setSession(newSession);
      if (newSession?.user) {
        await loadUserContext(newSession.user.id);
      } else {
        setProfile(null);
      }
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  const refreshProfile = async () => {
    if (session?.user) await loadUserContext(session.user.id);
  };

  const refreshSettings = async () => {
    const { data } = await supabase.from('business_settings').select('*').eq('id', 1).maybeSingle();
    if (data) setBusinessSettings(data as BusinessSettings);
  };

  const signIn = async (email: string, password: string) => {
    setAuthError(null);
    const { data, error } = await supabase.auth.signInWithPassword({
      email: email.trim().toLowerCase(),
      password,
    });
    if (error) return { error: error.message };
    if (data.user) {
      await loadUserContext(data.user.id);
    }
    return { error: null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfile(null);
    setSession(null);
  };

  const changeOwnPassword = async (
    currentPassword: string,
    newPassword: string,
    confirmPassword: string
  ) => {
    if (!profile) return { error: 'Not authenticated.' };
    if (!currentPassword) return { error: 'Current password is required.' };
    if (newPassword !== confirmPassword) return { error: 'New password and confirmation do not match.' };

    const minLen = businessSettings?.password_min_length || 8;
    const policyErr = validatePasswordPolicy(newPassword, minLen);
    if (policyErr) return { error: policyErr };
    if (currentPassword === newPassword) {
      return { error: 'New password must be different from your current password.' };
    }

    // 1. Verify current password through Supabase Auth
    const { error: verifyErr } = await supabase.auth.signInWithPassword({
      email: profile.email,
      password: currentPassword,
    });
    if (verifyErr) {
      return { error: 'Current password is incorrect.' };
    }

    // 2. Update password via Supabase Auth
    const { error: updateErr } = await supabase.auth.updateUser({ password: newPassword });
    if (updateErr) return { error: updateErr.message };

    // 3. Clear must_change_password flag & record audit metadata (never store password!)
    await supabase.from('profiles').update({ must_change_password: false }).eq('id', profile.id);
    await supabase.from('audit_logs').insert({
      actor_id: profile.id,
      actor_role: profile.role,
      action: 'own_password_changed',
      entity_type: 'profile',
      entity_id: profile.id,
      details: { self_service: true },
    });

    // 4. Revoke other sessions where supported
    try {
      await supabase.auth.signOut({ scope: 'others' });
    } catch {
      // Ignore if single-session environment
    }

    await refreshProfile();
    return { error: null };
  };

  const completeForcedPasswordChange = async (newPassword: string, confirmPassword: string) => {
    if (!profile) return { error: 'Not authenticated.' };
    if (newPassword !== confirmPassword) return { error: 'Passwords do not match.' };

    const minLen = businessSettings?.password_min_length || 8;
    const policyErr = validatePasswordPolicy(newPassword, minLen);
    if (policyErr) return { error: policyErr };

    const { error: updateErr } = await supabase.auth.updateUser({ password: newPassword });
    if (updateErr) return { error: updateErr.message };

    await supabase.from('profiles').update({ must_change_password: false }).eq('id', profile.id);
    await supabase.from('audit_logs').insert({
      actor_id: profile.id,
      actor_role: profile.role,
      action: 'forced_temp_password_updated',
      entity_type: 'profile',
      entity_id: profile.id,
      details: { completed_at: new Date().toISOString() },
    });

    await refreshProfile();
    return { error: null };
  };

  return (
    <AuthContext.Provider
      value={{
        session,
        profile,
        businessSettings,
        loading,
        authError,
        signIn,
        signOut,
        refreshProfile,
        refreshSettings,
        changeOwnPassword,
        completeForcedPasswordChange,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
