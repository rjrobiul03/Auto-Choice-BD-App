import { Order, BusinessSettings } from '../types/database';
import { formatBDT } from './i18n';

export function exportToCSV(filename: string, headers: string[], rows: (string | number)[][]) {
  const escape = (val: string | number) => {
    const s = String(val ?? '');
    if (s.includes(',') || s.includes('"') || s.includes('\n')) {
      return `"${s.replace(/"/g, '""')}"`;
    }
    return s;
  };
  const csv = [headers.map(escape).join(','), ...rows.map((r) => r.map(escape).join(','))].join('\n');
  // UTF-8 BOM ensures Excel renders Bengali characters properly
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export function exportToExcelTable(filename: string, headers: string[], rows: (string | number)[][]) {
  const html = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
      <head><meta charset="UTF-8" /></head>
      <body>
        <table border="1">
          <thead><tr>${headers.map((h) => `<th>${h}</th>`).join('')}</tr></thead>
          <tbody>${rows.map((r) => `<tr>${r.map((c) => `<td>${c ?? ''}</td>`).join('')}</tr>`).join('')}</tbody>
        </table>
      </body>
    </html>`;
  const blob = new Blob(['\uFEFF' + html], { type: 'application/vnd.ms-excel;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.xls') ? filename : `${filename}.xls`;
  a.click();
  URL.revokeObjectURL(url);
}

export function buildOrderWhatsAppText(order: Order, settings?: BusinessSettings | null): string {
  const due = Math.max(0, Number(order.grand_total) - Number(order.paid_amount));
  const lines = [
    `*${settings?.business_name || 'Auto Choice BD'}*`,
    `Order: ${order.order_number}`,
    `Customer: ${order.customers?.shop_name || 'N/A'}`,
    `Status: ${order.status.replace('_', ' ').toUpperCase()}`,
    `Grand Total: ${formatBDT(order.grand_total)}`,
    `Paid: ${formatBDT(order.paid_amount)}`,
    `Outstanding Due: ${formatBDT(due)}`,
  ];
  return lines.join('\n');
}

export function shareViaWhatsApp(phone: string | null | undefined, text: string) {
  const cleanPhone = (phone || '').replace(/[^0-9]/g, '');
  const formattedPhone = cleanPhone.startsWith('0') ? '88' + cleanPhone : cleanPhone;
  const base = formattedPhone ? `https://wa.me/${formattedPhone}` : 'https://wa.me/';
  window.open(`${base}?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer');
}
