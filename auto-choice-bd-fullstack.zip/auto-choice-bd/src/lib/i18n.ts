export type Lang = 'en' | 'bn';

const dict = {
  en: {
    appName: 'Auto Choice BD',
    tagline: 'Buy And Feel Like A King',
    loginTitle: 'Sign In',
    loginSubtitle: 'Sign in with your assigned account',
    email: 'Email Address',
    password: 'Password',
    signIn: 'SIGN IN',
    forgotPassword: 'Forgot Password?',
    logout: 'Logout',
    dashboard: 'Dashboard',
    catalog: 'Catalog',
    partsFinder: 'Parts Finder',
    cart: 'Order Cart',
    orders: 'Orders',
    customers: 'Customers',
    payments: 'Payments',
    srs: 'SR Team',
    reports: 'Reports',
    settings: 'Settings',
    changePassword: 'Change Password',
    currentPassword: 'Current Password',
    newPassword: 'New Password',
    confirmPassword: 'Confirm New Password',
    updatePassword: 'UPDATE PASSWORD',
    manualStockNote: 'Manual Stock (Admin Managed)',
    offlineBanner: 'Offline Mode — Changes queued locally (not yet synced to cloud)',
    onlineSynced: 'Cloud Synced',
    noResults: 'No matching records found.',
    verifiedFitment: 'Verified Fitment',
    unverifiedFitment: 'Unverified Fitment',
  },
  bn: {
    appName: 'অটো চয়েস বিডি',
    tagline: 'Buy And Feel Like A King',
    loginTitle: 'লগইন করুন',
    loginSubtitle: 'আপনার নির্ধারিত একাউন্ট দিয়ে প্রবেশ করুন',
    email: 'ইমেইল ঠিকানা',
    password: 'পাসওয়ার্ড',
    signIn: 'লগইন',
    forgotPassword: 'পাসওয়ার্ড ভুলে গেছেন?',
    logout: 'লগআউট',
    dashboard: 'ড্যাশবোর্ড',
    catalog: 'ক্যাটালগ',
    partsFinder: 'পার্টস ফাইন্ডার',
    cart: 'অর্ডার কার্ট',
    orders: 'অর্ডারসমূহ',
    customers: 'কাস্টমার',
    payments: 'পেমেন্ট ও বকেয়া',
    srs: 'এসআর টিম',
    reports: 'রিপোর্ট',
    settings: 'সেটিংস',
    changePassword: 'পাসওয়ার্ড পরিবর্তন',
    currentPassword: 'বর্তমান পাসওয়ার্ড',
    newPassword: 'নতুন পাসওয়ার্ড',
    confirmPassword: 'নতুন পাসওয়ার্ড নিশ্চিত করুন',
    updatePassword: 'পাসওয়ার্ড আপডেট করুন',
    manualStockNote: 'ম্যানুয়াল স্টক (অ্যাডমিন নিয়ন্ত্রিত)',
    offlineBanner: 'অফলাইন মোড — পরিবর্তনগুলো লোকালি সংরক্ষিত আছে (ক্লাউডে সিঙ্ক হয়নি)',
    onlineSynced: 'ক্লাউড সিঙ্কড',
    noResults: 'কোনো তথ্য পাওয়া যায়নি।',
    verifiedFitment: 'যাচাইকৃত ফিটমেন্ট',
    unverifiedFitment: 'অযাচাইকৃত ফিটমেন্ট',
  },
} as const;

export type TranslationKey = keyof typeof dict.en;

export function t(lang: Lang, key: TranslationKey): string {
  return dict[lang]?.[key] ?? dict.en[key];
}

export function formatBDT(amount: number): string {
  return '৳' + Number(amount || 0).toLocaleString('en-US', { maximumFractionDigits: 2 });
}
