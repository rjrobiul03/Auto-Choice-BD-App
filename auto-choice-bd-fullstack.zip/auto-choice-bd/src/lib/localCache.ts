export function saveLocalCache<T>(key: string, data: T): void {
  try {
    localStorage.setItem(`acbd_cache_${key}`, JSON.stringify(data));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadLocalCache<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(`acbd_cache_${key}`);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
