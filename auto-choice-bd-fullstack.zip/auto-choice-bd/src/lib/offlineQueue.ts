import { supabase } from './supabase';

export interface QueuedMutation {
  id: string;
  userId: string;
  type: 'submit_order' | 'record_payment' | 'shop_visit';
  payload: Record<string, unknown>;
  idempotencyKey: string;
  createdAt: string;
  status: 'queued' | 'conflict' | 'failed';
  errorMessage?: string;
}

function getStorageKey(userId: string) {
  return `acbd_offline_queue_${userId}`;
}

export function getOfflineQueue(userId: string): QueuedMutation[] {
  try {
    const raw = localStorage.getItem(getStorageKey(userId));
    return raw ? (JSON.parse(raw) as QueuedMutation[]) : [];
  } catch {
    return [];
  }
}

export function enqueueOfflineMutation(
  userId: string,
  type: QueuedMutation['type'],
  payload: Record<string, unknown>,
  idempotencyKey: string
): QueuedMutation {
  const queue = getOfflineQueue(userId);
  const item: QueuedMutation = {
    id: crypto.randomUUID(),
    userId,
    type,
    payload,
    idempotencyKey,
    createdAt: new Date().toISOString(),
    status: 'queued',
  };
  queue.push(item);
  localStorage.setItem(getStorageKey(userId), JSON.stringify(queue));
  return item;
}

export async function syncOfflineQueue(userId: string): Promise<{
  syncedCount: number;
  failedCount: number;
}> {
  if (!navigator.onLine) return { syncedCount: 0, failedCount: 0 };

  const queue = getOfflineQueue(userId);
  if (queue.length === 0) return { syncedCount: 0, failedCount: 0 };

  let syncedCount = 0;
  let failedCount = 0;
  const remaining: QueuedMutation[] = [];

  for (const item of queue) {
    try {
      if (item.type === 'submit_order') {
        const { error } = await supabase.rpc('submit_order_secure', {
          p_customer_id: item.payload.customer_id,
          p_items: item.payload.items,
          p_discount_amount: item.payload.discount_amount || 0,
          p_delivery_charge: item.payload.delivery_charge || 0,
          p_notes: item.payload.notes || '',
          p_idempotency_key: item.idempotencyKey,
        });
        if (error) throw error;
      } else if (item.type === 'record_payment') {
        const { error } = await supabase.from('payments').insert({
          ...item.payload,
          idempotency_key: item.idempotencyKey,
        });
        if (error && !error.message.includes('duplicate')) throw error;
      } else if (item.type === 'shop_visit') {
        const { error } = await supabase.from('shop_visits').insert(item.payload);
        if (error) throw error;
      }
      syncedCount++;
    } catch (err) {
      failedCount++;
      remaining.push({
        ...item,
        status: 'failed',
        errorMessage: err instanceof Error ? err.message : 'Sync failed',
      });
    }
  }

  localStorage.setItem(getStorageKey(userId), JSON.stringify(remaining));
  return { syncedCount, failedCount };
}
