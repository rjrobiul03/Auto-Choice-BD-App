import { useEffect } from 'react';
import { supabase, isSupabaseConfigured } from '../lib/supabase';

export function useRealtimeSync(
  tables: string[],
  onRemoteChange: () => void,
  enabled = true
) {
  useEffect(() => {
    if (!enabled || !isSupabaseConfigured || tables.length === 0) return;

    const channel = supabase.channel(`acbd-sync-${tables.join('-')}`);
    tables.forEach((table) => {
      channel.on(
        'postgres_changes',
        { event: '*', schema: 'public', table },
        () => onRemoteChange()
      );
    });

    channel.subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [enabled, tables.join(',')]);
}
