import React, { useEffect, useState } from 'react';
import { Search, Plus, QrCode, History, CheckCircle2, AlertTriangle, Printer, Edit3, Save, Table, Upload, Image as ImageIcon, Maximize2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { loadLocalCache, saveLocalCache } from '../lib/localCache';
import { useAuth } from '../context/AuthContext';
import { formatBDT } from '../lib/i18n';
import { Category, PositionApplication, Product } from '../types/database';
import { ElectricInput, ElectricSelect } from '../components/ElectricInput';

interface CatalogProps {
  onAddToCart: (product: Product) => void;
  onToast: (msg: string) => void;
}

const POSITIONS: PositionApplication[] = [
  'Front', 'Rear', 'Engine', 'Clutch', 'Gearbox', 'Electrical', 'Body', 'Other',
];

const MOTO_BRANDS = ['Honda', 'Yamaha', 'Bajaj', 'TVS', 'Hero', 'Suzuki', 'China', 'Universal'];

export function CatalogAndFinderPage({ onAddToCart, onToast }: CatalogProps) {
  const { profile } = useAuth();
  const isAdmin = profile?.role === 'admin';
  const canViewStock = isAdmin || (profile?.can_view_stock ?? true);

  const [subTab, setSubTab] = useState<'catalog' | 'finder' | 'scanner' | 'bulk'>('catalog');
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  const [searchQ, setSearchQ] = useState('');
  const [brandFilter, setBrandFilter] = useState('ALL');
  const [catFilter, setCatFilter] = useState('ALL');
  const [posFilter, setPosFilter] = useState('ALL');
  const [stockFilter, setStockFilter] = useState<'ALL' | 'IN_STOCK' | 'LOW' | 'OUT'>('ALL');
  const [sortBy, setSortBy] = useState<'name' | 'price_asc' | 'price_desc' | 'stock_asc'>('name');
  const [page, setPage] = useState(1);
  const pageSize = 12;

  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [priceHistoryModal, setPriceHistoryModal] = useState<{ product: Product; rows: Array<{ id: string; old_price: number; new_price: number; changed_at: string; reason: string | null }> } | null>(null);
  const [scanCode, setScanCode] = useState('');
  const [scanResult, setScanResult] = useState<Product | null>(null);

  // Bulk Grid Edits: productId -> partial fields
  const [bulkEdits, setBulkEdits] = useState<Record<string, { selling_price: number; dealer_price: string; workshop_price: string; stock_quantity: number }>>({});
  const [savingBulk, setSavingBulk] = useState(false);
  const [showBulkAdd, setShowBulkAdd] = useState(false);
  const [bulkRawText, setBulkRawText] = useState('');
  const [importingBulk, setImportingBulk] = useState(false);
  const [uploadingImg, setUploadingImg] = useState(false);
  const [lightboxProduct, setLightboxProduct] = useState<Product | null>(null);

  const loadData = async () => {
    setLoading(true);
    const [pRes, cRes] = await Promise.all([
      supabase.from('products').select('*').order('name'),
      supabase.from('categories').select('*').eq('is_active', true).order('sort_order'),
    ]);
    const prods = pRes.data ? (pRes.data as Product[]) : loadLocalCache<Product[]>('products', []);
    const cats = cRes.data ? (cRes.data as Category[]) : loadLocalCache<Category[]>('categories', []);
    if (pRes.data) saveLocalCache('products', pRes.data);
    if (cRes.data) saveLocalCache('categories', cRes.data);
    setProducts(prods);
    setCategories(cats);
    setBulkEdits({});
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const filtered = products
    .filter((p) => {
      if (!isAdmin && !p.is_active) return false;
      const q = searchQ.trim().toLowerCase();
      const matchQ =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        (p.barcode_qr || '').toLowerCase().includes(q) ||
        (p.compatible_brand || '').toLowerCase().includes(q) ||
        (p.compatible_model || '').toLowerCase().includes(q) ||
        p.position_application.toLowerCase().includes(q);
      const matchBrand =
        brandFilter === 'ALL' ||
        (p.compatible_brand || '').toLowerCase().includes(brandFilter.toLowerCase()) ||
        p.brand.toLowerCase() === brandFilter.toLowerCase();
      const matchCat = catFilter === 'ALL' || p.category_id === catFilter;
      const matchPos = posFilter === 'ALL' || p.position_application === posFilter;
      const matchStock =
        stockFilter === 'ALL' ||
        (stockFilter === 'IN_STOCK' && p.stock_quantity > 0) ||
        (stockFilter === 'LOW' && p.stock_quantity > 0 && p.stock_quantity <= 8) ||
        (stockFilter === 'OUT' && p.stock_quantity === 0);
      return matchQ && matchBrand && matchCat && matchPos && matchStock;
    })
    .sort((a, b) => {
      if (sortBy === 'price_asc') return a.selling_price - b.selling_price;
      if (sortBy === 'price_desc') return b.selling_price - a.selling_price;
      if (sortBy === 'stock_asc') return a.stock_quantity - b.stock_quantity;
      return a.name.localeCompare(b.name);
    });

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  const handleProductImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !editingProduct) return;
    setUploadingImg(true);
    const ext = file.name.split('.').pop() || 'jpg';
    const path = `products/${Date.now()}-${Math.random().toString(36).slice(2, 7)}.${ext}`;
    const { error } = await supabase.storage.from('product-images').upload(path, file, { upsert: true });
    if (error) {
      setUploadingImg(false);
      onToast('Image upload failed: ' + error.message);
      return;
    }
    const { data: pub } = supabase.storage.from('product-images').getPublicUrl(path);
    setEditingProduct({ ...editingProduct, image_url: pub.publicUrl });
    setUploadingImg(false);
    onToast('Product image uploaded!');
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct || !isAdmin) return;

    const payload = {
      name: editingProduct.name?.trim(),
      sku: editingProduct.sku?.trim(),
      barcode_qr: editingProduct.barcode_qr?.trim() || null,
      brand: editingProduct.brand?.trim() || 'Generic',
      category_id: editingProduct.category_id || null,
      compatible_brand: editingProduct.compatible_brand?.trim() || null,
      compatible_model: editingProduct.compatible_model?.trim() || null,
      model_year_range: editingProduct.model_year_range?.trim() || null,
      position_application: editingProduct.position_application || 'Other',
      selling_price: Number(editingProduct.selling_price || 0),
      dealer_price: editingProduct.dealer_price != null && editingProduct.dealer_price !== ('' as unknown as number) ? Number(editingProduct.dealer_price) : null,
      workshop_price: editingProduct.workshop_price != null && editingProduct.workshop_price !== ('' as unknown as number) ? Number(editingProduct.workshop_price) : null,
      stock_quantity: Math.max(0, Math.floor(Number(editingProduct.stock_quantity || 0))),
      description: editingProduct.description || '',
      image_url: editingProduct.image_url?.trim() || null,
      fitment_verified: Boolean(editingProduct.fitment_verified),
      is_active: editingProduct.is_active ?? true,
      updated_by: profile?.id,
    };

    const { error } = editingProduct.id
      ? await supabase.from('products').update(payload).eq('id', editingProduct.id)
      : await supabase.from('products').insert(payload);

    if (error) {
      onToast(error.message);
      return;
    }
    setEditingProduct(null);
    await loadData();
    onToast('Product saved (manual stock updated).');
  };

  const handleSaveBulkGrid = async () => {
    const ids = Object.keys(bulkEdits);
    if (ids.length === 0) return;
    setSavingBulk(true);
    let updatedCount = 0;
    for (const id of ids) {
      const row = bulkEdits[id];
      const { error } = await supabase
        .from('products')
        .update({
          selling_price: Math.max(0, Number(row.selling_price)),
          dealer_price: row.dealer_price !== '' ? Math.max(0, Number(row.dealer_price)) : null,
          workshop_price: row.workshop_price !== '' ? Math.max(0, Number(row.workshop_price)) : null,
          stock_quantity: Math.max(0, Math.floor(Number(row.stock_quantity))),
          updated_by: profile?.id,
        })
        .eq('id', id);
      if (!error) updatedCount++;
    }
    setSavingBulk(false);
    await loadData();
    onToast(`Bulk saved ${updatedCount} product(s).`);
  };

  const downloadBulkTemplate = () => {
    const csv = [
      'name,sku,brand,compatible_brand,compatible_model,position_application,selling_price,dealer_price,workshop_price,stock_quantity,barcode_qr',
      'SKF 6202 Wheel Bearing,AC-BRG-6202,SKF,Hero,Splendor+,Rear,210,185,195,120,',
      'Motul 3000 4T 20W40 1L,AC-OIL-3000,Motul,Universal,All 4T Bikes,Engine,620,580,600,85,',
    ].join('
');
    const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'auto_choice_bd_products_template.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const parseBulkRows = (raw: string) => {
    const lines = raw.split(/
?
/).map((l) => l.trim()).filter(Boolean);
    if (lines.length === 0) return [];
    const startIdx = lines[0].toLowerCase().includes('sku') && lines[0].toLowerCase().includes('name') ? 1 : 0;
    const validPos = new Set(['Front', 'Rear', 'Engine', 'Clutch', 'Gearbox', 'Electrical', 'Body', 'Other']);
    return lines.slice(startIdx).map((line) => {
      const sep = line.includes('	') ? '	' : ',';
      const cols = line.split(sep).map((c) => c.trim().replace(/^"|"$/g, ''));
      const pos = validPos.has(cols[5]) ? (cols[5] as PositionApplication) : 'Other';
      return {
        name: cols[0] || '',
        sku: cols[1] || '',
        brand: cols[2] || 'Generic',
        compatible_brand: cols[3] || null,
        compatible_model: cols[4] || null,
        position_application: pos,
        selling_price: Math.max(0, Number(cols[6] || 0)),
        dealer_price: cols[7] ? Math.max(0, Number(cols[7])) : null,
        workshop_price: cols[8] ? Math.max(0, Number(cols[8])) : null,
        stock_quantity: Math.max(0, Math.floor(Number(cols[9] || 0))),
        barcode_qr: cols[10] || null,
        is_active: true,
        updated_by: profile?.id,
      };
    }).filter((r) => r.name && r.sku);
  };

  const handleBulkFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setBulkRawText(String(reader.result || ''));
    reader.readAsText(file);
  };

  const handleBulkImportSubmit = async () => {
    if (!isAdmin) return;
    const rows = parseBulkRows(bulkRawText);
    if (rows.length === 0) {
      onToast('No valid rows found (each row needs at least Name and SKU).');
      return;
    }
    setImportingBulk(true);
    let inserted = 0;
    for (let i = 0; i < rows.length; i += 100) {
      const chunk = rows.slice(i, i + 100);
      const { error } = await supabase.from('products').upsert(chunk, { onConflict: 'sku' });
      if (error) {
        setImportingBulk(false);
        onToast(error.message);
        return;
      }
      inserted += chunk.length;
    }
    setImportingBulk(false);
    setShowBulkAdd(false);
    setBulkRawText('');
    await loadData();
    onToast(`Imported / updated ${inserted} product(s) successfully!`);
  };

  const openPriceHistory = async (product: Product) => {
    const { data } = await supabase
      .from('price_history')
      .select('id, old_price, new_price, changed_at, reason')
      .eq('product_id', product.id)
      .order('changed_at', { ascending: false })
      .limit(20);
    setPriceHistoryModal({ product, rows: data || [] });
  };

  const handleBarcodeLookup = (code: string) => {
    const c = code.trim().toLowerCase();
    const found = products.find(
      (p) => (p.barcode_qr || '').toLowerCase() === c || p.sku.toLowerCase() === c
    );
    setScanResult(found || null);
    if (!found) onToast('No product found for code: ' + code);
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, flexWrap: 'wrap', gap: 10 }}>
        <div className="chip-row" style={{ marginBottom: 0 }}>
          <button type="button" className={`chip ${subTab === 'catalog' ? 'active' : ''}`} onClick={() => setSubTab('catalog')}>
            Product Catalog
          </button>
          <button type="button" className={`chip ${subTab === 'finder' ? 'active' : ''}`} onClick={() => setSubTab('finder')}>
            Parts Finder
          </button>
          <button type="button" className={`chip ${subTab === 'scanner' ? 'active' : ''}`} onClick={() => setSubTab('scanner')}>
            <QrCode size={13} style={{ marginRight: 4, verticalAlign: 'middle' }} /> Barcode / QR
          </button>
          {isAdmin && (
            <button type="button" className={`chip ${subTab === 'bulk' ? 'active' : ''}`} onClick={() => setSubTab('bulk')}>
              <Table size={13} style={{ marginRight: 4, verticalAlign: 'middle' }} /> Bulk Price & Stock Grid
            </button>
          )}
        </div>

        {isAdmin && (
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button type="button" className="neu-btn-sm" onClick={() => setShowBulkAdd(true)}>
              <Upload size={14} /> Bulk Add (CSV)
            </button>
          <button
            type="button"
            className="neu-btn-sm primary"
            onClick={() =>
              setEditingProduct({
                name: '',
                sku: '',
                brand: 'Honda',
                position_application: 'Other',
                selling_price: 0,
                stock_quantity: 0,
                fitment_verified: false,
                is_active: true,
              })
            }
          >
            <Plus size={14} /> Add Product
          </button>
          </div>
        )}
      </div>

      {/* Bulk Grid Editor (Admin) */}
      {subTab === 'bulk' && isAdmin && (
        <div className="neu-card" style={{ overflowX: 'auto' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, flexWrap: 'wrap', gap: 10 }}>
            <div>
              <h3 style={{ fontSize: 16, fontWeight: 700 }}>Fast Bulk Price & Manual Stock Editor</h3>
              <p style={{ fontSize: 12, color: 'var(--muted)' }}>
                Edit prices or manual stock directly in the grid, then click Save Modified Rows.
              </p>
            </div>
            <button
              type="button"
              className="neu-btn-sm primary"
              disabled={Object.keys(bulkEdits).length === 0 || savingBulk}
              onClick={handleSaveBulkGrid}
            >
              <Save size={14} /> {savingBulk ? 'Saving...' : `Save Modified (${Object.keys(bulkEdits).length})`}
            </button>
          </div>
          <table className="data-table">
            <thead>
              <tr>
                <th>SKU</th>
                <th>Product</th>
                <th>Retail (৳)</th>
                <th>Dealer (৳)</th>
                <th>Workshop (৳)</th>
                <th>Manual Stock</th>
              </tr>
            </thead>
            <tbody>
              {products.slice(0, 60).map((p) => {
                const edit = bulkEdits[p.id] || {
                  selling_price: p.selling_price,
                  dealer_price: p.dealer_price != null ? String(p.dealer_price) : '',
                  workshop_price: p.workshop_price != null ? String(p.workshop_price) : '',
                  stock_quantity: p.stock_quantity,
                };
                const setField = (patch: Partial<typeof edit>) =>
                  setBulkEdits((prev) => ({ ...prev, [p.id]: { ...edit, ...patch } }));
                return (
                  <tr key={p.id}>
                    <td>{p.sku}</td>
                    <td>{p.name}</td>
                    <td>
                      <input
                        type="number"
                        value={edit.selling_price}
                        onChange={(e) => setField({ selling_price: Number(e.target.value) })}
                        style={{ width: 90, padding: '6px 8px', borderRadius: 10, border: '1px solid var(--border-subtle)', background: 'var(--bg)', color: 'var(--text)' }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        placeholder="-"
                        value={edit.dealer_price}
                        onChange={(e) => setField({ dealer_price: e.target.value })}
                        style={{ width: 90, padding: '6px 8px', borderRadius: 10, border: '1px solid var(--border-subtle)', background: 'var(--bg)', color: 'var(--text)' }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        placeholder="-"
                        value={edit.workshop_price}
                        onChange={(e) => setField({ workshop_price: e.target.value })}
                        style={{ width: 90, padding: '6px 8px', borderRadius: 10, border: '1px solid var(--border-subtle)', background: 'var(--bg)', color: 'var(--text)' }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        value={edit.stock_quantity}
                        onChange={(e) => setField({ stock_quantity: Number(e.target.value) })}
                        style={{ width: 80, padding: '6px 8px', borderRadius: 10, border: '1px solid var(--border-subtle)', background: 'var(--bg)', color: 'var(--text)' }}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {subTab === 'scanner' && (
        <div className="neu-card" style={{ maxWidth: 540, marginBottom: 18 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 8 }}>Barcode / QR Lookup</h3>
          <p style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 14 }}>
            Enter a product SKU or Barcode/QR value manually to look up price and manual stock.
          </p>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <div style={{ flex: 1 }}>
              <ElectricInput
                id="scan-input"
                label="Scan or Type SKU / Barcode"
                value={scanCode}
                onChange={(e) => setScanCode(e.target.value)}
              />
            </div>
            <button
              type="button"
              className="neu-btn-sm primary"
              style={{ height: 48, marginBottom: 16 }}
              onClick={() => handleBarcodeLookup(scanCode)}
            >
              Find
            </button>
          </div>

          {scanResult && (
            <div className="neu-inset" style={{ padding: 14 }}>
              <div style={{ fontWeight: 700, fontSize: 15 }}>{scanResult.name}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)', margin: '4px 0' }}>
                SKU: {scanResult.sku} • {scanResult.compatible_brand || scanResult.brand} {scanResult.compatible_model || ''}
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 }}>
                <span style={{ fontWeight: 800, fontSize: 17, color: 'var(--blue)' }}>
                  {formatBDT(scanResult.selling_price)}
                </span>
                {canViewStock && (
                  <span className={`status-pill ${scanResult.stock_quantity > 0 ? 'st-ok' : 'st-bad'}`}>
                    Manual Stock: {scanResult.stock_quantity}
                  </span>
                )}
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                <button type="button" className="neu-btn-sm primary" onClick={() => onAddToCart(scanResult)}>
                  Add to Order Cart
                </button>
                <button type="button" className="neu-btn-sm" onClick={() => window.print()}>
                  <Printer size={13} /> Print Label
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {(subTab === 'catalog' || subTab === 'finder') && (
        <>
          <div className="neu-card" style={{ marginBottom: 16 }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 10 }}>
              <ElectricInput
                id="prod-search"
                label={subTab === 'finder' ? 'Bearing / Part No / Bike Model...' : 'Search name, SKU, cross-fitment...'}
                leftIcon={<Search size={15} />}
                value={searchQ}
                onChange={(e) => {
                  setSearchQ(e.target.value);
                  setPage(1);
                }}
              />
              <ElectricSelect id="brand-sel" label="Motorcycle Brand" value={brandFilter} onChange={(e) => { setBrandFilter(e.target.value); setPage(1); }}>
                <option value="ALL">All Brands</option>
                {MOTO_BRANDS.map((b) => <option key={b} value={b}>{b}</option>)}
              </ElectricSelect>
              <ElectricSelect id="pos-sel" label="Position / Application" value={posFilter} onChange={(e) => { setPosFilter(e.target.value); setPage(1); }}>
                <option value="ALL">All Positions</option>
                {POSITIONS.map((pos) => <option key={pos} value={pos}>{pos}</option>)}
              </ElectricSelect>
              <ElectricSelect id="cat-sel" label="Category" value={catFilter} onChange={(e) => { setCatFilter(e.target.value); setPage(1); }}>
                <option value="ALL">All Categories</option>
                {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </ElectricSelect>
              <ElectricSelect id="stock-sel" label="Manual Stock Filter" value={stockFilter} onChange={(e) => setStockFilter(e.target.value as typeof stockFilter)}>
                <option value="ALL">All Stock Levels</option>
                <option value="IN_STOCK">Available (&gt; 0)</option>
                <option value="LOW">Low (&le; 8)</option>
                <option value="OUT">Zero / Unavailable</option>
              </ElectricSelect>
              <ElectricSelect id="sort-sel" label="Sort By" value={sortBy} onChange={(e) => setSortBy(e.target.value as typeof sortBy)}>
                <option value="name">Name (A-Z)</option>
                <option value="price_asc">Price (Low to High)</option>
                <option value="price_desc">Price (High to Low)</option>
                <option value="stock_asc">Manual Stock (Lowest First)</option>
              </ElectricSelect>
            </div>
          </div>

          {loading ? (
            <div className="neu-card">Loading products...</div>
          ) : paged.length === 0 ? (
            <div className="neu-card" style={{ textAlign: 'center', color: 'var(--muted)' }}>
              No matching motorcycle parts found.
            </div>
          ) : (
            <>
              <div className="cards-grid">
                {paged.map((p) => (
                  <div key={p.id} className="item-card">
                    <div>
                      {p.image_url && (
                        <div
                          onClick={() => setLightboxProduct(p)}
                          style={{
                            position: 'relative',
                            width: '100%',
                            height: 140,
                            borderRadius: 16,
                            overflow: 'hidden',
                            marginBottom: 10,
                            cursor: 'pointer',
                            boxShadow: 'var(--shadow-in-sm)',
                          }}
                          title="Click to view full image"
                        >
                          <img src={p.image_url} alt={p.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                          <span style={{ position: 'absolute', right: 8, bottom: 8, background: 'rgba(0,0,0,0.55)', color: '#fff', borderRadius: 8, padding: '3px 6px', display: 'flex', alignItems: 'center', gap: 4, fontSize: 10 }}>
                            <Maximize2 size={11} /> Full
                          </span>
                        </div>
                      )}
                      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center' }}>
                        <span className="status-pill st-blue">{p.position_application}</span>
                        {canViewStock && (
                          <span className={`status-pill ${p.stock_quantity <= 0 ? 'st-bad' : p.stock_quantity <= 8 ? 'st-warn' : 'st-ok'}`}>
                            Stock: {p.stock_quantity}
                          </span>
                        )}
                      </div>
                      <h3 style={{ fontSize: 14.5, fontWeight: 700, marginTop: 10 }}>{p.name}</h3>
                      <p style={{ fontSize: 11.5, color: 'var(--muted)', marginTop: 2 }}>
                        SKU: <strong>{p.sku}</strong> • {p.brand}
                      </p>
                      {(p.dealer_price != null || p.workshop_price != null) && (
                        <p style={{ fontSize: 11, color: 'var(--muted)', marginTop: 3 }}>
                          {p.dealer_price != null ? `Dealer: ${formatBDT(p.dealer_price)} ` : ''}
                          {p.workshop_price != null ? `• Workshop: ${formatBDT(p.workshop_price)}` : ''}
                        </p>
                      )}
                      {(p.compatible_brand || p.compatible_model) && (
                        <p style={{ fontSize: 11.5, marginTop: 6, display: 'flex', alignItems: 'center', gap: 4 }}>
                          {p.fitment_verified ? <CheckCircle2 size={13} color="var(--success)" /> : <AlertTriangle size={13} color="var(--warning)" />}
                          <span>
                            {p.compatible_brand} {p.compatible_model} {p.model_year_range ? `(${p.model_year_range})` : ''} •{' '}
                            <em>{p.fitment_verified ? 'Verified' : 'Unverified Fitment'}</em>
                          </span>
                        </p>
                      )}
                    </div>

                    <div style={{ borderTop: '1px solid var(--border-subtle)', paddingTop: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                      <span style={{ fontSize: 16, fontWeight: 800, color: 'var(--blue)' }}>
                        {formatBDT(p.selling_price)}
                      </span>
                      <div style={{ display: 'flex', gap: 6 }}>
                        {isAdmin && (
                          <>
                            <button type="button" className="neu-btn-sm" onClick={() => setEditingProduct(p)} title="Edit / Manual Stock">
                              <Edit3 size={13} />
                            </button>
                            <button type="button" className="neu-btn-sm" onClick={() => openPriceHistory(p)} title="Price History">
                              <History size={13} />
                            </button>
                          </>
                        )}
                        <button type="button" className="neu-btn-sm primary" disabled={!p.is_active} onClick={() => onAddToCart(p)}>
                          <Plus size={13} /> Add
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {totalPages > 1 && (
                <div style={{ display: 'flex', justifyContent: 'center', gap: 10, marginTop: 18 }}>
                  <button type="button" className="neu-btn-sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Prev</button>
                  <span style={{ fontSize: 12.5, alignSelf: 'center', color: 'var(--muted)' }}>Page {page} of {totalPages}</span>
                  <button type="button" className="neu-btn-sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>Next</button>
                </div>
              )}
            </>
          )}
        </>
      )}

      {/* Admin Add/Edit Product + Multi-Fitment + Tier Prices Modal */}
      {editingProduct && isAdmin && (
        <div className="modal-backdrop">
          <div className="modal-box">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ fontSize: 17, fontWeight: 700 }}>
                {editingProduct.id ? 'Edit Product & Manual Stock' : 'Add Motorcycle Part'}
              </h3>
              <button type="button" className="neu-btn-sm" onClick={() => setEditingProduct(null)}>Close</button>
            </div>
            <form onSubmit={handleSaveProduct}>
              <ElectricInput id="ep-name" label="Product Name" value={editingProduct.name || ''} onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })} required />
              <ElectricInput id="ep-sku" label="SKU / Part Number" value={editingProduct.sku || ''} onChange={(e) => setEditingProduct({ ...editingProduct, sku: e.target.value })} required />
              <ElectricInput id="ep-barcode" label="Barcode / QR Code (Optional)" value={editingProduct.barcode_qr || ''} onChange={(e) => setEditingProduct({ ...editingProduct, barcode_qr: e.target.value })} />
              <ElectricInput id="ep-brand" label="Part Brand" value={editingProduct.brand || ''} onChange={(e) => setEditingProduct({ ...editingProduct, brand: e.target.value })} required />
              <ElectricSelect id="ep-cat" label="Category" value={editingProduct.category_id || ''} onChange={(e) => setEditingProduct({ ...editingProduct, category_id: e.target.value })}>
                <option value="">Uncategorized</option>
                {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
              </ElectricSelect>
              <ElectricInput
                id="ep-compat-brand"
                label="Compatible Bike Brands (comma-separated, e.g. Hero, Bajaj, TVS)"
                value={editingProduct.compatible_brand || ''}
                onChange={(e) => setEditingProduct({ ...editingProduct, compatible_brand: e.target.value })}
              />
              <ElectricInput
                id="ep-compat-model"
                label="Compatible Bike Models (comma-separated, e.g. Pulsar 150, Apache RTR)"
                value={editingProduct.compatible_model || ''}
                onChange={(e) => setEditingProduct({ ...editingProduct, compatible_model: e.target.value })}
              />
              <ElectricInput id="ep-year" label="Model Year Range (e.g. 2018-2024)" value={editingProduct.model_year_range || ''} onChange={(e) => setEditingProduct({ ...editingProduct, model_year_range: e.target.value })} />
              <ElectricSelect id="ep-pos" label="Position / Application" value={editingProduct.position_application || 'Other'} onChange={(e) => setEditingProduct({ ...editingProduct, position_application: e.target.value as PositionApplication })}>
                {POSITIONS.map((pos) => <option key={pos} value={pos}>{pos}</option>)}
              </ElectricSelect>
              <ElectricInput id="ep-price" type="number" step="0.01" label="Retail Selling Price (BDT)" value={editingProduct.selling_price ?? 0} onChange={(e) => setEditingProduct({ ...editingProduct, selling_price: Number(e.target.value) })} required />
              <ElectricInput id="ep-dealer" type="number" step="0.01" label="Dealer Price (Optional BDT)" value={editingProduct.dealer_price ?? ''} onChange={(e) => setEditingProduct({ ...editingProduct, dealer_price: e.target.value === '' ? null : Number(e.target.value) })} />
              <ElectricInput id="ep-workshop" type="number" step="0.01" label="Workshop Price (Optional BDT)" value={editingProduct.workshop_price ?? ''} onChange={(e) => setEditingProduct({ ...editingProduct, workshop_price: e.target.value === '' ? null : Number(e.target.value) })} />
              <ElectricInput id="ep-stock" type="number" label="Manual Stock Quantity (Admin Controlled)" value={editingProduct.stock_quantity ?? 0} onChange={(e) => setEditingProduct({ ...editingProduct, stock_quantity: Number(e.target.value) })} required />
              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 12, color: 'var(--muted)', display: 'block', marginBottom: 6 }}>
                  Product Photo (Upload or Paste URL)
                </label>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                  <label className="neu-btn-sm" style={{ cursor: 'pointer' }}>
                    <ImageIcon size={13} /> {uploadingImg ? 'Uploading...' : 'Choose Photo'}
                    <input type="file" accept="image/*" onChange={handleProductImageUpload} style={{ display: 'none' }} />
                  </label>
                  {editingProduct.image_url && (
                    <img src={editingProduct.image_url} alt="Preview" style={{ width: 44, height: 44, borderRadius: 10, objectFit: 'cover' }} />
                  )}
                </div>
              </div>
              <ElectricInput id="ep-img" label="Image URL (Auto-filled on upload)" value={editingProduct.image_url || ''} onChange={(e) => setEditingProduct({ ...editingProduct, image_url: e.target.value })} />
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12.5, marginBottom: 10 }}>
                <input type="checkbox" checked={Boolean(editingProduct.fitment_verified)} onChange={(e) => setEditingProduct({ ...editingProduct, fitment_verified: e.target.checked })} />
                Fitment Verified by Admin
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12.5, marginBottom: 16 }}>
                <input type="checkbox" checked={editingProduct.is_active ?? true} onChange={(e) => setEditingProduct({ ...editingProduct, is_active: e.target.checked })} />
                Active Product
              </label>
              <button type="submit" className="main-btn">SAVE PRODUCT</button>
            </form>
          </div>
        </div>
      )}

      {showBulkAdd && isAdmin && (
        <div className="modal-backdrop">
          <div className="modal-box" style={{ width: 620 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700 }}>Bulk Add / Update Products (CSV or Excel Paste)</h3>
              <button type="button" className="neu-btn-sm" onClick={() => setShowBulkAdd(false)}>Close</button>
            </div>
            <p style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 10 }}>
              Columns: <code>name, sku, brand, compatible_brand, compatible_model, position, retail_price, dealer_price, workshop_price, manual_stock, barcode</code>
            </p>
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
              <button type="button" className="neu-btn-sm" onClick={downloadBulkTemplate}>Download CSV Template</button>
              <label className="neu-btn-sm" style={{ cursor: 'pointer' }}>
                <Upload size={13} /> Upload .CSV File
                <input type="file" accept=".csv,.txt" onChange={handleBulkFileUpload} style={{ display: 'none' }} />
              </label>
            </div>
            <textarea
              rows={8}
              placeholder="Paste CSV or Excel rows here..."
              value={bulkRawText}
              onChange={(e) => setBulkRawText(e.target.value)}
              style={{
                width: '100%',
                borderRadius: 14,
                padding: 12,
                border: '1px solid var(--border-subtle)',
                background: 'var(--bg)',
                color: 'var(--text)',
                fontSize: 12,
                marginBottom: 12,
              }}
            />
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 12.5, color: 'var(--muted)' }}>
                Valid rows detected: <strong>{parseBulkRows(bulkRawText).length}</strong>
              </span>
              <button
                type="button"
                className="neu-btn-sm primary"
                disabled={importingBulk || parseBulkRows(bulkRawText).length === 0}
                onClick={handleBulkImportSubmit}
              >
                {importingBulk ? 'Importing...' : 'Import Products'}
              </button>
            </div>
          </div>
        </div>
      )}

      {lightboxProduct && lightboxProduct.image_url && (
        <div className="modal-backdrop" onClick={() => setLightboxProduct(null)}>
          <div className="modal-box" style={{ width: 620, textAlign: 'center' }} onClick={(e) => e.stopPropagation()}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div style={{ textAlign: 'left' }}>
                <h3 style={{ fontSize: 16, fontWeight: 700 }}>{lightboxProduct.name}</h3>
                <p style={{ fontSize: 12, color: 'var(--muted)' }}>SKU: {lightboxProduct.sku} • {formatBDT(lightboxProduct.selling_price)}</p>
              </div>
              <button type="button" className="neu-btn-sm" onClick={() => setLightboxProduct(null)}>Close</button>
            </div>
            <img
              src={lightboxProduct.image_url}
              alt={lightboxProduct.name}
              style={{ width: '100%', maxHeight: '72vh', objectFit: 'contain', borderRadius: 16 }}
            />
          </div>
        </div>
      )}

      {priceHistoryModal && (
        <div className="modal-backdrop">
          <div className="modal-box">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700 }}>Price History: {priceHistoryModal.product.name}</h3>
              <button type="button" className="neu-btn-sm" onClick={() => setPriceHistoryModal(null)}>Close</button>
            </div>
            {priceHistoryModal.rows.length === 0 ? (
              <p style={{ fontSize: 12.5, color: 'var(--muted)' }}>No price changes recorded yet.</p>
            ) : (
              <table className="data-table">
                <thead><tr><th>Date</th><th>Old</th><th>New</th></tr></thead>
                <tbody>
                  {priceHistoryModal.rows.map((r) => (
                    <tr key={r.id}>
                      <td>{new Date(r.changed_at).toLocaleDateString()}</td>
                      <td>{formatBDT(r.old_price)}</td>
                      <td style={{ fontWeight: 700, color: 'var(--blue)' }}>{formatBDT(r.new_price)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
