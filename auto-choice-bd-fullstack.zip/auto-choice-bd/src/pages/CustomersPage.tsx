import React, { useEffect, useState } from 'react';
import { Plus, Search, FileText, MapPin, Printer } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { loadLocalCache, saveLocalCache } from '../lib/localCache';
import { enqueueOfflineMutation } from '../lib/offlineQueue';
import { useRealtimeSync } from '../lib/useRealtimeSync';
import { useAuth } from '../context/AuthContext';
import { formatBDT } from '../lib/i18n';
import { Customer, Order, Payment, PriceTier, Profile, ShopVisit } from '../types/database';
import { ElectricInput, ElectricSelect } from '../components/ElectricInput';

export function CustomersPage({ onToast }: { onToast: (msg: string) => void }) {
  const { profile, businessSettings } = useAuth();
  const isAdmin = profile?.role === 'admin';

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [srs, setSrs] = useState<Profile[]>([]);
  const [visits, setVisits] = useState<ShopVisit[]>([]);
  const [searchQ, setSearchQ] = useState('');
  const [editing, setEditing] = useState<Partial<Customer> | null>(null);

  const [visitCustomer, setVisitCustomer] = useState<Customer | null>(null);
  const [visitStatus, setVisitStatus] = useState<ShopVisit['visit_status']>('later');
  const [visitNotes, setVisitNotes] = useState('');

  const [ledger, setLedger] = useState<{
    customer: Customer;
    orders: Order[];
    payments: Payment[];
  } | null>(null);
  const [statementMonth, setStatementMonth] = useState(() => new Date().toISOString().slice(0, 7));

  const loadData = async () => {
    const [cRes, vRes] = await Promise.all([
      supabase.from('customers').select('*').order('shop_name'),
      supabase.from('shop_visits').select('*, customers(shop_name, area), profiles(full_name)').order('visited_at', { ascending: false }).limit(25),
    ]);
    if (cRes.data) saveLocalCache('customers', cRes.data);
    if (vRes.data) saveLocalCache('visits', vRes.data);
    setCustomers(cRes.data ? (cRes.data as Customer[]) : loadLocalCache<Customer[]>('customers', []));
    setVisits(vRes.data ? (vRes.data as ShopVisit[]) : loadLocalCache<ShopVisit[]>('visits', []));
    if (isAdmin) {
      const sRes = await supabase.from('profiles').select('*').eq('role', 'sr').order('full_name');
      setSrs((sRes.data as Profile[]) || []);
    }
  };

  useEffect(() => {
    loadData();
  }, [isAdmin]);

  useRealtimeSync(['customers', 'shop_visits', 'orders', 'payments'], loadData);

  const filtered = customers.filter((c) => {
    const q = searchQ.trim().toLowerCase();
    return (
      !q ||
      c.shop_name.toLowerCase().includes(q) ||
      c.phone.toLowerCase().includes(q) ||
      c.address.toLowerCase().includes(q) ||
      c.area.toLowerCase().includes(q)
    );
  });

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing || !isAdmin) return;
    const payload = {
      shop_name: editing.shop_name?.trim(),
      contact_person: editing.contact_person?.trim() || null,
      phone: editing.phone?.trim(),
      address: editing.address?.trim() || '',
      area: editing.area?.trim() || '',
      notes: editing.notes?.trim() || '',
      assigned_sr_id: editing.assigned_sr_id || null,
      status: editing.status || 'active',
      credit_limit: Math.max(0, Number(editing.credit_limit || 0)),
      price_tier: editing.price_tier || 'retail',
      created_by: profile?.id,
    };

    const { error } = editing.id
      ? await supabase.from('customers').update(payload).eq('id', editing.id)
      : await supabase.from('customers').insert(payload);

    if (error) {
      onToast(error.message.includes('duplicate') ? 'A customer with this phone already exists.' : error.message);
      return;
    }
    setEditing(null);
    await loadData();
    onToast('Customer saved.');
  };

  const handleVisitCheckIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || !visitCustomer) return;
    if (!navigator.onLine) {
      enqueueOfflineMutation(profile.id, 'shop_visit', {
        sr_id: profile.id,
        customer_id: visitCustomer.id,
        visit_status: visitStatus,
        notes: visitNotes.trim(),
      }, crypto.randomUUID());
      setVisitCustomer(null);
      setVisitNotes('');
      onToast('Offline: Visit queued locally (will sync when online).');
      return;
    }
    const { error } = await supabase.from('shop_visits').insert({
      sr_id: profile.id,
      customer_id: visitCustomer.id,
      visit_status: visitStatus,
      notes: visitNotes.trim(),
    });
    if (error) {
      onToast(error.message);
      return;
    }
    setVisitCustomer(null);
    setVisitNotes('');
    await loadData();
    onToast(`Visit logged for ${visitCustomer.shop_name}`);
  };

  const openLedger = async (customer: Customer) => {
    const [oRes, pRes] = await Promise.all([
      supabase.from('orders').select('*').eq('customer_id', customer.id).order('created_at', { ascending: false }),
      supabase.from('payments').select('*').eq('customer_id', customer.id).order('payment_date', { ascending: false }),
    ]);
    setLedger({
      customer,
      orders: (oRes.data as Order[]) || [],
      payments: (pRes.data as Payment[]) || [],
    });
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, flexWrap: 'wrap', gap: 10 }}>
        <h2 style={{ fontSize: 18, fontWeight: 700 }}>Customers, Visits & Statements</h2>
        {isAdmin && (
          <button
            type="button"
            className="neu-btn-sm primary"
            onClick={() => setEditing({ shop_name: '', phone: '', address: '', area: '', status: 'active', credit_limit: 0, price_tier: 'retail' })}
          >
            <Plus size={14} /> Add Customer
          </button>
        )}
      </div>

      <ElectricInput
        id="cust-search"
        label="Search by shop name, phone, or address..."
        leftIcon={<Search size={15} />}
        value={searchQ}
        onChange={(e) => setSearchQ(e.target.value)}
      />

      <div className="stack-list" style={{ marginBottom: 20 }}>
        {filtered.length === 0 ? (
          <div className="neu-card" style={{ textAlign: 'center', color: 'var(--muted)' }}>No customers found.</div>
        ) : (
          filtered.map((c) => (
            <div key={c.id} className="list-row">
              <div>
                <div style={{ fontWeight: 700, fontSize: 14.5 }}>
                  {c.shop_name}{' '}
                  <span className="status-pill st-blue" style={{ marginLeft: 6 }}>{(c.price_tier || 'retail').toUpperCase()}</span>
                </div>
                <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                  {c.contact_person ? `${c.contact_person} • ` : ''}{c.phone} • {c.address} {c.area}
                  {Number(c.credit_limit) > 0 ? ` • Credit Limit: ${formatBDT(c.credit_limit)}` : ''}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                <span className={`status-pill ${c.status === 'active' ? 'st-ok' : 'st-bad'}`}>{c.status}</span>
                <button type="button" className="neu-btn-sm" onClick={() => setVisitCustomer(c)}>
                  <MapPin size={13} /> Check-In
                </button>
                <button type="button" className="neu-btn-sm" onClick={() => openLedger(c)}>
                  <FileText size={13} /> Statement
                </button>
                {isAdmin && (
                  <button type="button" className="neu-btn-sm" onClick={() => setEditing(c)}>Edit</button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Recent Shop Visits */}
      <div className="neu-card">
        <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 10 }}>Recent SR Shop Visits</h3>
        {visits.length === 0 ? (
          <p style={{ fontSize: 12.5, color: 'var(--muted)' }}>No shop visits logged yet.</p>
        ) : (
          <div className="stack-list">
            {visits.slice(0, 8).map((v) => (
              <div key={v.id} className="neu-inset" style={{ padding: '8px 12px', fontSize: 12, display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 6 }}>
                <span>
                  <strong>{v.customers?.shop_name}</strong> ({v.visit_status.replace('_', ' ')}) — {v.notes || 'No note'}
                </span>
                <span style={{ color: 'var(--muted)' }}>
                  {v.profiles?.full_name} • {new Date(v.visited_at).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add/Edit Customer */}
      {editing && isAdmin && (
        <div className="modal-backdrop">
          <div className="modal-box">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700 }}>{editing.id ? 'Edit Customer' : 'New Customer'}</h3>
              <button type="button" className="neu-btn-sm" onClick={() => setEditing(null)}>Close</button>
            </div>
            <form onSubmit={handleSave}>
              <ElectricInput id="ec-shop" label="Shop / Customer Name" value={editing.shop_name || ''} onChange={(e) => setEditing({ ...editing, shop_name: e.target.value })} required />
              <ElectricInput id="ec-person" label="Contact Person" value={editing.contact_person || ''} onChange={(e) => setEditing({ ...editing, contact_person: e.target.value })} />
              <ElectricInput id="ec-phone" label="Phone Number (Unique)" value={editing.phone || ''} onChange={(e) => setEditing({ ...editing, phone: e.target.value })} required />
              <ElectricInput id="ec-addr" label="Address" value={editing.address || ''} onChange={(e) => setEditing({ ...editing, address: e.target.value })} />
              <ElectricInput id="ec-area" label="Area / District" value={editing.area || ''} onChange={(e) => setEditing({ ...editing, area: e.target.value })} />
              <ElectricSelect id="ec-tier" label="Price Tier" value={editing.price_tier || 'retail'} onChange={(e) => setEditing({ ...editing, price_tier: e.target.value as PriceTier })}>
                <option value="retail">Retail</option>
                <option value="workshop">Workshop</option>
                <option value="dealer">Dealer</option>
              </ElectricSelect>
              <ElectricInput id="ec-limit" type="number" label="Credit Limit (0 = No Limit)" value={editing.credit_limit ?? 0} onChange={(e) => setEditing({ ...editing, credit_limit: Number(e.target.value) })} />
              <ElectricSelect id="ec-sr" label="Assigned SR" value={editing.assigned_sr_id || ''} onChange={(e) => setEditing({ ...editing, assigned_sr_id: e.target.value || null })}>
                <option value="">Unassigned</option>
                {srs.map((s) => <option key={s.id} value={s.id}>{s.full_name} ({s.zone || s.email})</option>)}
              </ElectricSelect>
              <button type="submit" className="main-btn">SAVE CUSTOMER</button>
            </form>
          </div>
        </div>
      )}

      {/* Visit Check-In Modal */}
      {visitCustomer && (
        <div className="modal-backdrop">
          <div className="modal-box">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700 }}>Shop Visit Check-In: {visitCustomer.shop_name}</h3>
              <button type="button" className="neu-btn-sm" onClick={() => setVisitCustomer(null)}>Close</button>
            </div>
            <form onSubmit={handleVisitCheckIn}>
              <ElectricSelect id="vs-st" label="Visit Outcome" value={visitStatus} onChange={(e) => setVisitStatus(e.target.value as ShopVisit['visit_status'])}>
                <option value="ordered">Order Taken</option>
                <option value="later">Will Order Later</option>
                <option value="shop_closed">Shop Closed</option>
                <option value="no_need">No Stock Needed Today</option>
              </ElectricSelect>
              <ElectricInput id="vs-notes" label="Visit Notes" value={visitNotes} onChange={(e) => setVisitNotes(e.target.value)} />
              <button type="submit" className="main-btn">LOG VISIT</button>
            </form>
          </div>
        </div>
      )}

      {/* Customer Monthly Statement & Ledger PDF */}
      {ledger && (
        <div className="modal-backdrop">
          <div className="modal-box print-only-area" style={{ width: 680 }}>
            <div className="no-print" style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12, flexWrap: 'wrap', gap: 8 }}>
              <input
                type="month"
                value={statementMonth}
                onChange={(e) => setStatementMonth(e.target.value)}
                style={{ padding: '6px 10px', borderRadius: 10, border: '1px solid var(--border-subtle)', background: 'var(--bg)', color: 'var(--text)' }}
              />
              <div style={{ display: 'flex', gap: 8 }}>
                <button type="button" className="neu-btn-sm primary" onClick={() => window.print()}>
                  <Printer size={13} /> Print / Save Statement PDF
                </button>
                <button type="button" className="neu-btn-sm" onClick={() => setLedger(null)}>Close</button>
              </div>
            </div>

            <h2 style={{ color: 'var(--blue)', fontWeight: 800 }}>{businessSettings?.business_name || 'Auto Choice BD'}</h2>
            <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 8 }}>
              Monthly Statement ({statementMonth}) — {ledger.customer.shop_name}
            </h3>

            {(() => {
              const mOrders = ledger.orders.filter(
                (o) => o.created_at.startsWith(statementMonth) && o.status !== 'cancelled' && o.status !== 'rejected'
              );
              const mPayments = ledger.payments.filter(
                (p) => p.payment_date.startsWith(statementMonth) && !p.is_reversed
              );
              const mBilled = mOrders.reduce((s, o) => s + Number(o.grand_total), 0);
              const mPaid = mPayments.reduce((s, p) => s + Number(p.amount), 0);

              const allBilled = ledger.orders
                .filter((o) => o.status !== 'cancelled' && o.status !== 'rejected')
                .reduce((s, o) => s + Number(o.grand_total), 0);
              const allPaid = ledger.payments.filter((p) => !p.is_reversed).reduce((s, p) => s + Number(p.amount), 0);

              return (
                <>
                  <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 14 }}>
                    <span className="status-pill st-blue">Month Billed: {formatBDT(mBilled)}</span>
                    <span className="status-pill st-ok">Month Paid: {formatBDT(mPaid)}</span>
                    <span className="status-pill st-warn">Total Closing Due: {formatBDT(Math.max(0, allBilled - allPaid))}</span>
                  </div>
                  <h4 style={{ fontSize: 13, fontWeight: 700, marginBottom: 6 }}>Orders in {statementMonth} ({mOrders.length})</h4>
                  <table className="data-table" style={{ marginBottom: 12 }}>
                    <thead><tr><th>Date</th><th>Order No</th><th>Status</th><th>Total</th></tr></thead>
                    <tbody>
                      {mOrders.map((o) => (
                        <tr key={o.id}>
                          <td>{new Date(o.created_at).toLocaleDateString()}</td>
                          <td>{o.order_number}</td>
                          <td>{o.status}</td>
                          <td>{formatBDT(o.grand_total)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <h4 style={{ fontSize: 13, fontWeight: 700, marginBottom: 6 }}>Payments in {statementMonth} ({mPayments.length})</h4>
                  <table className="data-table">
                    <thead><tr><th>Date</th><th>Receipt No</th><th>Method</th><th>Amount</th></tr></thead>
                    <tbody>
                      {mPayments.map((p) => (
                        <tr key={p.id}>
                          <td>{new Date(p.payment_date).toLocaleDateString()}</td>
                          <td>{p.receipt_number}</td>
                          <td>{p.method}</td>
                          <td>{formatBDT(p.amount)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
}
