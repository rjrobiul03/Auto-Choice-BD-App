import React, { useEffect, useState } from 'react';
import {
  ShoppingBag,
  Clock,
  CreditCard,
  AlertCircle,
  Users,
  Package,
  UserCheck,
  Bell,
  Play,
  Square,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useRealtimeSync } from '../lib/useRealtimeSync';
import { useAuth } from '../context/AuthContext';
import { formatBDT } from '../lib/i18n';
import { NotificationItem, Order, Payment, Product, Profile, SrAttendance } from '../types/database';

export function DashboardPage({ onNavigate }: { onNavigate: (tab: string) => void }) {
  const { profile, businessSettings } = useAuth();
  const isAdmin = profile?.role === 'admin';
  const [dateRange, setDateRange] = useState<'today' | 'week' | 'month' | 'all'>('month');
  const [orders, setOrders] = useState<Order[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [customerCount, setCustomerCount] = useState(0);
  const [srs, setSrs] = useState<Profile[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [todayShift, setTodayShift] = useState<SrAttendance | null>(null);
  const [loading, setLoading] = useState(true);

  const loadDashboard = async () => {
    setLoading(true);
    const now = new Date();
    let fromIso: string | null = null;
    if (dateRange === 'today') {
      fromIso = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();
    } else if (dateRange === 'week') {
      fromIso = new Date(now.getTime() - 7 * 86400000).toISOString();
    } else if (dateRange === 'month') {
      fromIso = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    }

    let ordQuery = supabase
      .from('orders')
      .select('*, customers(shop_name, phone, address, area), profiles(full_name)')
      .order('created_at', { ascending: false });
    if (fromIso) ordQuery = ordQuery.gte('created_at', fromIso);

    let payQuery = supabase
      .from('payments')
      .select('*, customers(shop_name), profiles(full_name)')
      .eq('is_reversed', false)
      .order('payment_date', { ascending: false });
    if (fromIso) payQuery = payQuery.gte('payment_date', fromIso);

    const todayDate = new Date().toISOString().slice(0, 10);

    const [ordRes, payRes, prodRes, custRes, notifRes, attRes] = await Promise.all([
      ordQuery,
      payQuery,
      supabase.from('products').select('*').order('stock_quantity', { ascending: true }),
      supabase.from('customers').select('id', { count: 'exact', head: true }),
      supabase.from('notifications').select('*').eq('is_read', false).order('created_at', { ascending: false }).limit(5),
      profile
        ? supabase.from('sr_attendance').select('*').eq('sr_id', profile.id).eq('work_date', todayDate).maybeSingle()
        : Promise.resolve({ data: null }),
    ]);

    setOrders((ordRes.data as Order[]) || []);
    setPayments((payRes.data as Payment[]) || []);
    setProducts((prodRes.data as Product[]) || []);
    setCustomerCount(custRes.count || 0);
    setNotifications((notifRes.data as NotificationItem[]) || []);
    setTodayShift((attRes.data as SrAttendance) || null);

    if (isAdmin) {
      const { data: srData } = await supabase.from('profiles').select('*').eq('role', 'sr');
      setSrs((srData as Profile[]) || []);
    }
    setLoading(false);
  };

  useEffect(() => {
    loadDashboard();
  }, [dateRange, isAdmin]);

  useRealtimeSync(['orders', 'payments', 'notifications', 'return_claims'], loadDashboard);

  const handleStartDay = async () => {
    if (!profile) return;
    const todayDate = new Date().toISOString().slice(0, 10);
    await supabase.from('sr_attendance').upsert({
      sr_id: profile.id,
      work_date: todayDate,
      started_at: new Date().toISOString(),
    });
    await loadDashboard();
  };

  const handleEndDay = async () => {
    if (!todayShift) return;
    await supabase
      .from('sr_attendance')
      .update({ ended_at: new Date().toISOString() })
      .eq('id', todayShift.id);
    await loadDashboard();
  };

  const validOrders = orders.filter((o) => o.status !== 'cancelled' && o.status !== 'rejected');
  const totalBilled = validOrders.reduce((s, o) => s + Number(o.grand_total), 0);
  const totalCollected = payments.reduce((s, p) => s + Number(p.amount), 0);
  const totalDue = validOrders.reduce(
    (s, o) => s + Math.max(0, Number(o.grand_total) - Number(o.paid_amount)),
    0
  );

  const pendingCount = orders.filter((o) => o.status === 'pending_review').length;
  const approvedCount = orders.filter((o) => o.status === 'approved').length;
  const processingCount = orders.filter((o) => o.status === 'processing' || o.status === 'ready_shipped').length;
  const deliveredCount = orders.filter((o) => o.status === 'delivered').length;
  const cancelledCount = orders.filter((o) => o.status === 'cancelled' || o.status === 'rejected').length;

  const lowThreshold = businessSettings?.low_stock_threshold ?? 8;
  const lowStockProducts = products.filter((p) => p.is_active && p.stock_quantity > 0 && p.stock_quantity <= lowThreshold);
  const unavailableProducts = products.filter((p) => !p.is_active || p.stock_quantity === 0);

  if (loading) {
    return <div className="neu-card">Loading dashboard metrics...</div>;
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, flexWrap: 'wrap', gap: 10 }}>
        <h2 style={{ fontSize: 18, fontWeight: 700 }}>
          {isAdmin ? 'Admin Dashboard' : 'SR Dashboard'}
        </h2>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          {!isAdmin && (
            todayShift ? (
              todayShift.ended_at ? (
                <span className="status-pill st-ok">Shift Ended ({new Date(todayShift.ended_at).toLocaleTimeString()})</span>
              ) : (
                <button type="button" className="neu-btn-sm danger" onClick={handleEndDay}>
                  <Square size={13} /> End Day
                </button>
              )
            ) : (
              <button type="button" className="neu-btn-sm primary" onClick={handleStartDay}>
                <Play size={13} /> Start Day
              </button>
            )
          )}
          <div className="chip-row" style={{ marginBottom: 0 }}>
            {(['today', 'week', 'month', 'all'] as const).map((r) => (
              <button
                key={r}
                type="button"
                className={`chip ${dateRange === r ? 'active' : ''}`}
                onClick={() => setDateRange(r)}
              >
                {r === 'today' ? 'Today' : r === 'week' ? '7 Days' : r === 'month' ? 'This Month' : 'All Time'}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="kpi-grid">
        <div className="kpi-card">
          <div style={{ color: 'var(--blue)', marginBottom: 8 }}><ShoppingBag size={20} /></div>
          <div style={{ fontSize: 20, fontWeight: 800 }}>{formatBDT(totalBilled)}</div>
          <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>Total Billed Sales ({validOrders.length} orders)</div>
        </div>
        <div className="kpi-card">
          <div style={{ color: 'var(--success)', marginBottom: 8 }}><CreditCard size={20} /></div>
          <div style={{ fontSize: 20, fontWeight: 800 }}>{formatBDT(totalCollected)}</div>
          <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>Payments Received</div>
        </div>
        <div className="kpi-card">
          <div style={{ color: 'var(--warning)', marginBottom: 8 }}><AlertCircle size={20} /></div>
          <div style={{ fontSize: 20, fontWeight: 800 }}>{formatBDT(totalDue)}</div>
          <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>Outstanding Dues</div>
        </div>
        <div className="kpi-card">
          <div style={{ color: 'var(--blue)', marginBottom: 8 }}><Clock size={20} /></div>
          <div style={{ fontSize: 20, fontWeight: 800 }}>{pendingCount}</div>
          <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>Pending Approvals</div>
        </div>
        <div className="kpi-card">
          <div style={{ color: 'var(--blue)', marginBottom: 8 }}><Users size={20} /></div>
          <div style={{ fontSize: 20, fontWeight: 800 }}>{customerCount}</div>
          <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>Customers</div>
        </div>
        {isAdmin && (
          <>
            <div className="kpi-card">
              <div style={{ color: 'var(--success)', marginBottom: 8 }}><UserCheck size={20} /></div>
              <div style={{ fontSize: 20, fontWeight: 800 }}>
                {srs.filter((s) => s.status === 'active').length}/{srs.length}
              </div>
              <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>Active SRs</div>
            </div>
            <div className="kpi-card">
              <div style={{ color: 'var(--blue)', marginBottom: 8 }}><Package size={20} /></div>
              <div style={{ fontSize: 20, fontWeight: 800 }}>{products.length}</div>
              <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>
                Products ({lowStockProducts.length} Low, {unavailableProducts.length} Out/Inactive)
              </div>
            </div>
          </>
        )}
      </div>

      <div className="neu-card" style={{ marginBottom: 16 }}>
        <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 12 }}>Order Pipeline</h3>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <span className="status-pill st-warn">Pending: {pendingCount}</span>
          <span className="status-pill st-blue">Approved: {approvedCount}</span>
          <span className="status-pill st-blue">Processing/Shipped: {processingCount}</span>
          <span className="status-pill st-ok">Delivered: {deliveredCount}</span>
          <span className="status-pill st-bad">Cancelled/Rejected: {cancelledCount}</span>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 16 }}>
        <div className="neu-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700 }}>Recent Orders</h3>
            <button type="button" className="neu-btn-sm" onClick={() => onNavigate('orders')}>View All</button>
          </div>
          {orders.length === 0 ? (
            <p style={{ fontSize: 12.5, color: 'var(--muted)' }}>No orders in this period.</p>
          ) : (
            <div className="stack-list">
              {orders.slice(0, 4).map((o) => (
                <div key={o.id} className="list-row" style={{ boxShadow: 'var(--shadow-in-sm)' }}>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 13 }}>{o.order_number}</div>
                    <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>
                      {o.customers?.shop_name} • {o.profiles?.full_name}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontWeight: 700, color: 'var(--blue)' }}>{formatBDT(o.grand_total)}</div>
                    <span className="status-pill st-blue">{o.status.replace('_', ' ')}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="neu-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <h3 style={{ fontSize: 15, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6 }}>
              <Bell size={16} color="var(--blue)" /> Alerts & Notifications
            </h3>
            <button type="button" className="neu-btn-sm" onClick={() => onNavigate('settings')}>Manage</button>
          </div>
          <div className="stack-list">
            {notifications.map((n) => (
              <div key={n.id} className="neu-inset" style={{ padding: '10px 12px', fontSize: 12 }}>
                <div style={{ fontWeight: 700 }}>{n.title}</div>
                <div style={{ color: 'var(--muted)' }}>{n.message}</div>
              </div>
            ))}
            {isAdmin && lowStockProducts.slice(0, 3).map((p) => (
              <div key={p.id} className="neu-inset" style={{ padding: '10px 12px', fontSize: 12, color: 'var(--warning)' }}>
                Low Manual Stock: <strong>{p.name}</strong> ({p.sku}) — {p.stock_quantity} left
              </div>
            ))}
            {notifications.length === 0 && lowStockProducts.length === 0 && (
              <p style={{ fontSize: 12.5, color: 'var(--muted)' }}>No unread alerts.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
