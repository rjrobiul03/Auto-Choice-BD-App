import React, { useEffect, useState } from 'react';
import { Printer, Share2, Trash2, Plus, Minus, Repeat, AlertTriangle, RotateCcw, Download } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { loadLocalCache, saveLocalCache } from '../lib/localCache';
import { useRealtimeSync } from '../lib/useRealtimeSync';
import { useAuth } from '../context/AuthContext';
import { formatBDT } from '../lib/i18n';
import { Customer, Order, OrderStatus, Product, ReturnClaim } from '../types/database';
import { enqueueOfflineMutation } from '../lib/offlineQueue';
import { buildOrderWhatsAppText, shareViaWhatsApp } from '../lib/exportUtils';
import { ElectricInput, ElectricSelect } from '../components/ElectricInput';

export interface CartLine {
  product: Product;
  quantity: number;
}

interface OrdersPageProps {
  cart: CartLine[];
  setCart: React.Dispatch<React.SetStateAction<CartLine[]>>;
  onToast: (msg: string) => void;
}

export function OrdersPage({ cart, setCart, onToast }: OrdersPageProps) {
  const { profile, businessSettings } = useAuth();
  const isAdmin = profile?.role === 'admin';

  const [subTab, setSubTab] = useState<'orders' | 'claims'>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [claims, setClaims] = useState<ReturnClaim[]>([]);
  const [statusFilter, setStatusFilter] = useState<'ALL' | OrderStatus>('ALL');
  const [selectedCustomerId, setSelectedCustomerId] = useState('');
  const [discountAmount, setDiscountAmount] = useState(0);
  const [deliveryCharge, setDeliveryCharge] = useState(0);
  const [orderNotes, setOrderNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const [invoiceOrder, setInvoiceOrder] = useState<Order | null>(null);
  const [thermalMode, setThermalMode] = useState(false);
  const [rejectModal, setRejectModal] = useState<{ orderId: string; targetStatus: 'rejected' | 'cancelled' } | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  // Return / Damage Claim modal
  const [showClaimModal, setShowClaimModal] = useState(false);
  const [claimCustId, setClaimCustId] = useState('');
  const [claimProdId, setClaimProdId] = useState('');
  const [claimQty, setClaimQty] = useState(1);
  const [claimType, setClaimType] = useState<'damaged' | 'wrong_item' | 'other'>('damaged');
  const [claimReason, setClaimReason] = useState('');
  const [claimAdj, setClaimAdj] = useState(0);

  const loadOrdersAndCustomers = async () => {
    const [oRes, cRes, pRes, clRes] = await Promise.all([
      supabase
        .from('orders')
        .select('*, customers(shop_name, phone, address, area, price_tier), profiles(full_name, phone), order_items(*)')
        .order('created_at', { ascending: false }),
      supabase.from('customers').select('*').eq('status', 'active').order('shop_name'),
      supabase.from('products').select('*').eq('is_active', true),
      supabase
        .from('return_claims')
        .select('*, customers(shop_name), products(name, sku), profiles!return_claims_sr_id_fkey(full_name)')
        .order('created_at', { ascending: false }),
    ]);
    if (oRes.data) saveLocalCache('orders', oRes.data);
    if (cRes.data) saveLocalCache('customers', cRes.data);
    if (pRes.data) saveLocalCache('products', pRes.data);
    setOrders(oRes.data ? (oRes.data as Order[]) : loadLocalCache<Order[]>('orders', []));
    const custList = cRes.data ? (cRes.data as Customer[]) : loadLocalCache<Customer[]>('customers', []);
    setCustomers(custList);
    if (!selectedCustomerId && custList.length > 0) setSelectedCustomerId(custList[0].id);
    if (!claimCustId && custList.length > 0) setClaimCustId(custList[0].id);
    const prodList = pRes.data ? (pRes.data as Product[]) : loadLocalCache<Product[]>('products', []);
    setProducts(prodList);
    if (!claimProdId && prodList.length > 0) setClaimProdId(prodList[0].id);
    setClaims((clRes.data as ReturnClaim[]) || []);
  };

  useEffect(() => {
    loadOrdersAndCustomers();
  }, []);

  useRealtimeSync(['orders', 'order_items', 'return_claims'], loadOrdersAndCustomers);

  const selectedCustomer = customers.find((c) => c.id === selectedCustomerId);

  // Compute tier-aware unit price preview
  const getTierPrice = (p: Product): number => {
    if (selectedCustomer?.price_tier === 'dealer' && p.dealer_price != null) return Number(p.dealer_price);
    if (selectedCustomer?.price_tier === 'workshop' && p.workshop_price != null) return Number(p.workshop_price);
    return Number(p.selling_price);
  };

  // Compute selected customer's current due & due age in days
  const customerUnpaidOrders = orders.filter(
    (o) =>
      o.customer_id === selectedCustomerId &&
      o.status !== 'cancelled' &&
      o.status !== 'rejected' &&
      Number(o.grand_total) > Number(o.paid_amount)
  );
  const currentCustomerDue = customerUnpaidOrders.reduce(
    (s, o) => s + Math.max(0, Number(o.grand_total) - Number(o.paid_amount)),
    0
  );
  const oldestUnpaidDays = customerUnpaidOrders.reduce((maxD, o) => {
    const days = Math.floor((Date.now() - new Date(o.created_at).getTime()) / 86400000);
    return Math.max(maxD, days);
  }, 0);

  const cartSubtotal = cart.reduce((s, c) => s + getTierPrice(c.product) * c.quantity, 0);
  const cartGrandTotal = Math.max(0, cartSubtotal - discountAmount + deliveryCharge);
  const exceedsCreditLimit =
    selectedCustomer &&
    Number(selectedCustomer.credit_limit) > 0 &&
    currentCustomerDue + cartGrandTotal > Number(selectedCustomer.credit_limit);

  const handleRepeatOrder = (order: Order) => {
    if (!order.order_items || order.order_items.length === 0) {
      onToast('No items found in this order to repeat.');
      return;
    }
    const newLines: CartLine[] = [];
    for (const item of order.order_items) {
      const prod = products.find((p) => p.id === item.product_id);
      if (prod) newLines.push({ product: prod, quantity: item.quantity });
    }
    if (newLines.length === 0) {
      onToast('Products from that order are no longer active.');
      return;
    }
    setSelectedCustomerId(order.customer_id);
    setCart(newLines);
    onToast(`Loaded ${newLines.length} item(s) from ${order.order_number} into Cart!`);
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || cart.length === 0 || !selectedCustomerId) return;

    const idempotencyKey = crypto.randomUUID();
    const itemsPayload = cart.map((c) => ({ product_id: c.product.id, quantity: c.quantity }));

    if (!navigator.onLine) {
      enqueueOfflineMutation(
        profile.id,
        'submit_order',
        {
          customer_id: selectedCustomerId,
          items: itemsPayload,
          discount_amount: discountAmount,
          delivery_charge: deliveryCharge,
          notes: orderNotes,
        },
        idempotencyKey
      );
      setCart([]);
      setOrderNotes('');
      onToast('Offline: Order queued locally (not yet synced to cloud).');
      return;
    }

    setSubmitting(true);
    const { data, error } = await supabase.rpc('submit_order_secure', {
      p_customer_id: selectedCustomerId,
      p_items: itemsPayload,
      p_discount_amount: discountAmount,
      p_delivery_charge: deliveryCharge,
      p_notes: orderNotes,
      p_idempotency_key: idempotencyKey,
    });
    setSubmitting(false);

    if (error) {
      onToast(error.message);
      return;
    }

    setCart([]);
    setDiscountAmount(0);
    setDeliveryCharge(0);
    setOrderNotes('');
    await loadOrdersAndCustomers();
    const { data: fullOrder } = await supabase
      .from('orders')
      .select('*, customers(shop_name, phone, address, area, price_tier), profiles(full_name, phone), order_items(*)')
      .eq('id', (data as Order).id)
      .single();
    if (fullOrder) {
      setThermalMode(false);
      setInvoiceOrder(fullOrder as Order);
    }
    onToast(`Order ${(data as Order).order_number} submitted! Memo opened.`);
  };

  const updateOrderStatus = async (orderId: string, newStatus: OrderStatus, reason?: string) => {
    if (!isAdmin) return;
    const { error } = await supabase
      .from('orders')
      .update({ status: newStatus, status_reason: reason || null, updated_at: new Date().toISOString() })
      .eq('id', orderId);
    if (error) {
      onToast(error.message);
      return;
    }
    await loadOrdersAndCustomers();
    onToast(`Order updated to ${newStatus.replace('_', ' ')}`);
  };

  const handleSubmitClaim = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || !claimCustId || !claimProdId) return;
    const { error } = await supabase.from('return_claims').insert({
      claim_number: '',
      customer_id: claimCustId,
      sr_id: profile.id,
      product_id: claimProdId,
      quantity: Math.max(1, Number(claimQty)),
      claim_type: claimType,
      reason: claimReason.trim(),
      adjustment_amount: Math.max(0, Number(claimAdj)),
    });
    if (error) {
      onToast(error.message);
      return;
    }
    setShowClaimModal(false);
    setClaimReason('');
    setClaimAdj(0);
    await loadOrdersAndCustomers();
    onToast('Return/Damage claim submitted (manual stock unchanged).');
  };

  const handleClaimAction = async (claimId: string, status: 'approved' | 'rejected') => {
    if (!isAdmin) return;
    const { error } = await supabase
      .from('return_claims')
      .update({ status, reviewed_by: profile?.id, reviewed_at: new Date().toISOString() })
      .eq('id', claimId);
    if (error) {
      onToast(error.message);
      return;
    }
    await loadOrdersAndCustomers();
    onToast(`Claim ${status} (manual stock remains Admin-controlled).`);
  };

  const handleSaveMemoFile = (order: Order) => {
    const due = Math.max(0, Number(order.grand_total) - Number(order.paid_amount));
    const rowsHtml = (order.order_items || [])
      .map(
        (item, idx) =>
          `<tr><td>${idx + 1}</td><td>${item.product_name_snapshot} (${item.sku_snapshot})</td><td>${item.quantity}</td><td>${formatBDT(item.unit_price)}</td><td>${formatBDT(item.line_total)}</td></tr>`
      )
      .join('');
    const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Memo-${order.order_number}</title>
<style>
  body { font-family: Arial, sans-serif; padding: 28px; color: #1f2937; }
  .memo { position: relative; max-width: 720px; margin: 0 auto; border: 1.5px solid #006cff; border-radius: 14px; padding: 24px; overflow: hidden; }
  .watermark { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; pointer-events: none; z-index: 0; }
  .watermark img { width: 320px; max-width: 72%; opacity: 0.08; }
  .content { position: relative; z-index: 1; }
  table { width: 100%; border-collapse: collapse; margin: 14px 0; font-size: 13px; }
  th, td { border-bottom: 1px solid #d1d5db; padding: 8px; text-align: left; }
  th { background: rgba(0,108,255,0.08); }
  .totals { text-align: right; font-size: 13.5px; line-height: 1.6; }
</style>
</head>
<body>
  <div class="memo">
    <div class="watermark"><img src="${window.location.origin}/logo.jpg" alt="Auto Choice BD" /></div>
    <div class="content">
      <h2 style="margin:0;color:#006cff;">${businessSettings?.business_name || 'Auto Choice BD'}</h2>
      <p style="margin:2px 0 10px;font-size:12px;color:#4b5563;">${businessSettings?.tagline || 'Buy And Feel Like A King'}</p>
      <div style="font-size:13px;margin-bottom:10px;">
        <strong>Memo / Order #:</strong> ${order.order_number} &nbsp;|&nbsp;
        <strong>Date:</strong> ${new Date(order.created_at).toLocaleString()}<br/>
        <strong>Shop:</strong> ${order.customers?.shop_name || ''} (${order.customers?.phone || ''}) &nbsp;|&nbsp;
        <strong>SR:</strong> ${order.profiles?.full_name || ''}
      </div>
      <table>
        <thead><tr><th>#</th><th>Product</th><th>Qty</th><th>Rate</th><th>Total</th></tr></thead>
        <tbody>${rowsHtml}</tbody>
      </table>
      <div class="totals">
        <div>Subtotal: ${formatBDT(order.subtotal)}</div>
        ${Number(order.discount_amount) > 0 ? `<div>Discount: -${formatBDT(order.discount_amount)}</div>` : ''}
        ${Number(order.delivery_charge) > 0 ? `<div>Delivery: ${formatBDT(order.delivery_charge)}</div>` : ''}
        <div style="font-size:16px;font-weight:bold;color:#006cff;">Grand Total: ${formatBDT(order.grand_total)}</div>
        <div>Paid: ${formatBDT(order.paid_amount)} | <strong>Due: ${formatBDT(due)}</strong></div>
      </div>
    </div>
  </div>
</body>
</html>`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Memo-${order.order_number}.html`;
    a.click();
    URL.revokeObjectURL(url);
    onToast(`Saved Memo-${order.order_number}.html`);
  };

  const filteredOrders = orders.filter((o) => statusFilter === 'ALL' || o.status === statusFilter);

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, flexWrap: 'wrap', gap: 10 }}>
        <div className="chip-row" style={{ marginBottom: 0 }}>
          <button type="button" className={`chip ${subTab === 'orders' ? 'active' : ''}`} onClick={() => setSubTab('orders')}>
            Orders & Cart
          </button>
          <button type="button" className={`chip ${subTab === 'claims' ? 'active' : ''}`} onClick={() => setSubTab('claims')}>
            <RotateCcw size={13} style={{ marginRight: 4, verticalAlign: 'middle' }} /> Returns & Claims ({claims.length})
          </button>
        </div>
        {subTab === 'claims' && (
          <button type="button" className="neu-btn-sm primary" onClick={() => setShowClaimModal(true)}>
            <Plus size={14} /> New Return / Claim
          </button>
        )}
      </div>

      {subTab === 'claims' ? (
        <div className="stack-list">
          {claims.length === 0 ? (
            <div className="neu-card" style={{ textAlign: 'center', color: 'var(--muted)' }}>
              No return or damage claims yet.
            </div>
          ) : (
            claims.map((c) => (
              <div key={c.id} className="list-row">
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14 }}>
                    {c.claim_number} • {c.customers?.shop_name}
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                    {c.products?.name} ({c.products?.sku}) × {c.quantity} • Type: {c.claim_type.toUpperCase()} •
                    Adjustment: <strong>{formatBDT(c.adjustment_amount)}</strong>
                  </div>
                  <div style={{ fontSize: 11.5, marginTop: 2 }}>Reason: {c.reason}</div>
                </div>
                <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                  <span className={`status-pill ${c.status === 'approved' ? 'st-ok' : c.status === 'rejected' ? 'st-bad' : 'st-warn'}`}>
                    {c.status}
                  </span>
                  {isAdmin && c.status === 'pending' && (
                    <>
                      <button type="button" className="neu-btn-sm primary" onClick={() => handleClaimAction(c.id, 'approved')}>Approve</button>
                      <button type="button" className="neu-btn-sm danger" onClick={() => handleClaimAction(c.id, 'rejected')}>Reject</button>
                    </>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      ) : (
        <>
          {cart.length > 0 && (
            <div className="neu-card" style={{ marginBottom: 18 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>
                New Order Review ({cart.length} items • Tier: {(selectedCustomer?.price_tier || 'retail').toUpperCase()})
              </h3>

              {(exceedsCreditLimit || oldestUnpaidDays >= 30) && (
                <div className="neu-inset" style={{ padding: '10px 14px', marginBottom: 12, fontSize: 12.5, color: 'var(--danger)', display: 'flex', gap: 8, alignItems: 'center' }}>
                  <AlertTriangle size={16} />
                  <span>
                    {exceedsCreditLimit && `Credit Limit Alert: Current Due (${formatBDT(currentCustomerDue)}) + Order (${formatBDT(cartGrandTotal)}) exceeds limit (${formatBDT(selectedCustomer?.credit_limit || 0)}). `}
                    {oldestUnpaidDays >= 30 && `Due Aging Alert: Unpaid balance is ${oldestUnpaidDays} days old.`}
                  </span>
                </div>
              )}

              <div className="stack-list" style={{ marginBottom: 14 }}>
                {cart.map((line) => {
                  const unitPrice = getTierPrice(line.product);
                  return (
                    <div key={line.product.id} className="list-row" style={{ boxShadow: 'var(--shadow-in-sm)' }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 13.5 }}>{line.product.name}</div>
                        <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>
                          {formatBDT(unitPrice)} × {line.quantity} = <strong>{formatBDT(unitPrice * line.quantity)}</strong>
                        </div>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <button type="button" className="neu-btn-sm" onClick={() => setCart((prev) => prev.map((c) => (c.product.id === line.product.id ? { ...c, quantity: c.quantity - 1 } : c)).filter((c) => c.quantity > 0))}>
                          <Minus size={13} />
                        </button>
                        <span style={{ fontWeight: 700 }}>{line.quantity}</span>
                        <button type="button" className="neu-btn-sm" onClick={() => setCart((prev) => prev.map((c) => (c.product.id === line.product.id ? { ...c, quantity: c.quantity + 1 } : c)))}>
                          <Plus size={13} />
                        </button>
                        <button type="button" className="neu-btn-sm danger" onClick={() => setCart((prev) => prev.filter((c) => c.product.id !== line.product.id))}>
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>

              <form onSubmit={handleSubmitOrder}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 10 }}>
                  <ElectricSelect id="ord-cust" label="Select Customer" value={selectedCustomerId} onChange={(e) => setSelectedCustomerId(e.target.value)} required>
                    {customers.map((c) => (
                      <option key={c.id} value={c.id}>{c.shop_name} ({c.price_tier.toUpperCase()} • {c.area || c.phone})</option>
                    ))}
                  </ElectricSelect>
                  <ElectricInput id="ord-disc" type="number" label="Discount (BDT)" value={discountAmount} onChange={(e) => setDiscountAmount(Math.max(0, Number(e.target.value)))} />
                  <ElectricInput id="ord-deliv" type="number" label="Delivery Charge (BDT)" value={deliveryCharge} onChange={(e) => setDeliveryCharge(Math.max(0, Number(e.target.value)))} />
                  <ElectricInput id="ord-notes" label="Order Notes" value={orderNotes} onChange={(e) => setOrderNotes(e.target.value)} />
                </div>

                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8, flexWrap: 'wrap', gap: 10 }}>
                  <div style={{ fontSize: 16, fontWeight: 800, color: 'var(--blue)' }}>
                    Grand Total: {formatBDT(cartGrandTotal)}
                  </div>
                  <button type="submit" className="neu-btn-sm primary" style={{ padding: '12px 22px' }} disabled={submitting}>
                    {submitting ? 'Submitting...' : 'Submit Order'}
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="chip-row">
            {(['ALL', 'pending_review', 'approved', 'processing', 'ready_shipped', 'delivered', 'rejected', 'cancelled'] as const).map((st) => (
              <button key={st} type="button" className={`chip ${statusFilter === st ? 'active' : ''}`} onClick={() => setStatusFilter(st)}>
                {st === 'ALL' ? 'All Orders' : st.replace('_', ' ')}
              </button>
            ))}
          </div>

          <div className="stack-list">
            {filteredOrders.length === 0 ? (
              <div className="neu-card" style={{ textAlign: 'center', color: 'var(--muted)' }}>No orders found.</div>
            ) : (
              filteredOrders.map((o) => {
                const due = Math.max(0, Number(o.grand_total) - Number(o.paid_amount));
                return (
                  <div key={o.id} className="list-row">
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 14 }}>{o.order_number} • {o.customers?.shop_name}</div>
                      <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>
                        {new Date(o.created_at).toLocaleString()} • SR: {o.profiles?.full_name} •{' '}
                        Total: <strong>{formatBDT(o.grand_total)}</strong> • Paid: {formatBDT(o.paid_amount)} •{' '}
                        Due: <strong style={{ color: due > 0 ? 'var(--warning)' : 'var(--success)' }}>{formatBDT(due)}</strong>
                      </div>
                      {o.status_reason && <div style={{ fontSize: 11.5, color: 'var(--danger)', marginTop: 2 }}>Reason: {o.status_reason}</div>}
                    </div>

                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', alignItems: 'center' }}>
                      <span className="status-pill st-blue">{o.status.replace('_', ' ')}</span>
                      <button type="button" className="neu-btn-sm" onClick={() => handleRepeatOrder(o)} title="Repeat Last Order">
                        <Repeat size={13} /> Repeat
                      </button>
                      <button type="button" className="neu-btn-sm" onClick={() => { setThermalMode(false); setInvoiceOrder(o); }}>
                        <Printer size={13} /> Memo
                      </button>
                      <button type="button" className="neu-btn-sm" onClick={() => shareViaWhatsApp(o.customers?.phone, buildOrderWhatsAppText(o, businessSettings))}>
                        <Share2 size={13} /> WhatsApp
                      </button>

                      {isAdmin && o.status === 'pending_review' && (
                        <>
                          <button type="button" className="neu-btn-sm primary" onClick={() => updateOrderStatus(o.id, 'approved')}>Approve</button>
                          <button type="button" className="neu-btn-sm danger" onClick={() => setRejectModal({ orderId: o.id, targetStatus: 'rejected' })}>Reject</button>
                        </>
                      )}
                      {isAdmin && o.status === 'approved' && <button type="button" className="neu-btn-sm primary" onClick={() => updateOrderStatus(o.id, 'processing')}>Process</button>}
                      {isAdmin && o.status === 'processing' && <button type="button" className="neu-btn-sm primary" onClick={() => updateOrderStatus(o.id, 'ready_shipped')}>Ship</button>}
                      {isAdmin && o.status === 'ready_shipped' && <button type="button" className="neu-btn-sm primary" onClick={() => updateOrderStatus(o.id, 'delivered')}>Deliver</button>}
                      {isAdmin && o.status !== 'delivered' && o.status !== 'cancelled' && o.status !== 'rejected' && (
                        <button type="button" className="neu-btn-sm danger" onClick={() => setRejectModal({ orderId: o.id, targetStatus: 'cancelled' })}>Cancel</button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </>
      )}

      {/* New Return Claim Modal */}
      {showClaimModal && (
        <div className="modal-backdrop">
          <div className="modal-box">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700 }}>Submit Return / Damage Claim</h3>
              <button type="button" className="neu-btn-sm" onClick={() => setShowClaimModal(false)}>Close</button>
            </div>
            <form onSubmit={handleSubmitClaim}>
              <ElectricSelect id="cl-cust" label="Customer" value={claimCustId} onChange={(e) => setClaimCustId(e.target.value)} required>
                {customers.map((c) => <option key={c.id} value={c.id}>{c.shop_name}</option>)}
              </ElectricSelect>
              <ElectricSelect id="cl-prod" label="Product" value={claimProdId} onChange={(e) => setClaimProdId(e.target.value)} required>
                {products.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.sku})</option>)}
              </ElectricSelect>
              <ElectricInput id="cl-qty" type="number" label="Quantity" value={claimQty} onChange={(e) => setClaimQty(Number(e.target.value))} required />
              <ElectricSelect id="cl-type" label="Claim Type" value={claimType} onChange={(e) => setClaimType(e.target.value as typeof claimType)}>
                <option value="damaged">Damaged / Warranty</option>
                <option value="wrong_item">Wrong Item</option>
                <option value="other">Other</option>
              </ElectricSelect>
              <ElectricInput id="cl-adj" type="number" label="Credit Adjustment Amount (BDT)" value={claimAdj} onChange={(e) => setClaimAdj(Number(e.target.value))} />
              <ElectricInput id="cl-reason" label="Reason / Details" value={claimReason} onChange={(e) => setClaimReason(e.target.value)} required />
              <button type="submit" className="main-btn">SUBMIT CLAIM</button>
            </form>
          </div>
        </div>
      )}

      {rejectModal && (
        <div className="modal-backdrop">
          <div className="modal-box">
            <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12 }}>Provide Reason to {rejectModal.targetStatus}</h3>
            <ElectricInput id="rej-reason" label="Reason" value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} required />
            <div style={{ display: 'flex', gap: 10 }}>
              <button type="button" className="neu-btn-sm primary" onClick={async () => { await updateOrderStatus(rejectModal.orderId, rejectModal.targetStatus, rejectReason); setRejectModal(null); setRejectReason(''); }}>Confirm</button>
              <button type="button" className="neu-btn-sm" onClick={() => setRejectModal(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Invoice Preview (Standard A4/PDF + 58mm Thermal POS Mode) */}
      {invoiceOrder && (
        <div className="modal-backdrop">
          <div className="modal-box print-only-area" style={{ width: thermalMode ? 310 : 680, position: 'relative', overflow: 'hidden' }}>
            <div
              aria-hidden="true"
              style={{
                position: 'absolute',
                inset: 0,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                pointerEvents: 'none',
                zIndex: 0,
              }}
            >
              <img
                src="/logo.jpg"
                alt=""
                style={{ width: thermalMode ? 180 : 320, maxWidth: '75%', opacity: 0.08, objectFit: 'contain' }}
              />
            </div>
            <div style={{ position: 'relative', zIndex: 1 }}>
            <div className="no-print" style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14, flexWrap: 'wrap', gap: 8 }}>
              <div style={{ display: 'flex', gap: 6 }}>
                <button type="button" className={`neu-btn-sm ${!thermalMode ? 'primary' : ''}`} onClick={() => setThermalMode(false)}>A4 / PDF</button>
                <button type="button" className={`neu-btn-sm ${thermalMode ? 'primary' : ''}`} onClick={() => setThermalMode(true)}>58mm Thermal</button>
              </div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                <button type="button" className="neu-btn-sm" onClick={() => handleSaveMemoFile(invoiceOrder)}><Download size={14} /> Save File</button>
                <button type="button" className="neu-btn-sm primary" onClick={() => window.print()}><Printer size={14} /> Print / PDF</button>
                <button type="button" className="neu-btn-sm" onClick={() => setInvoiceOrder(null)}>Close</button>
              </div>
            </div>

            <div style={{ borderBottom: '2px solid var(--blue)', paddingBottom: 10, marginBottom: 10 }}>
              <h2 style={{ fontSize: thermalMode ? 16 : 20, fontWeight: 800, color: 'var(--blue)' }}>
                {businessSettings?.business_name || 'Auto Choice BD'}
              </h2>
              <p style={{ fontSize: 11 }}>{businessSettings?.tagline}</p>
              {businessSettings?.phone && <p style={{ fontSize: 11 }}>Tel: {businessSettings.phone}</p>}
              <div style={{ fontWeight: 700, fontSize: 13, marginTop: 6 }}>INVOICE #{invoiceOrder.order_number}</div>
              <div style={{ fontSize: 11 }}>{new Date(invoiceOrder.created_at).toLocaleString()}</div>
            </div>

            <div style={{ fontSize: 12, marginBottom: 10 }}>
              <strong>{invoiceOrder.customers?.shop_name}</strong> ({invoiceOrder.customers?.phone})<br />
              <span>SR: {invoiceOrder.profiles?.full_name}</span>
            </div>

            <table className="data-table" style={{ marginBottom: 12, fontSize: thermalMode ? 11 : 13 }}>
              <thead>
                <tr><th>Item</th><th>Qty</th><th>Rate</th><th>Total</th></tr>
              </thead>
              <tbody>
                {(invoiceOrder.order_items || []).map((item) => (
                  <tr key={item.id}>
                    <td>{item.product_name_snapshot}</td>
                    <td>{item.quantity}</td>
                    <td>{formatBDT(item.unit_price)}</td>
                    <td>{formatBDT(item.line_total)}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div style={{ textAlign: 'right', fontSize: 12.5 }}>
              <div>Subtotal: {formatBDT(invoiceOrder.subtotal)}</div>
              {Number(invoiceOrder.discount_amount) > 0 && <div>Discount: -{formatBDT(invoiceOrder.discount_amount)}</div>}
              {Number(invoiceOrder.delivery_charge) > 0 && <div>Delivery: {formatBDT(invoiceOrder.delivery_charge)}</div>}
              <div style={{ fontSize: 15, fontWeight: 800, color: 'var(--blue)', marginTop: 4 }}>
                Grand Total: {formatBDT(invoiceOrder.grand_total)}
              </div>
              <div>Paid: {formatBDT(invoiceOrder.paid_amount)}</div>
              <div style={{ fontWeight: 700 }}>
                Due: {formatBDT(Math.max(0, Number(invoiceOrder.grand_total) - Number(invoiceOrder.paid_amount)))}
              </div>
            </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
