import React, { useEffect, useState } from 'react';
import { Plus, Printer, RotateCcw, Share2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { loadLocalCache, saveLocalCache } from '../lib/localCache';
import { useRealtimeSync } from '../lib/useRealtimeSync';
import { useAuth } from '../context/AuthContext';
import { formatBDT } from '../lib/i18n';
import { Customer, Order, Payment, PaymentMethod } from '../types/database';
import { enqueueOfflineMutation } from '../lib/offlineQueue';
import { shareViaWhatsApp } from '../lib/exportUtils';
import { ElectricInput, ElectricSelect } from '../components/ElectricInput';

export function PaymentsPage({ onToast }: { onToast: (msg: string) => void }) {
  const { profile, businessSettings } = useAuth();
  const isAdmin = profile?.role === 'admin';

  const [payments, setPayments] = useState<Payment[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [showAdd, setShowAdd] = useState(false);

  const [customerId, setCustomerId] = useState('');
  const [orderId, setOrderId] = useState('');
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState<PaymentMethod>('cash');
  const [referenceNo, setReferenceNo] = useState('');
  const [notes, setNotes] = useState('');
  const [receiptPayment, setReceiptPayment] = useState<Payment | null>(null);
  const [thermalMode, setThermalMode] = useState(false);
  const [reversingId, setReversingId] = useState<string | null>(null);
  const [reversalReason, setReversalReason] = useState('');

  const loadData = async () => {
    const [pRes, cRes, oRes] = await Promise.all([
      supabase.from('payments').select('*, customers(shop_name, phone), orders(order_number), profiles(full_name)').order('payment_date', { ascending: false }),
      supabase.from('customers').select('*').eq('status', 'active').order('shop_name'),
      supabase.from('orders').select('*').neq('payment_status', 'paid').order('created_at', { ascending: false }),
    ]);
    if (pRes.data) saveLocalCache('payments', pRes.data);
    if (cRes.data) saveLocalCache('customers', cRes.data);
    if (oRes.data) saveLocalCache('orders', oRes.data);
    setPayments(pRes.data ? (pRes.data as Payment[]) : loadLocalCache<Payment[]>('payments', []));
    const cList = cRes.data ? (cRes.data as Customer[]) : loadLocalCache<Customer[]>('customers', []);
    setCustomers(cList);
    if (!customerId && cList.length > 0) setCustomerId(cList[0].id);
    setOrders(oRes.data ? (oRes.data as Order[]) : loadLocalCache<Order[]>('orders', []));
  };

  useEffect(() => {
    loadData();
  }, []);

  useRealtimeSync(['payments', 'orders'], loadData);

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!profile || !customerId) return;
    const amt = Number(amount);
    if (amt <= 0) {
      onToast('Payment amount must be greater than 0.');
      return;
    }

    const idempotencyKey = crypto.randomUUID();
    const payload = {
      receipt_number: '',
      customer_id: customerId,
      order_id: orderId || null,
      sr_id: profile.id,
      amount: amt,
      method,
      reference_no: referenceNo.trim(),
      notes: notes.trim(),
      entered_by: profile.id,
      idempotency_key: idempotencyKey,
    };

    if (!navigator.onLine) {
      enqueueOfflineMutation(profile.id, 'record_payment', payload, idempotencyKey);
      setShowAdd(false);
      setAmount('');
      setReferenceNo('');
      setNotes('');
      onToast('Offline: Payment queued locally (not yet synced to cloud).');
      return;
    }

    const { error } = await supabase.from('payments').insert(payload);
    if (error) {
      onToast(error.message);
      return;
    }

    setShowAdd(false);
    setAmount('');
    setReferenceNo('');
    setNotes('');
    await loadData();
    onToast('Payment recorded & receipt generated.');
  };

  const handleReverse = async () => {
    if (!isAdmin || !reversingId || !reversalReason.trim()) return;
    const { error } = await supabase
      .from('payments')
      .update({
        is_reversed: true,
        reversed_at: new Date().toISOString(),
        reversed_by: profile?.id,
        reversal_reason: reversalReason.trim(),
      })
      .eq('id', reversingId);

    if (error) {
      onToast(error.message);
      return;
    }
    await supabase.from('audit_logs').insert({
      actor_id: profile?.id,
      actor_role: 'admin',
      action: 'payment_reversed',
      entity_type: 'payment',
      entity_id: reversingId,
      details: { reason: reversalReason.trim() },
    });

    setReversingId(null);
    setReversalReason('');
    await loadData();
    onToast('Payment reversed with audit trail preserved.');
  };

  const customerOrders = orders.filter((o) => o.customer_id === customerId);

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, flexWrap: 'wrap', gap: 10 }}>
        <h2 style={{ fontSize: 18, fontWeight: 700 }}>Payments, Dues & Collections</h2>
        <button type="button" className="neu-btn-sm primary" onClick={() => setShowAdd(true)}>
          <Plus size={14} /> Record Payment
        </button>
      </div>

      <div className="stack-list">
        {payments.length === 0 ? (
          <div className="neu-card" style={{ textAlign: 'center', color: 'var(--muted)' }}>No payments recorded yet.</div>
        ) : (
          payments.map((p) => (
            <div key={p.id} className="list-row">
              <div>
                <div style={{ fontWeight: 700, fontSize: 14 }}>
                  {p.receipt_number} • {p.customers?.shop_name}
                  {p.is_reversed && <span className="status-pill st-bad" style={{ marginLeft: 8 }}>REVERSED</span>}
                </div>
                <div style={{ fontSize: 11.5, color: 'var(--muted)' }}>
                  {new Date(p.payment_date).toLocaleString()} • Method: {p.method.toUpperCase()}
                  {p.orders?.order_number ? ` • Order: ${p.orders.order_number}` : ' • General/Advance'}
                  {p.reference_no ? ` • Ref: ${p.reference_no}` : ''}
                </div>
                {p.reversal_reason && <div style={{ fontSize: 11.5, color: 'var(--danger)' }}>Reversal Reason: {p.reversal_reason}</div>}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontWeight: 800, fontSize: 16, color: p.is_reversed ? 'var(--muted)' : 'var(--success)' }}>
                  {formatBDT(p.amount)}
                </span>
                <button type="button" className="neu-btn-sm" onClick={() => { setThermalMode(false); setReceiptPayment(p); }}>
                  <Printer size={13} /> Receipt
                </button>
                <button
                  type="button"
                  className="neu-btn-sm"
                  onClick={() =>
                    shareViaWhatsApp(
                      p.customers?.phone,
                      `*${businessSettings?.business_name || 'Auto Choice BD'}*\nReceipt: ${p.receipt_number}\nShop: ${p.customers?.shop_name}\nAmount: ${formatBDT(p.amount)}\nMethod: ${p.method.toUpperCase()}`
                    )
                  }
                >
                  <Share2 size={13} />
                </button>
                {isAdmin && !p.is_reversed && (
                  <button type="button" className="neu-btn-sm danger" onClick={() => setReversingId(p.id)}>
                    <RotateCcw size={13} /> Reverse
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {showAdd && (
        <div className="modal-backdrop">
          <div className="modal-box">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700 }}>Record Payment Collection</h3>
              <button type="button" className="neu-btn-sm" onClick={() => setShowAdd(false)}>Close</button>
            </div>
            <form onSubmit={handleRecordPayment}>
              <ElectricSelect id="pay-cust" label="Customer" value={customerId} onChange={(e) => setCustomerId(e.target.value)} required>
                {customers.map((c) => <option key={c.id} value={c.id}>{c.shop_name} ({c.phone})</option>)}
              </ElectricSelect>
              <ElectricSelect id="pay-ord" label="Apply to Order (Optional)" value={orderId} onChange={(e) => setOrderId(e.target.value)}>
                <option value="">General / Advance Collection</option>
                {customerOrders.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.order_number} (Due: {formatBDT(Math.max(0, Number(o.grand_total) - Number(o.paid_amount)))})
                  </option>
                ))}
              </ElectricSelect>
              <ElectricInput id="pay-amt" type="number" step="0.01" label="Amount (BDT)" value={amount} onChange={(e) => setAmount(e.target.value)} required />
              <ElectricSelect id="pay-method" label="Payment Method" value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
                <option value="cash">Cash</option>
                <option value="mfs">Mobile Financial Service (bKash/Nagad/Rocket)</option>
                <option value="bank_transfer">Bank Transfer</option>
              </ElectricSelect>
              <ElectricInput id="pay-ref" label="Reference / TrxID (Optional)" value={referenceNo} onChange={(e) => setReferenceNo(e.target.value)} />
              <ElectricInput id="pay-notes" label="Notes" value={notes} onChange={(e) => setNotes(e.target.value)} />
              <button type="submit" className="main-btn">SAVE PAYMENT</button>
            </form>
          </div>
        </div>
      )}

      {reversingId && (
        <div className="modal-backdrop">
          <div className="modal-box">
            <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 10 }}>Reverse Payment Record</h3>
            <p style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 12 }}>
              Original financial records are never deleted. Enter a reason for this reversal:
            </p>
            <ElectricInput id="rev-reason" label="Reversal Reason" value={reversalReason} onChange={(e) => setReversalReason(e.target.value)} required />
            <div style={{ display: 'flex', gap: 10 }}>
              <button type="button" className="neu-btn-sm primary" onClick={handleReverse}>Confirm Reversal</button>
              <button type="button" className="neu-btn-sm" onClick={() => setReversingId(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {receiptPayment && (
        <div className="modal-backdrop">
          <div className="modal-box print-only-area" style={{ width: thermalMode ? 300 : 460 }}>
            <div className="no-print" style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12, flexWrap: 'wrap', gap: 8 }}>
              <div style={{ display: 'flex', gap: 6 }}>
                <button type="button" className={`neu-btn-sm ${!thermalMode ? 'primary' : ''}`} onClick={() => setThermalMode(false)}>Standard</button>
                <button type="button" className={`neu-btn-sm ${thermalMode ? 'primary' : ''}`} onClick={() => setThermalMode(true)}>58mm Thermal</button>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button type="button" className="neu-btn-sm primary" onClick={() => window.print()}>Print / PDF</button>
                <button type="button" className="neu-btn-sm" onClick={() => setReceiptPayment(null)}>Close</button>
              </div>
            </div>
            <h2 style={{ color: 'var(--blue)', fontWeight: 800, fontSize: thermalMode ? 16 : 20 }}>
              {businessSettings?.business_name || 'Auto Choice BD'}
            </h2>
            <p style={{ fontSize: 12, marginBottom: 12 }}>Receipt #{receiptPayment.receipt_number}</p>
            <div className="neu-inset" style={{ padding: 14, fontSize: thermalMode ? 12 : 13 }}>
              <div>Customer: <strong>{receiptPayment.customers?.shop_name}</strong></div>
              <div>Date: {new Date(receiptPayment.payment_date).toLocaleString()}</div>
              <div>Method: {receiptPayment.method.toUpperCase()}</div>
              {receiptPayment.reference_no && <div>Ref: {receiptPayment.reference_no}</div>}
              <div style={{ fontSize: thermalMode ? 15 : 18, fontWeight: 800, color: 'var(--success)', marginTop: 8 }}>
                Amount Received: {formatBDT(receiptPayment.amount)}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
