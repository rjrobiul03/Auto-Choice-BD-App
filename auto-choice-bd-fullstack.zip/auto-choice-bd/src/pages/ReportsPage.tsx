import React, { useEffect, useState } from 'react';
import { Download, Printer } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { formatBDT } from '../lib/i18n';
import { exportToCSV, exportToExcelTable } from '../lib/exportUtils';
import { AuditLog, Order, Payment, Product } from '../types/database';

type ReportType = 'orders' | 'collections' | 'manual_stock' | 'low_stock' | 'price_history' | 'audit_logs';

export function ReportsPage() {
  const { profile, businessSettings } = useAuth();
  const isAdmin = profile?.role === 'admin';

  const [reportType, setReportType] = useState<ReportType>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [priceHistory, setPriceHistory] = useState<Array<{ id: string; old_price: number; new_price: number; changed_at: string; products?: { name: string; sku: string } }>>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  useEffect(() => {
    async function load() {
      const [oRes, pRes, prRes] = await Promise.all([
        supabase.from('orders').select('*, customers(shop_name), profiles(full_name)').order('created_at', { ascending: false }),
        supabase.from('payments').select('*, customers(shop_name), profiles(full_name)').order('payment_date', { ascending: false }),
        supabase.from('products').select('*').order('name'),
      ]);
      setOrders((oRes.data as Order[]) || []);
      setPayments((pRes.data as Payment[]) || []);
      setProducts((prRes.data as Product[]) || []);

      if (isAdmin) {
        const [phRes, alRes] = await Promise.all([
          supabase.from('price_history').select('*, products(name, sku)').order('changed_at', { ascending: false }).limit(100),
          supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(150),
        ]);
        setPriceHistory(phRes.data || []);
        setAuditLogs((alRes.data as AuditLog[]) || []);
      }
    }
    load();
  }, [isAdmin]);

  const lowThreshold = businessSettings?.low_stock_threshold ?? 8;

  const getTableData = (): { title: string; headers: string[]; rows: (string | number)[][] } => {
    switch (reportType) {
      case 'orders':
        return {
          title: 'Order Report',
          headers: ['Order No', 'Date', 'Customer', 'SR', 'Status', 'Grand Total', 'Paid', 'Due'],
          rows: orders.map((o) => [
            o.order_number,
            new Date(o.created_at).toLocaleDateString(),
            o.customers?.shop_name || '',
            o.profiles?.full_name || '',
            o.status,
            o.grand_total,
            o.paid_amount,
            Math.max(0, Number(o.grand_total) - Number(o.paid_amount)),
          ]),
        };
      case 'collections':
        return {
          title: 'Payment Collection Report',
          headers: ['Receipt No', 'Date', 'Customer', 'SR', 'Method', 'Amount', 'Status'],
          rows: payments.map((p) => [
            p.receipt_number,
            new Date(p.payment_date).toLocaleDateString(),
            p.customers?.shop_name || '',
            p.profiles?.full_name || '',
            p.method,
            p.amount,
            p.is_reversed ? 'REVERSED' : 'VALID',
          ]),
        };
      case 'manual_stock':
        return {
          title: 'Manually Entered Stock Report',
          headers: ['SKU', 'Product', 'Brand', 'Position', 'Selling Price', 'Manual Stock', 'Active'],
          rows: products.map((p) => [
            p.sku, p.name, p.brand, p.position_application, p.selling_price, p.stock_quantity, p.is_active ? 'Yes' : 'No',
          ]),
        };
      case 'low_stock':
        return {
          title: `Low Manual Stock (<= ${lowThreshold})`,
          headers: ['SKU', 'Product', 'Brand', 'Manual Stock', 'Selling Price'],
          rows: products
            .filter((p) => p.stock_quantity <= lowThreshold)
            .map((p) => [p.sku, p.name, p.brand, p.stock_quantity, p.selling_price]),
        };
      case 'price_history':
        return {
          title: 'Price Change History',
          headers: ['Date', 'SKU', 'Product', 'Old Price', 'New Price'],
          rows: priceHistory.map((h) => [
            new Date(h.changed_at).toLocaleString(),
            h.products?.sku || '',
            h.products?.name || '',
            h.old_price,
            h.new_price,
          ]),
        };
      case 'audit_logs':
        return {
          title: 'Security & Activity Audit Logs',
          headers: ['Timestamp', 'Action', 'Entity', 'Actor Role', 'Details'],
          rows: auditLogs.map((a) => [
            new Date(a.created_at).toLocaleString(),
            a.action,
            `${a.entity_type}:${a.entity_id || ''}`,
            a.actor_role || '',
            JSON.stringify(a.details),
          ]),
        };
    }
  };

  const { title, headers, rows } = getTableData();

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, flexWrap: 'wrap', gap: 10 }}>
        <h2 style={{ fontSize: 18, fontWeight: 700 }}>Business Reports & Exports</h2>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button type="button" className="neu-btn-sm" onClick={() => exportToCSV(`acbd_${reportType}`, headers, rows)}>
            <Download size={13} /> CSV
          </button>
          <button type="button" className="neu-btn-sm" onClick={() => exportToExcelTable(`acbd_${reportType}`, headers, rows)}>
            <Download size={13} /> Excel (.xls)
          </button>
          <button type="button" className="neu-btn-sm primary" onClick={() => window.print()}>
            <Printer size={13} /> Print / PDF
          </button>
        </div>
      </div>

      <div className="chip-row">
        <button type="button" className={`chip ${reportType === 'orders' ? 'active' : ''}`} onClick={() => setReportType('orders')}>Orders</button>
        <button type="button" className={`chip ${reportType === 'collections' ? 'active' : ''}`} onClick={() => setReportType('collections')}>Collections</button>
        <button type="button" className={`chip ${reportType === 'manual_stock' ? 'active' : ''}`} onClick={() => setReportType('manual_stock')}>Manual Stock</button>
        <button type="button" className={`chip ${reportType === 'low_stock' ? 'active' : ''}`} onClick={() => setReportType('low_stock')}>Low Stock</button>
        {isAdmin && (
          <>
            <button type="button" className={`chip ${reportType === 'price_history' ? 'active' : ''}`} onClick={() => setReportType('price_history')}>Price History</button>
            <button type="button" className={`chip ${reportType === 'audit_logs' ? 'active' : ''}`} onClick={() => setReportType('audit_logs')}>Audit Logs</button>
          </>
        )}
      </div>

      <div className="neu-card print-only-area" style={{ overflowX: 'auto' }}>
        <h3 style={{ fontSize: 15, fontWeight: 700, marginBottom: 10 }}>{title} ({rows.length} rows)</h3>
        {rows.length === 0 ? (
          <p style={{ fontSize: 12.5, color: 'var(--muted)' }}>No records to display.</p>
        ) : (
          <table className="data-table">
            <thead>
              <tr>{headers.map((h) => <th key={h}>{h}</th>)}</tr>
            </thead>
            <tbody>
              {rows.slice(0, 100).map((r, i) => (
                <tr key={i}>
                  {r.map((cell, j) => (
                    <td key={j}>
                      {typeof cell === 'number' && (headers[j].includes('Price') || headers[j].includes('Total') || headers[j].includes('Paid') || headers[j].includes('Due') || headers[j].includes('Amount'))
                        ? formatBDT(cell)
                        : String(cell)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
