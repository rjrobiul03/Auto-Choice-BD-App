import React, { useEffect, useState } from 'react';
import { RefreshCw, Bell, Building2, Globe, Moon, Sun, Megaphone, Share2, Upload } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { getOfflineQueue, QueuedMutation, syncOfflineQueue } from '../lib/offlineQueue';
import { ChangePasswordPanel } from '../components/ChangePasswordPanel';
import { ElectricInput } from '../components/ElectricInput';
import { Announcement, NotificationItem } from '../types/database';

interface SettingsPageProps {
  theme: 'light' | 'dark';
  setTheme: (t: 'light' | 'dark') => void;
  lang: 'en' | 'bn';
  setLang: (l: 'en' | 'bn') => void;
  onToast: (msg: string) => void;
}

export function SettingsPage({ theme, setTheme, lang, setLang, onToast }: SettingsPageProps) {
  const { profile, businessSettings, refreshProfile, refreshSettings } = useAuth();
  const isAdmin = profile?.role === 'admin';

  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [annTitle, setAnnTitle] = useState('');
  const [annMsg, setAnnMsg] = useState('');
  const [pendingQueueCount, setPendingQueueCount] = useState(0);
  const [syncing, setSyncing] = useState(false);

  const [bizName, setBizName] = useState(businessSettings?.business_name || 'Auto Choice BD');
  const [bizPhone, setBizPhone] = useState(businessSettings?.phone || '');
  const [bizWhatsapp, setBizWhatsapp] = useState(businessSettings?.whatsapp || '');
  const [bizAddress, setBizAddress] = useState(businessSettings?.address || '');
  const [bizFooter, setBizFooter] = useState(businessSettings?.invoice_footer_note || '');

  const loadExtras = async () => {
    if (!profile) return;
    setPendingQueueCount(getOfflineQueue(profile.id).length);
    const [nRes, aRes] = await Promise.all([
      supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(20),
      supabase.from('announcements').select('*').order('created_at', { ascending: false }).limit(10),
    ]);
    setNotifications((nRes.data as NotificationItem[]) || []);
    setAnnouncements((aRes.data as Announcement[]) || []);
  };

  useEffect(() => {
    loadExtras();
  }, [profile]);

  const handleSavePrefs = async (newTheme: 'light' | 'dark', newLang: 'en' | 'bn') => {
    setTheme(newTheme);
    setLang(newLang);
    if (profile) {
      await supabase.from('profiles').update({ theme: newTheme, language: newLang }).eq('id', profile.id);
      await refreshProfile();
    }
  };

  const handleSaveBusiness = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    const { error } = await supabase
      .from('business_settings')
      .update({
        business_name: bizName.trim(),
        phone: bizPhone.trim(),
        whatsapp: bizWhatsapp.trim(),
        address: bizAddress.trim(),
        invoice_footer_note: bizFooter.trim(),
        updated_at: new Date().toISOString(),
        updated_by: profile?.id,
      })
      .eq('id', 1);

    if (error) {
      onToast(error.message);
      return;
    }
    await refreshSettings();
    onToast('Business settings saved.');
  };

  const handlePostAnnouncement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin || !annTitle.trim() || !annMsg.trim()) return;
    const { error } = await supabase.from('announcements').insert({
      title: annTitle.trim(),
      message: annMsg.trim(),
      is_active: true,
      created_by: profile?.id,
    });
    if (error) {
      onToast(error.message);
      return;
    }
    setAnnTitle('');
    setAnnMsg('');
    await loadExtras();
    onToast('Broadcast notice published!');
  };

  const toggleAnnouncement = async (ann: Announcement) => {
    if (!isAdmin) return;
    await supabase.from('announcements').update({ is_active: !ann.is_active }).eq('id', ann.id);
    await loadExtras();
  };

  const handleExportTransferPackage = async () => {
    if (!profile) return;
    const queue = getOfflineQueue(profile.id);
    const payload = {
      app: 'Auto Choice BD',
      exportedAt: new Date().toISOString(),
      exportedBy: profile.email,
      queue,
    };
    const jsonStr = JSON.stringify(payload, null, 2);
    const file = new File([jsonStr], `acbd-offline-transfer-${Date.now()}.json`, { type: 'application/json' });

    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      try {
        await navigator.share({
          title: 'Auto Choice BD Offline Transfer',
          text: `${queue.length} queued offline update(s)`,
          files: [file],
        });
        onToast('Transfer file shared!');
        return;
      } catch {
        // Fallback to download
      }
    }
    const url = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.name;
    a.click();
    URL.revokeObjectURL(url);
    onToast(`Exported ${queue.length} queued item(s) for offline transfer.`);
  };

  const handleImportTransferPackage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !profile) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result || '{}'));
        const incoming = (parsed.queue || []) as QueuedMutation[];
        if (!Array.isArray(incoming)) throw new Error('Invalid transfer file');
        const current = getOfflineQueue(profile.id);
        const existingKeys = new Set(current.map((q) => q.idempotencyKey));
        let added = 0;
        for (const item of incoming) {
          if (item.idempotencyKey && !existingKeys.has(item.idempotencyKey)) {
            current.push({ ...item, userId: profile.id, status: 'queued' });
            existingKeys.add(item.idempotencyKey);
            added++;
          }
        }
        localStorage.setItem(`acbd_offline_queue_${profile.id}`, JSON.stringify(current));
        setPendingQueueCount(current.length);
        onToast(`Imported ${added} new offline update(s). Sync when online.`);
      } catch {
        onToast('Invalid offline transfer file.');
      }
    };
    reader.readAsText(file);
  };

  const handleManualSync = async () => {
    if (!profile) return;
    if (!navigator.onLine) {
      onToast('Device is offline. Cannot sync until internet connection returns.');
      return;
    }
    setSyncing(true);
    const { syncedCount, failedCount } = await syncOfflineQueue(profile.id);
    setPendingQueueCount(getOfflineQueue(profile.id).length);
    setSyncing(false);
    onToast(`Sync complete: ${syncedCount} synced, ${failedCount} failed.`);
  };

  const markAllRead = async () => {
    await supabase.from('notifications').update({ is_read: true }).eq('is_read', false);
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
    onToast('Notifications marked as read.');
  };

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 18 }}>
      <div className="neu-card">
        <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 10 }}>My Profile & Appearance</h3>
        <div className="neu-inset" style={{ padding: 12, marginBottom: 14, fontSize: 12.5 }}>
          <div><strong>{profile?.full_name}</strong> ({profile?.role.toUpperCase()})</div>
          <div style={{ color: 'var(--muted)' }}>{profile?.email}</div>
          {profile?.zone && <div style={{ color: 'var(--muted)' }}>Zone: {profile.zone}</div>}
        </div>

        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 14 }}>
          <button type="button" className={`neu-btn-sm ${theme === 'light' ? 'primary' : ''}`} onClick={() => handleSavePrefs('light', lang)}>
            <Sun size={14} /> Light Theme
          </button>
          <button type="button" className={`neu-btn-sm ${theme === 'dark' ? 'primary' : ''}`} onClick={() => handleSavePrefs('dark', lang)}>
            <Moon size={14} /> Dark Theme
          </button>
        </div>

        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <button type="button" className={`neu-btn-sm ${lang === 'en' ? 'primary' : ''}`} onClick={() => handleSavePrefs(theme, 'en')}>
            <Globe size={14} /> English
          </button>
          <button type="button" className={`neu-btn-sm ${lang === 'bn' ? 'primary' : ''}`} onClick={() => handleSavePrefs(theme, 'bn')}>
            <Globe size={14} /> বাংলা (Bengali)
          </button>
        </div>
      </div>

      <ChangePasswordPanel onSuccess={onToast} />

      <div className="neu-card">
        <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 10 }}>Cloud Sync & Offline Transfer</h3>
        <div className="neu-inset" style={{ padding: 12, marginBottom: 14, fontSize: 12.5 }}>
          <div>Network: <strong style={{ color: navigator.onLine ? 'var(--success)' : 'var(--warning)' }}>{navigator.onLine ? 'Online' : 'Offline'}</strong></div>
          <div>Queued Offline Changes: <strong>{pendingQueueCount}</strong></div>
        </div>
        <button type="button" className="main-btn" onClick={handleManualSync} disabled={syncing} style={{ marginBottom: 12 }}>
          <RefreshCw size={15} /> {syncing ? 'SYNCING...' : 'SYNC NOW'}
        </button>
        <p style={{ fontSize: 11.5, color: 'var(--muted)', marginBottom: 8 }}>
          Offline Device Transfer (share via Android Nearby Share / Wi-Fi / Hotspot file):
        </p>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button type="button" className="neu-btn-sm" onClick={handleExportTransferPackage}>
            <Share2 size={13} /> Export & Share Updates
          </button>
          <label className="neu-btn-sm" style={{ cursor: 'pointer' }}>
            <Upload size={13} /> Import Updates
            <input type="file" accept=".json" onChange={handleImportTransferPackage} style={{ display: 'none' }} />
          </label>
        </div>
      </div>

      <div className="neu-card">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6 }}>
            <Bell size={16} /> Notifications
          </h3>
          <button type="button" className="neu-btn-sm" onClick={markAllRead}>Mark Read</button>
        </div>
        <div className="stack-list">
          {notifications.length === 0 ? (
            <p style={{ fontSize: 12.5, color: 'var(--muted)' }}>No notifications.</p>
          ) : (
            notifications.slice(0, 6).map((n) => (
              <div key={n.id} className="neu-inset" style={{ padding: '8px 12px', fontSize: 12, opacity: n.is_read ? 0.65 : 1 }}>
                <strong>{n.title}</strong>: {n.message}
              </div>
            ))
          )}
        </div>
      </div>

      {isAdmin && (
        <div className="neu-card">
          <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
            <Megaphone size={16} /> Broadcast Notice / Offer Banner
          </h3>
          <form onSubmit={handlePostAnnouncement} style={{ marginBottom: 12 }}>
            <ElectricInput id="ann-title" label="Notice Title" value={annTitle} onChange={(e) => setAnnTitle(e.target.value)} required />
            <ElectricInput id="ann-msg" label="Offer / Notice Message" value={annMsg} onChange={(e) => setAnnMsg(e.target.value)} required />
            <button type="submit" className="main-btn">PUBLISH NOTICE</button>
          </form>
          <div className="stack-list">
            {announcements.map((a) => (
              <div key={a.id} className="neu-inset" style={{ padding: '8px 12px', fontSize: 12, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span><strong>{a.title}</strong>: {a.message}</span>
                <button type="button" className="neu-btn-sm" onClick={() => toggleAnnouncement(a)}>
                  {a.is_active ? 'Hide' : 'Show'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {isAdmin && (
        <div className="neu-card">
          <h3 style={{ fontSize: 16, fontWeight: 700, marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
            <Building2 size={16} /> Business Details (Invoices & Branding)
          </h3>
          <form onSubmit={handleSaveBusiness}>
            <ElectricInput id="bz-name" label="Business Name" value={bizName} onChange={(e) => setBizName(e.target.value)} required />
            <ElectricInput id="bz-phone" label="Contact Phone" value={bizPhone} onChange={(e) => setBizPhone(e.target.value)} />
            <ElectricInput id="bz-wa" label="WhatsApp Number" value={bizWhatsapp} onChange={(e) => setBizWhatsapp(e.target.value)} />
            <ElectricInput id="bz-addr" label="Business Address" value={bizAddress} onChange={(e) => setBizAddress(e.target.value)} />
            <ElectricInput id="bz-foot" label="Invoice Footer Note" value={bizFooter} onChange={(e) => setBizFooter(e.target.value)} />
            <button type="submit" className="main-btn">SAVE BUSINESS DETAILS</button>
          </form>
        </div>
      )}
    </div>
  );
}
