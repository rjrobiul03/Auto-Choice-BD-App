import React, { useEffect, useState } from 'react';
import { KeyRound, UserPlus, PauseCircle, PlayCircle, Ban } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import { formatBDT } from '../lib/i18n';
import { Order, Payment, Profile } from '../types/database';
import { ElectricInput } from '../components/ElectricInput';

export function SrManagementPage({ onToast }: { onToast: (msg: string) => void }) {
  const { profile } = useAuth();
  const [srs, setSrs] = useState<Profile[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [showCreate, setShowCreate] = useState(false);

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [zone, setZone] = useState('');
  const [target, setTarget] = useState('0');
  const [commissionPct, setCommissionPct] = useState('0');
  const [createdCreds, setCreatedCreds] = useState<{ email: string; tempPwd: string } | null>(null);

  const [resetTarget, setResetTarget] = useState<Profile | null>(null);
  const [resetMode, setResetMode] = useState<'temporary_password' | 'email_link'>('temporary_password');
  const [resetResult, setResetResult] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const loadData = async () => {
    const [sRes, oRes, pRes] = await Promise.all([
      supabase.from('profiles').select('*').eq('role', 'sr').order('full_name'),
      supabase.from('orders').select('*').neq('status', 'cancelled').neq('status', 'rejected'),
      supabase.from('payments').select('*').eq('is_reversed', false),
    ]);
    setSrs((sRes.data as Profile[]) || []);
    setOrders((oRes.data as Order[]) || []);
    setPayments((pRes.data as Payment[]) || []);
  };

  useEffect(() => {
    loadData();
  }, []);

  if (profile?.role !== 'admin') {
    return <div className="neu-card">Access denied. Admin privileges required.</div>;
  }

  const handleCreateSr = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const { data, error } = await supabase.functions.invoke('admin-create-sr', {
      body: {
        full_name: fullName,
        email,
        phone,
        zone,
        monthly_sales_target: Number(target || 0),
        commission_rate_pct: Number(commissionPct || 0),
      },
    });
    setBusy(false);

    if (error || data?.error) {
      onToast(data?.error || error?.message || 'Failed to create SR');
      return;
    }

    setCreatedCreds({ email: data.email, tempPwd: data.temporary_password });
    setShowCreate(false);
    setFullName('');
    setEmail('');
    setPhone('');
    setZone('');
    await loadData();
    onToast('SR account created securely.');
  };

  const handleResetPassword = async () => {
    if (!resetTarget) return;
    setBusy(true);
    setResetResult(null);
    const { data, error } = await supabase.functions.invoke('admin-reset-sr-password', {
      body: { sr_id: resetTarget.id, mode: resetMode, redirect_to: window.location.origin },
    });
    setBusy(false);

    if (error || data?.error) {
      onToast(data?.error || error?.message || 'Reset failed');
      return;
    }

    if (data.mode === 'temporary_password') {
      setResetResult(
        `Temporary password issued: ${data.temporary_password} — Share securely with ${resetTarget.full_name}. They will be forced to change it on next login.`
      );
    } else {
      setResetResult(data.message || 'Password reset email sent.');
    }
    onToast('SR password reset completed and logged.');
  };

  const handleStatusChange = async (sr: Profile, status: 'active' | 'paused' | 'deactivated') => {
    const { data, error } = await supabase.functions.invoke('admin-update-sr-status', {
      body: { sr_id: sr.id, status },
    });
    if (error || data?.error) {
      onToast(data?.error || error?.message || 'Status update failed');
      return;
    }
    await loadData();
    onToast(`${sr.full_name} marked ${status}`);
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, flexWrap: 'wrap', gap: 10 }}>
        <h2 style={{ fontSize: 18, fontWeight: 700 }}>SR Management & Password Resets</h2>
        <button type="button" className="neu-btn-sm primary" onClick={() => setShowCreate(true)}>
          <UserPlus size={14} /> Create SR Account
        </button>
      </div>

      {createdCreds && (
        <div className="neu-card" style={{ marginBottom: 16, border: '1.5px solid var(--blue)' }}>
          <h4 style={{ fontSize: 14, fontWeight: 700, color: 'var(--blue)' }}>One-Time SR Credentials</h4>
          <p style={{ fontSize: 12.5, marginTop: 4 }}>
            Email: <strong>{createdCreds.email}</strong> • Temporary Password: <strong>{createdCreds.tempPwd}</strong>
          </p>
          <p style={{ fontSize: 11.5, color: 'var(--muted)', marginTop: 4 }}>
            The SR will be required to change this password on first login. Copy it now — it will not be shown again.
          </p>
          <button type="button" className="neu-btn-sm" style={{ marginTop: 8 }} onClick={() => setCreatedCreds(null)}>
            Dismiss
          </button>
        </div>
      )}

      <div className="stack-list">
        {srs.map((sr) => {
          const srOrders = orders.filter((o) => o.sr_id === sr.id);
          const srSales = srOrders.reduce((s, o) => s + Number(o.grand_total), 0);
          const srCollections = payments.filter((p) => p.sr_id === sr.id).reduce((s, p) => s + Number(p.amount), 0);
          const pct = sr.monthly_sales_target > 0 ? Math.min(100, Math.round((srSales / sr.monthly_sales_target) * 100)) : 0;

          return (
            <div key={sr.id} className="list-row">
              <div style={{ flex: 1, minWidth: 240 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontWeight: 700, fontSize: 15 }}>{sr.full_name}</span>
                  <span className={`status-pill ${sr.status === 'active' ? 'st-ok' : sr.status === 'paused' ? 'st-warn' : 'st-bad'}`}>
                    {sr.status}
                  </span>
                </div>
                <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                  {sr.email} • {sr.phone || 'No phone'} • Zone: {sr.zone || 'Unassigned'}
                </div>
                <div style={{ fontSize: 12, marginTop: 6 }}>
                  Orders: <strong>{srOrders.length}</strong> • Sales: <strong>{formatBDT(srSales)}</strong> •
                  Collected: <strong style={{ color: 'var(--success)' }}>{formatBDT(srCollections)}</strong> •
                  Target: {formatBDT(sr.monthly_sales_target)} ({pct}%)
                </div>
              </div>

              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                <button
                  type="button"
                  className="neu-btn-sm primary"
                  onClick={() => {
                    setResetTarget(sr);
                    setResetResult(null);
                  }}
                >
                  <KeyRound size={13} /> Reset Password
                </button>
                {sr.status !== 'active' && (
                  <button type="button" className="neu-btn-sm" onClick={() => handleStatusChange(sr, 'active')}>
                    <PlayCircle size={13} /> Activate
                  </button>
                )}
                {sr.status === 'active' && (
                  <button type="button" className="neu-btn-sm" onClick={() => handleStatusChange(sr, 'paused')}>
                    <PauseCircle size={13} /> Pause
                  </button>
                )}
                {sr.status !== 'deactivated' && (
                  <button type="button" className="neu-btn-sm danger" onClick={() => handleStatusChange(sr, 'deactivated')}>
                    <Ban size={13} /> Deactivate
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Create SR Modal */}
      {showCreate && (
        <div className="modal-backdrop">
          <div className="modal-box">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700 }}>Create SR Account</h3>
              <button type="button" className="neu-btn-sm" onClick={() => setShowCreate(false)}>Close</button>
            </div>
            <form onSubmit={handleCreateSr}>
              <ElectricInput id="sr-name" label="Full Name" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
              <ElectricInput id="sr-email" type="email" label="Email Address" value={email} onChange={(e) => setEmail(e.target.value)} required />
              <ElectricInput id="sr-phone" label="Phone Number" value={phone} onChange={(e) => setPhone(e.target.value)} />
              <ElectricInput id="sr-zone" label="Zone / Territory" value={zone} onChange={(e) => setZone(e.target.value)} />
              <ElectricInput id="sr-target" type="number" label="Monthly Sales Target (BDT)" value={target} onChange={(e) => setTarget(e.target.value)} />
              <ElectricInput id="sr-comm" type="number" step="0.1" label="Sales Commission % (Optional)" value={commissionPct} onChange={(e) => setCommissionPct(e.target.value)} />
              <button type="submit" className="main-btn" disabled={busy}>
                {busy ? 'CREATING...' : 'CREATE SR ACCOUNT'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Confirm SR Password Reset Modal */}
      {resetTarget && (
        <div className="modal-backdrop">
          <div className="modal-box">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 12 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700 }}>Reset SR Password</h3>
              <button type="button" className="neu-btn-sm" onClick={() => setResetTarget(null)}>Close</button>
            </div>
            <p style={{ fontSize: 12.5, marginBottom: 12 }}>
              Selected SR: <strong>{resetTarget.full_name}</strong> ({resetTarget.email})
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 14, fontSize: 12.5 }}>
              <label style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <input
                  type="radio"
                  checked={resetMode === 'temporary_password'}
                  onChange={() => setResetMode('temporary_password')}
                />
                Generate secure temporary password (forces SR to change on next login)
              </label>
              <label style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                <input
                  type="radio"
                  checked={resetMode === 'email_link'}
                  onChange={() => setResetMode('email_link')}
                />
                Send password reset link to SR&apos;s verified email
              </label>
            </div>

            {resetResult && (
              <div className="neu-inset" style={{ padding: 12, marginBottom: 14, fontSize: 12.5, color: 'var(--success)' }}>
                {resetResult}
              </div>
            )}

            <button type="button" className="main-btn" disabled={busy} onClick={handleResetPassword}>
              {busy ? 'PROCESSING...' : 'CONFIRM PASSWORD RESET'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
