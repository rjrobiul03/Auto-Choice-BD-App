export type UserRole = 'admin' | 'sr';
export type AccountStatus = 'active' | 'paused' | 'deactivated';
export type PriceTier = 'retail' | 'workshop' | 'dealer';
export type OrderStatus =
  | 'pending_review'
  | 'approved'
  | 'processing'
  | 'ready_shipped'
  | 'delivered'
  | 'rejected'
  | 'cancelled';
export type PaymentMethod = 'cash' | 'bank_transfer' | 'mfs';
export type PositionApplication =
  | 'Front'
  | 'Rear'
  | 'Engine'
  | 'Clutch'
  | 'Gearbox'
  | 'Electrical'
  | 'Body'
  | 'Other';

export interface Profile {
  id: string;
  full_name: string;
  email: string;
  phone: string | null;
  role: UserRole;
  status: AccountStatus;
  zone: string | null;
  monthly_sales_target: number;
  commission_rate_pct: number;
  must_change_password: boolean;
  can_view_stock: boolean;
  can_request_discount: boolean;
  language: 'en' | 'bn';
  theme: 'light' | 'dark';
  created_at: string;
}

export interface BusinessSettings {
  id: number;
  business_name: string;
  tagline: string;
  logo_url: string | null;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  invoice_footer_note: string;
  low_stock_threshold: number;
  password_min_length: number;
}

export interface Category {
  id: string;
  name: string;
  name_bn: string | null;
  is_active: boolean;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  barcode_qr: string | null;
  brand: string;
  category_id: string | null;
  compatible_brand: string | null;
  compatible_model: string | null;
  model_year_range: string | null;
  position_application: PositionApplication;
  selling_price: number;
  dealer_price: number | null;
  workshop_price: number | null;
  stock_quantity: number;
  description: string;
  image_url: string | null;
  fitment_verified: boolean;
  is_active: boolean;
  updated_at: string;
}

export interface Customer {
  id: string;
  shop_name: string;
  contact_person: string | null;
  phone: string;
  address: string;
  area: string;
  notes: string;
  assigned_sr_id: string | null;
  status: 'active' | 'inactive';
  advance_balance: number;
  credit_limit: number;
  price_tier: PriceTier;
  created_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name_snapshot: string;
  sku_snapshot: string;
  quantity: number;
  unit_price: number;
  line_total: number;
}

export interface Order {
  id: string;
  order_number: string;
  customer_id: string;
  sr_id: string;
  status: OrderStatus;
  status_reason: string | null;
  subtotal: number;
  discount_amount: number;
  discount_status: 'none' | 'pending_approval' | 'approved' | 'rejected';
  delivery_charge: number;
  grand_total: number;
  paid_amount: number;
  payment_status: 'unpaid' | 'partial' | 'paid';
  notes: string;
  created_at: string;
  customers?: { shop_name: string; phone: string; address: string; area: string; price_tier?: PriceTier };
  profiles?: { full_name: string; phone: string | null };
  order_items?: OrderItem[];
}

export interface Payment {
  id: string;
  receipt_number: string;
  customer_id: string;
  order_id: string | null;
  sr_id: string;
  amount: number;
  method: PaymentMethod;
  reference_no: string;
  notes: string;
  payment_date: string;
  is_reversed: boolean;
  reversal_reason: string | null;
  customers?: { shop_name: string; phone: string };
  orders?: { order_number: string };
  profiles?: { full_name: string };
}

export interface ShopVisit {
  id: string;
  sr_id: string;
  customer_id: string;
  visit_status: 'ordered' | 'shop_closed' | 'later' | 'no_need';
  notes: string;
  visited_at: string;
  customers?: { shop_name: string; area: string };
  profiles?: { full_name: string };
}

export interface ReturnClaim {
  id: string;
  claim_number: string;
  order_id: string | null;
  customer_id: string;
  sr_id: string;
  product_id: string;
  quantity: number;
  claim_type: 'damaged' | 'wrong_item' | 'other';
  reason: string;
  adjustment_amount: number;
  status: 'pending' | 'approved' | 'rejected';
  created_at: string;
  customers?: { shop_name: string };
  products?: { name: string; sku: string };
  profiles?: { full_name: string };
}

export interface Announcement {
  id: string;
  title: string;
  message: string;
  is_active: boolean;
  created_at: string;
}

export interface SrAttendance {
  id: string;
  sr_id: string;
  work_date: string;
  started_at: string;
  ended_at: string | null;
  notes: string;
  profiles?: { full_name: string };
}

export interface NotificationItem {
  id: string;
  recipient_id: string | null;
  recipient_role: UserRole;
  type: string;
  title: string;
  message: string;
  entity_type: string | null;
  entity_id: string | null;
  is_read: boolean;
  created_at: string;
}

export interface AuditLog {
  id: string;
  actor_id: string | null;
  actor_role: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  details: Record<string, unknown>;
  created_at: string;
}
