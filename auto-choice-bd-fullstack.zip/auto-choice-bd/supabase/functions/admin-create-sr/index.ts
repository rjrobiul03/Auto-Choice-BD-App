import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders, jsonResponse } from '../_shared/cors.ts';

function generateTempPassword(length = 12): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => chars[b % chars.length]).join('');
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return jsonResponse({ error: 'Missing Authorization header' }, 401);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const callerClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user: caller }, error: callerErr } = await callerClient.auth.getUser();
    if (callerErr || !caller) return jsonResponse({ error: 'Unauthorized' }, 401);

    const adminClient = createClient(supabaseUrl, serviceRoleKey);
    const { data: callerProfile } = await adminClient
      .from('profiles')
      .select('role, status')
      .eq('id', caller.id)
      .single();

    if (!callerProfile || callerProfile.role !== 'admin' || callerProfile.status !== 'active') {
      return jsonResponse({ error: 'Forbidden: Active Admin privileges required' }, 403);
    }

    const body = await req.json();
    const { full_name, email, phone, zone, monthly_sales_target, commission_rate_pct } = body;
    if (!full_name || !email) {
      return jsonResponse({ error: 'full_name and email are required' }, 400);
    }

    const tempPassword = generateTempPassword(12);

    const { data: created, error: createErr } = await adminClient.auth.admin.createUser({
      email: String(email).trim().toLowerCase(),
      password: tempPassword,
      email_confirm: true,
      user_metadata: { full_name },
      app_metadata: { role: 'sr' },
    });

    if (createErr || !created.user) {
      return jsonResponse({ error: createErr?.message || 'Failed to create auth user' }, 400);
    }

    const { error: profileErr } = await adminClient.from('profiles').insert({
      id: created.user.id,
      full_name: String(full_name).trim(),
      email: String(email).trim().toLowerCase(),
      phone: phone ? String(phone).trim() : null,
      role: 'sr',
      status: 'active',
      zone: zone ? String(zone).trim() : null,
      monthly_sales_target: Number(monthly_sales_target || 0),
      commission_rate_pct: Number(commission_rate_pct || 0),
      must_change_password: true,
    });

    if (profileErr) {
      await adminClient.auth.admin.deleteUser(created.user.id);
      return jsonResponse({ error: profileErr.message }, 400);
    }

    await adminClient.from('audit_logs').insert({
      actor_id: caller.id,
      actor_role: 'admin',
      action: 'sr_account_created',
      entity_type: 'profile',
      entity_id: created.user.id,
      details: { email: created.user.email, full_name, zone: zone || null },
    });

    return jsonResponse({
      user_id: created.user.id,
      email: created.user.email,
      temporary_password: tempPassword,
      must_change_password: true,
    });
  } catch (err) {
    return jsonResponse({ error: err instanceof Error ? err.message : 'Server error' }, 500);
  }
});
