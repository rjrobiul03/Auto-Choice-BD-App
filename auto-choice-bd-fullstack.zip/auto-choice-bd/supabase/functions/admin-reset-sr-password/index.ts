import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders, jsonResponse } from '../_shared/cors.ts';

function generateTempPassword(length = 12): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => chars[b % chars.length]).join('');
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return jsonResponse({ error: 'Missing Authorization header' }, 401);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const callerClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user: caller }, error: callerErr } = await callerClient.auth.getUser();
    if (callerErr || !caller) return jsonResponse({ error: 'Unauthorized' }, 401);

    const adminClient = createClient(supabaseUrl, serviceRoleKey);
    const { data: callerProfile } = await adminClient
      .from('profiles')
      .select('role, status')
      .eq('id', caller.id)
      .single();

    if (!callerProfile || callerProfile.role !== 'admin' || callerProfile.status !== 'active') {
      return jsonResponse({ error: 'Forbidden: Active Admin privileges required' }, 403);
    }

    const { sr_id, mode = 'temporary_password', redirect_to } = await req.json();
    if (!sr_id) return jsonResponse({ error: 'sr_id is required' }, 400);

    const { data: targetProfile, error: targetErr } = await adminClient
      .from('profiles')
      .select('id, email, full_name, role')
      .eq('id', sr_id)
      .single();

    if (targetErr || !targetProfile) {
      return jsonResponse({ error: 'SR account not found' }, 404);
    }
    if (targetProfile.role !== 'sr') {
      return jsonResponse({ error: 'This endpoint only resets SR accounts' }, 403);
    }

    if (mode === 'email_link') {
      const { error: resetErr } = await adminClient.auth.resetPasswordForEmail(targetProfile.email, {
        redirectTo: redirect_to || undefined,
      });
      if (resetErr) return jsonResponse({ error: resetErr.message }, 400);

      await adminClient.from('audit_logs').insert({
        actor_id: caller.id,
        actor_role: 'admin',
        action: 'sr_password_reset_email_sent',
        entity_type: 'profile',
        entity_id: targetProfile.id,
        details: { target_email: targetProfile.email, mode: 'email_link' },
      });

      await adminClient.from('notifications').insert({
        recipient_id: targetProfile.id,
        recipient_role: 'sr',
        type: 'security',
        title: 'Password Reset Initiated',
        message: 'An administrator sent a password reset link to your registered email.',
        entity_type: 'profile',
        entity_id: targetProfile.id,
      });

      return jsonResponse({
        success: true,
        mode: 'email_link',
        message: `Password reset link sent to ${targetProfile.email}.`,
      });
    }

    // Secure temporary password workflow (forces SR to change on next login)
    const tempPassword = generateTempPassword(12);
    const { error: updErr } = await adminClient.auth.admin.updateUserById(targetProfile.id, {
      password: tempPassword,
    });
    if (updErr) return jsonResponse({ error: updErr.message }, 400);

    await adminClient
      .from('profiles')
      .update({ must_change_password: true, updated_at: new Date().toISOString() })
      .eq('id', targetProfile.id);

    // Log metadata ONLY — NEVER store passwords or reset tokens in audit logs
    await adminClient.from('audit_logs').insert({
      actor_id: caller.id,
      actor_role: 'admin',
      action: 'sr_password_reset_temporary',
      entity_type: 'profile',
      entity_id: targetProfile.id,
      details: { target_email: targetProfile.email, mode: 'temporary_password', forced_change: true },
    });

    await adminClient.from('notifications').insert({
      recipient_id: targetProfile.id,
      recipient_role: 'sr',
      type: 'security',
      title: 'Temporary Password Issued',
      message: 'Your password was reset by Admin. You must set a new password upon login.',
      entity_type: 'profile',
      entity_id: targetProfile.id,
    });

    return jsonResponse({
      success: true,
      mode: 'temporary_password',
      temporary_password: tempPassword,
      must_change_password: true,
    });
  } catch (err) {
    return jsonResponse({ error: err instanceof Error ? err.message : 'Server error' }, 500);
  }
});
