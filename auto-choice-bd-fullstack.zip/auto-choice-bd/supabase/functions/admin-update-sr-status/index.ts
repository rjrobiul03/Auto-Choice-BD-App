import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders, jsonResponse } from '../_shared/cors.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) return jsonResponse({ error: 'Missing Authorization header' }, 401);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const anonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const callerClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user: caller }, error: callerErr } = await callerClient.auth.getUser();
    if (callerErr || !caller) return jsonResponse({ error: 'Unauthorized' }, 401);

    const adminClient = createClient(supabaseUrl, serviceRoleKey);
    const { data: callerProfile } = await adminClient
      .from('profiles')
      .select('role, status')
      .eq('id', caller.id)
      .single();

    if (!callerProfile || callerProfile.role !== 'admin' || callerProfile.status !== 'active') {
      return jsonResponse({ error: 'Forbidden' }, 403);
    }

    const { sr_id, status } = await req.json();
    if (!sr_id || !['active', 'paused', 'deactivated'].includes(status)) {
      return jsonResponse({ error: 'Invalid sr_id or status' }, 400);
    }

    const { error: updErr } = await adminClient
      .from('profiles')
      .update({ status, updated_at: new Date().toISOString() })
      .eq('id', sr_id)
      .eq('role', 'sr');

    if (updErr) return jsonResponse({ error: updErr.message }, 400);

    // Ban/unban in Supabase Auth for deactivated accounts
    await adminClient.auth.admin.updateUserById(sr_id, {
      ban_duration: status === 'deactivated' ? '876000h' : 'none',
    });

    await adminClient.from('audit_logs').insert({
      actor_id: caller.id,
      actor_role: 'admin',
      action: 'sr_status_changed',
      entity_type: 'profile',
      entity_id: sr_id,
      details: { new_status: status },
    });

    return jsonResponse({ success: true, sr_id, status });
  } catch (err) {
    return jsonResponse({ error: err instanceof Error ? err.message : 'Server error' }, 500);
  }
});
