-- Auto Choice BD — 001_schema.sql
-- PostgreSQL / Supabase relational schema
-- Strict exclusions: NO purchase cost, NO profit/loss, NO automatic stock deduction.

create extension if not exists "pgcrypto";

-- 1. Profiles (extends auth.users)
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  email text not null unique,
  phone text,
  role text not null default 'sr' check (role in ('admin', 'sr')),
  status text not null default 'active' check (status in ('active', 'paused', 'deactivated')),
  zone text,
  monthly_sales_target numeric(12, 2) not null default 0 check (monthly_sales_target >= 0),
  commission_rate_pct numeric(5, 2) not null default 0 check (commission_rate_pct >= 0 and commission_rate_pct <= 100),
  must_change_password boolean not null default false,
  can_view_stock boolean not null default true,
  can_request_discount boolean not null default true,
  language text not null default 'en' check (language in ('en', 'bn')),
  theme text not null default 'light' check (theme in ('light', 'dark')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- 2. Business Settings (singleton id = 1)
create table if not exists public.business_settings (
  id integer primary key default 1 check (id = 1),
  business_name text not null default 'Auto Choice BD',
  tagline text not null default 'Buy And Feel Like A King',
  logo_url text,
  phone text not null default '',
  whatsapp text not null default '',
  email text not null default '',
  address text not null default '',
  invoice_footer_note text not null default 'Thank you for doing business with Auto Choice BD.',
  low_stock_threshold integer not null default 8 check (low_stock_threshold >= 0),
  password_min_length integer not null default 8 check (password_min_length >= 8),
  updated_at timestamptz not null default now(),
  updated_by uuid references public.profiles(id)
);

insert into public.business_settings (id) values (1) on conflict (id) do nothing;

-- 3. Categories & Motorcycle Fitment Reference
create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  name_bn text,
  sort_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.motorcycle_brands (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.motorcycle_models (
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references public.motorcycle_brands(id) on delete cascade,
  name text not null,
  year_range text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (brand_id, name)
);

-- 4. Products (Manual Stock Only, No Purchase Cost / Profit)
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  sku text not null unique,
  barcode_qr text unique,
  brand text not null,
  category_id uuid references public.categories(id) on delete set null,
  compatible_brand text,
  compatible_model text,
  model_year_range text,
  position_application text not null default 'Other' check (
    position_application in ('Front', 'Rear', 'Engine', 'Clutch', 'Gearbox', 'Electrical', 'Body', 'Other')
  ),
  selling_price numeric(12, 2) not null check (selling_price >= 0),
  stock_quantity integer not null default 0 check (stock_quantity >= 0),
  description text default '',
  image_url text,
  fitment_verified boolean not null default false,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  updated_by uuid references public.profiles(id)
);

create index if not exists idx_products_sku on public.products (sku);
create index if not exists idx_products_barcode on public.products (barcode_qr);
create index if not exists idx_products_compat on public.products (compatible_brand, compatible_model, position_application);

create table if not exists public.product_fitments (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  motorcycle_model_id uuid not null references public.motorcycle_models(id) on delete cascade,
  position_application text not null default 'Other' check (
    position_application in ('Front', 'Rear', 'Engine', 'Clutch', 'Gearbox', 'Electrical', 'Body', 'Other')
  ),
  notes text,
  is_verified boolean not null default false,
  created_at timestamptz not null default now(),
  unique (product_id, motorcycle_model_id, position_application)
);

create table if not exists public.price_history (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  old_price numeric(12, 2) not null,
  new_price numeric(12, 2) not null,
  reason text,
  changed_by uuid references public.profiles(id),
  changed_at timestamptz not null default now()
);

-- 5. Customers & Assignments
create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  shop_name text not null,
  contact_person text,
  phone text not null unique,
  address text not null default '',
  area text default '',
  notes text default '',
  assigned_sr_id uuid references public.profiles(id) on delete set null,
  status text not null default 'active' check (status in ('active', 'inactive')),
  advance_balance numeric(12, 2) not null default 0 check (advance_balance >= 0),
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.customer_assignments (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id) on delete cascade,
  sr_id uuid not null references public.profiles(id) on delete cascade,
  assigned_by uuid references public.profiles(id),
  assigned_at timestamptz not null default now(),
  unique (customer_id, sr_id)
);

create table if not exists public.customer_prices (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.customers(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  custom_price numeric(12, 2) check (custom_price >= 0),
  discount_pct numeric(5, 2) check (discount_pct >= 0 and discount_pct <= 100),
  is_active boolean not null default true,
  approved_by uuid references public.profiles(id),
  updated_at timestamptz not null default now(),
  unique (customer_id, product_id)
);

-- 6. Orders & Order Items (Server-generated Order Number, Price Snapshot, NO Stock Deduction)
create sequence if not exists public.order_number_seq start 1001;
create sequence if not exists public.receipt_number_seq start 1001;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  customer_id uuid not null references public.customers(id),
  sr_id uuid not null references public.profiles(id),
  status text not null default 'pending_review' check (
    status in ('pending_review', 'approved', 'processing', 'ready_shipped', 'delivered', 'rejected', 'cancelled')
  ),
  status_reason text,
  subtotal numeric(12, 2) not null default 0 check (subtotal >= 0),
  discount_amount numeric(12, 2) not null default 0 check (discount_amount >= 0),
  discount_status text not null default 'none' check (
    discount_status in ('none', 'pending_approval', 'approved', 'rejected')
  ),
  delivery_charge numeric(12, 2) not null default 0 check (delivery_charge >= 0),
  grand_total numeric(12, 2) not null default 0 check (grand_total >= 0),
  paid_amount numeric(12, 2) not null default 0 check (paid_amount >= 0),
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid', 'partial', 'paid')),
  notes text default '',
  idempotency_key text unique,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_orders_sr on public.orders (sr_id, created_at desc);
create index if not exists idx_orders_customer on public.orders (customer_id, created_at desc);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid not null references public.products(id),
  product_name_snapshot text not null,
  sku_snapshot text not null,
  quantity integer not null check (quantity > 0),
  unit_price numeric(12, 2) not null check (unit_price >= 0),
  line_total numeric(12, 2) not null check (line_total >= 0)
);

create table if not exists public.order_status_history (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  old_status text,
  new_status text not null,
  reason text,
  changed_by uuid references public.profiles(id),
  changed_at timestamptz not null default now()
);

-- 7. Payments (Audit-preserving, Reversal instead of Delete)
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  receipt_number text not null unique,
  customer_id uuid not null references public.customers(id),
  order_id uuid references public.orders(id) on delete set null,
  sr_id uuid not null references public.profiles(id),
  amount numeric(12, 2) not null check (amount > 0),
  method text not null check (method in ('cash', 'bank_transfer', 'mfs')),
  reference_no text default '',
  notes text default '',
  payment_date timestamptz not null default now(),
  is_reversed boolean not null default false,
  reversed_at timestamptz,
  reversed_by uuid references public.profiles(id),
  reversal_reason text,
  idempotency_key text unique,
  entered_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create index if not exists idx_payments_customer on public.payments (customer_id, payment_date desc);

-- 8. Notifications & Audit Logs
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid references public.profiles(id) on delete cascade,
  recipient_role text not null check (recipient_role in ('admin', 'sr')),
  type text not null,
  title text not null,
  message text not null,
  entity_type text,
  entity_id text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references public.profiles(id) on delete set null,
  actor_role text,
  action text not null,
  entity_type text not null,
  entity_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_audit_logs_created on public.audit_logs (created_at desc);

-- Seed starter reference data (brands & categories)
insert into public.motorcycle_brands (name) values
  ('Honda'), ('Yamaha'), ('Bajaj'), ('TVS'), ('Hero'), ('Suzuki'), ('China'), ('Universal')
on conflict (name) do nothing;

insert into public.categories (name, name_bn, sort_order) values
  ('Spare Parts', 'স্পেয়ার পার্টস', 1),
  ('Engine Oil', 'ইঞ্জিন অয়েল', 2),
  ('Bearings', 'বেয়ারিং', 3),
  ('Helmets', 'হেলমেট', 4),
  ('Riding Gear', 'রাইডিং গিয়ার', 5),
  ('Accessories', 'এক্সেসরিজ', 6)
on conflict (name) do nothing;
