-- Auto Choice BD — 002_rls_policies.sql
-- Row Level Security policies enforcing trusted server-side roles

-- Helper functions evaluated on the database server
create or replace function public.is_active_user()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and status = 'active'
  );
$$;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and role = 'admin' and status = 'active'
  );
$$;

create or replace function public.is_customer_assigned_to_me(p_customer_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.customers c
    where c.id = p_customer_id and c.assigned_sr_id = auth.uid()
  ) or exists (
    select 1 from public.customer_assignments ca
    where ca.customer_id = p_customer_id and ca.sr_id = auth.uid()
  );
$$;

-- Enable RLS on all tables
alter table public.profiles enable row level security;
alter table public.business_settings enable row level security;
alter table public.categories enable row level security;
alter table public.motorcycle_brands enable row level security;
alter table public.motorcycle_models enable row level security;
alter table public.products enable row level security;
alter table public.product_fitments enable row level security;
alter table public.price_history enable row level security;
alter table public.customers enable row level security;
alter table public.customer_assignments enable row level security;
alter table public.customer_prices enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.order_status_history enable row level security;
alter table public.payments enable row level security;
alter table public.notifications enable row level security;
alter table public.audit_logs enable row level security;

-- PROFILES
create policy "Users can view own profile" on public.profiles
  for select using (id = auth.uid() or public.is_admin());

create policy "Users can update own safe preferences" on public.profiles
  for update using (id = auth.uid() and public.is_active_user())
  with check (
    id = auth.uid()
    and role = (select role from public.profiles where id = auth.uid())
    and status = (select status from public.profiles where id = auth.uid())
  );

create policy "Admins manage all profiles" on public.profiles
  for all using (public.is_admin()) with check (public.is_admin());

-- BUSINESS SETTINGS
create policy "Active users read business settings" on public.business_settings
  for select using (public.is_active_user());

create policy "Admins update business settings" on public.business_settings
  for all using (public.is_admin()) with check (public.is_admin());

-- CATEGORIES & MOTORCYCLE REFERENCE
create policy "Active users read categories" on public.categories
  for select using (public.is_active_user());
create policy "Admins manage categories" on public.categories
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Active users read motorcycle_brands" on public.motorcycle_brands
  for select using (public.is_active_user());
create policy "Admins manage motorcycle_brands" on public.motorcycle_brands
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Active users read motorcycle_models" on public.motorcycle_models
  for select using (public.is_active_user());
create policy "Admins manage motorcycle_models" on public.motorcycle_models
  for all using (public.is_admin()) with check (public.is_admin());

-- PRODUCTS & FITMENTS & PRICE HISTORY
create policy "Active users read products" on public.products
  for select using (public.is_active_user() and (is_active = true or public.is_admin()));
create policy "Admins manage products" on public.products
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Active users read product_fitments" on public.product_fitments
  for select using (public.is_active_user());
create policy "Admins manage product_fitments" on public.product_fitments
  for all using (public.is_admin()) with check (public.is_admin());

create policy "Admins read price_history" on public.price_history
  for select using (public.is_admin());
create policy "Admins insert price_history" on public.price_history
  for insert with check (public.is_admin());

-- CUSTOMERS & ASSIGNMENTS & CUSTOMER PRICES
create policy "Admins manage customers" on public.customers
  for all using (public.is_admin()) with check (public.is_admin());

create policy "SRs read assigned customers" on public.customers
  for select using (public.is_active_user() and public.is_customer_assigned_to_me(id));

create policy "Admins manage customer_assignments" on public.customer_assignments
  for all using (public.is_admin()) with check (public.is_admin());

create policy "SRs read own assignments" on public.customer_assignments
  for select using (sr_id = auth.uid() and public.is_active_user());

create policy "Admins manage customer_prices" on public.customer_prices
  for all using (public.is_admin()) with check (public.is_admin());

create policy "SRs read customer_prices for assigned customers" on public.customer_prices
  for select using (public.is_active_user() and public.is_customer_assigned_to_me(customer_id));

-- ORDERS, ITEMS & STATUS HISTORY
create policy "Admins manage all orders" on public.orders
  for all using (public.is_admin()) with check (public.is_admin());

create policy "SRs read own orders" on public.orders
  for select using (public.is_active_user() and sr_id = auth.uid());

create policy "SRs insert own orders for assigned customers" on public.orders
  for insert with check (
    public.is_active_user()
    and sr_id = auth.uid()
    and created_by = auth.uid()
    and public.is_customer_assigned_to_me(customer_id)
  );

create policy "Admins manage all order_items" on public.order_items
  for all using (public.is_admin()) with check (public.is_admin());

create policy "SRs read own order_items" on public.order_items
  for select using (
    public.is_active_user()
    and exists (select 1 from public.orders o where o.id = order_id and o.sr_id = auth.uid())
  );

create policy "SRs insert own order_items" on public.order_items
  for insert with check (
    public.is_active_user()
    and exists (select 1 from public.orders o where o.id = order_id and o.sr_id = auth.uid())
  );

create policy "Admins manage order_status_history" on public.order_status_history
  for all using (public.is_admin()) with check (public.is_admin());

create policy "SRs read own order_status_history" on public.order_status_history
  for select using (
    public.is_active_user()
    and exists (select 1 from public.orders o where o.id = order_id and o.sr_id = auth.uid())
  );

-- PAYMENTS
create policy "Admins manage all payments" on public.payments
  for all using (public.is_admin()) with check (public.is_admin());

create policy "SRs read own payments" on public.payments
  for select using (public.is_active_user() and sr_id = auth.uid());

create policy "SRs record payments for assigned customers" on public.payments
  for insert with check (
    public.is_active_user()
    and sr_id = auth.uid()
    and entered_by = auth.uid()
    and public.is_customer_assigned_to_me(customer_id)
  );

-- NOTIFICATIONS
create policy "Users read own notifications" on public.notifications
  for select using (
    public.is_active_user()
    and (
      recipient_id = auth.uid()
      or (recipient_id is null and recipient_role = 'admin' and public.is_admin())
    )
  );

create policy "Users mark own notifications read" on public.notifications
  for update using (
    public.is_active_user()
    and (
      recipient_id = auth.uid()
      or (recipient_id is null and recipient_role = 'admin' and public.is_admin())
    )
  );

create policy "Active users create notifications" on public.notifications
  for insert with check (public.is_active_user());

-- AUDIT LOGS (Admin-only read; authenticated insert via RPC/triggers)
create policy "Admins read audit_logs" on public.audit_logs
  for select using (public.is_admin());

create policy "Active users insert own audit_logs" on public.audit_logs
  for insert with check (public.is_active_user() and actor_id = auth.uid());
