-- Auto Choice BD — 003_functions_triggers.sql
-- Server-side order/receipt number generation, price history, payment reconciliation, and audit logging.
-- NOTE: Stock is NEVER automatically deducted or modified by orders.

-- 1. Server-generated Order Number
create or replace function public.generate_order_number()
returns trigger
language plpgsql
as $$
begin
  if new.order_number is null or new.order_number = '' then
    new.order_number := 'ORD-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('public.order_number_seq')::text, 4, '0');
  end if;
  return new;
end;
$$;

drop trigger if exists trg_orders_number on public.orders;
create trigger trg_orders_number
  before insert on public.orders
  for each row execute function public.generate_order_number();

-- 2. Server-generated Payment Receipt Number
create or replace function public.generate_receipt_number()
returns trigger
language plpgsql
as $$
begin
  if new.receipt_number is null or new.receipt_number = '' then
    new.receipt_number := 'RCP-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('public.receipt_number_seq')::text, 4, '0');
  end if;
  return new;
end;
$$;

drop trigger if exists trg_payments_receipt on public.payments;
create trigger trg_payments_receipt
  before insert on public.payments
  for each row execute function public.generate_receipt_number();

-- 3. Automatic Price History & Stock Edit Audit Log
create or replace function public.log_product_changes()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if new.selling_price is distinct from old.selling_price then
    insert into public.price_history (product_id, old_price, new_price, changed_by)
    values (new.id, old.selling_price, new.selling_price, auth.uid());

    insert into public.audit_logs (actor_id, action, entity_type, entity_id, details)
    values (
      auth.uid(),
      'product_price_updated',
      'product',
      new.id::text,
      jsonb_build_object('sku', new.sku, 'old_price', old.selling_price, 'new_price', new.selling_price)
    );
  end if;

  if new.stock_quantity is distinct from old.stock_quantity then
    insert into public.audit_logs (actor_id, action, entity_type, entity_id, details)
    values (
      auth.uid(),
      'manual_stock_updated',
      'product',
      new.id::text,
      jsonb_build_object('sku', new.sku, 'old_stock', old.stock_quantity, 'new_stock', new.stock_quantity)
    );
  end if;

  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists trg_products_audit on public.products;
create trigger trg_products_audit
  before update on public.products
  for each row execute function public.log_product_changes();

-- 4. Recompute Order Paid Amount & Payment Status from Non-Reversed Payments
create or replace function public.sync_order_payment_status()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  v_order_id uuid;
  v_paid numeric(12, 2);
  v_total numeric(12, 2);
  v_status text;
begin
  v_order_id := coalesce(new.order_id, old.order_id);
  if v_order_id is null then
    return null;
  end if;

  select coalesce(sum(amount), 0) into v_paid
  from public.payments
  where order_id = v_order_id and is_reversed = false;

  select grand_total into v_total
  from public.orders
  where id = v_order_id;

  if v_paid <= 0 then
    v_status := 'unpaid';
  elsif v_paid < v_total then
    v_status := 'partial';
  else
    v_status := 'paid';
  end if;

  update public.orders
  set paid_amount = v_paid,
      payment_status = v_status,
      updated_at = now()
  where id = v_order_id;

  return null;
end;
$$;

drop trigger if exists trg_payments_sync_order on public.payments;
create trigger trg_payments_sync_order
  after insert or update on public.payments
  for each row execute function public.sync_order_payment_status();

-- 5. Log Order Status Transitions & Notify
create or replace function public.log_order_status_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if tg_op = 'INSERT' then
    insert into public.order_status_history (order_id, old_status, new_status, reason, changed_by)
    values (new.id, null, new.status, new.status_reason, auth.uid());

    insert into public.notifications (recipient_id, recipient_role, type, title, message, entity_type, entity_id)
    values (
      null,
      'admin',
      'new_order',
      'New Order Submitted',
      'Order ' || new.order_number || ' is awaiting review.',
      'order',
      new.id::text
    );
  elsif new.status is distinct from old.status then
    insert into public.order_status_history (order_id, old_status, new_status, reason, changed_by)
    values (new.id, old.status, new.status, new.status_reason, auth.uid());

    insert into public.notifications (recipient_id, recipient_role, type, title, message, entity_type, entity_id)
    values (
      new.sr_id,
      'sr',
      'order_status',
      'Order Status Updated',
      'Order ' || new.order_number || ' is now ' || replace(new.status, '_', ' ') || '.',
      'order',
      new.id::text
    );
  end if;
  return new;
end;
$$;

drop trigger if exists trg_orders_status_history on public.orders;
create trigger trg_orders_status_history
  after insert or update on public.orders
  for each row execute function public.log_order_status_change();

-- 6. RPC: Atomic Order Creation (Server Validates Prices, Never Touches Stock)
create or replace function public.submit_order_secure(
  p_customer_id uuid,
  p_items jsonb,
  p_discount_amount numeric default 0,
  p_delivery_charge numeric default 0,
  p_notes text default '',
  p_idempotency_key text default null
)
returns public.orders
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_profile public.profiles;
  v_existing public.orders;
  v_order public.orders;
  v_item jsonb;
  v_product public.products;
  v_qty integer;
  v_unit_price numeric(12, 2);
  v_subtotal numeric(12, 2) := 0;
  v_discount numeric(12, 2) := greatest(0, coalesce(p_discount_amount, 0));
  v_delivery numeric(12, 2) := greatest(0, coalesce(p_delivery_charge, 0));
  v_discount_status text := 'none';
begin
  select * into v_profile from public.profiles where id = v_user_id and status = 'active';
  if not found then
    raise exception 'Unauthorized or inactive account';
  end if;

  if v_profile.role = 'sr' and not public.is_customer_assigned_to_me(p_customer_id) then
    raise exception 'Customer is not assigned to this SR';
  end if;

  if p_idempotency_key is not null then
    select * into v_existing from public.orders where idempotency_key = p_idempotency_key;
    if found then
      return v_existing;
    end if;
  end if;

  if jsonb_array_length(p_items) = 0 then
    raise exception 'Order must contain at least one item';
  end if;

  if v_discount > 0 then
    if v_profile.role = 'admin' then
      v_discount_status := 'approved';
    elsif v_profile.can_request_discount then
      v_discount_status := 'pending_approval';
    else
      raise exception 'Discount requests are not permitted for this account';
    end if;
  end if;

  insert into public.orders (
    order_number, customer_id, sr_id, status, subtotal, discount_amount,
    discount_status, delivery_charge, grand_total, notes, idempotency_key, created_by
  ) values (
    '', p_customer_id, v_user_id, 'pending_review', 0, v_discount,
    v_discount_status, v_delivery, 0, coalesce(p_notes, ''), p_idempotency_key, v_user_id
  )
  returning * into v_order;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::integer;
    if v_qty <= 0 then
      raise exception 'Invalid item quantity';
    end if;

    select * into v_product from public.products
    where id = (v_item->>'product_id')::uuid and is_active = true;
    if not found then
      raise exception 'Product not found or inactive';
    end if;

    -- Check customer-specific price if active
    select coalesce(
      cp.custom_price,
      round(v_product.selling_price * (1 - coalesce(cp.discount_pct, 0) / 100.0), 2)
    )
    into v_unit_price
    from public.customer_prices cp
    where cp.customer_id = p_customer_id
      and cp.product_id = v_product.id
      and cp.is_active = true
    limit 1;

    if v_unit_price is null then
      v_unit_price := v_product.selling_price;
    end if;

    insert into public.order_items (
      order_id, product_id, product_name_snapshot, sku_snapshot,
      quantity, unit_price, line_total
    ) values (
      v_order.id, v_product.id, v_product.name, v_product.sku,
      v_qty, v_unit_price, round(v_unit_price * v_qty, 2)
    );

    v_subtotal := v_subtotal + round(v_unit_price * v_qty, 2);
  end loop;

  update public.orders
  set subtotal = v_subtotal,
      grand_total = greatest(0, v_subtotal - v_discount + v_delivery),
      updated_at = now()
  where id = v_order.id
  returning * into v_order;

  insert into public.audit_logs (actor_id, actor_role, action, entity_type, entity_id, details)
  values (
    v_user_id, v_profile.role, 'order_submitted', 'order', v_order.id::text,
    jsonb_build_object('order_number', v_order.order_number, 'grand_total', v_order.grand_total)
  );

  return v_order;
end;
$$;
