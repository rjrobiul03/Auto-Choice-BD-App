-- Auto Choice BD — 004_extended_features.sql
-- Adds: Credit Limit, Price Tiers, Shop Visits, Returns/Claims (no auto-stock!), Announcements, SR Attendance

-- 1. Customer Credit Limit & Price Tier
alter table public.customers
  add column if not exists credit_limit numeric(12, 2) not null default 0 check (credit_limit >= 0),
  add column if not exists price_tier text not null default 'retail' check (price_tier in ('retail', 'workshop', 'dealer'));

-- 2. Product Tier Prices (Optional; falls back to selling_price)
alter table public.products
  add column if not exists dealer_price numeric(12, 2) check (dealer_price is null or dealer_price >= 0),
  add column if not exists workshop_price numeric(12, 2) check (workshop_price is null or workshop_price >= 0);

-- 3. SR Shop Visits & Daily Route Check-In
create table if not exists public.shop_visits (
  id uuid primary key default gen_random_uuid(),
  sr_id uuid not null references public.profiles(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete cascade,
  visit_status text not null check (visit_status in ('ordered', 'shop_closed', 'later', 'no_need')),
  notes text default '',
  visited_at timestamptz not null default now()
);

alter table public.shop_visits enable row level security;

create policy "Admins read all shop_visits" on public.shop_visits
  for select using (public.is_admin());

create policy "SRs manage own shop_visits" on public.shop_visits
  for all using (public.is_active_user() and sr_id = auth.uid())
  with check (public.is_active_user() and sr_id = auth.uid() and public.is_customer_assigned_to_me(customer_id));

-- 4. Return & Damage Claims (Manual Stock Only — NEVER auto-adjusts stock_quantity)
create table if not exists public.return_claims (
  id uuid primary key default gen_random_uuid(),
  claim_number text not null unique,
  order_id uuid references public.orders(id) on delete set null,
  customer_id uuid not null references public.customers(id) on delete cascade,
  sr_id uuid not null references public.profiles(id),
  product_id uuid not null references public.products(id),
  quantity integer not null check (quantity > 0),
  claim_type text not null default 'damaged' check (claim_type in ('damaged', 'wrong_item', 'other')),
  reason text not null,
  adjustment_amount numeric(12, 2) not null default 0 check (adjustment_amount >= 0),
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create sequence if not exists public.claim_number_seq start 1001;

create or replace function public.generate_claim_number()
returns trigger language plpgsql as $$
begin
  if new.claim_number is null or new.claim_number = '' then
    new.claim_number := 'CLM-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('public.claim_number_seq')::text, 4, '0');
  end if;
  return new;
end;
$$;

drop trigger if exists trg_claim_number on public.return_claims;
create trigger trg_claim_number
  before insert on public.return_claims
  for each row execute function public.generate_claim_number();

alter table public.return_claims enable row level security;

create policy "Admins manage all return_claims" on public.return_claims
  for all using (public.is_admin()) with check (public.is_admin());

create policy "SRs read own return_claims" on public.return_claims
  for select using (public.is_active_user() and sr_id = auth.uid());

create policy "SRs submit own return_claims" on public.return_claims
  for insert with check (
    public.is_active_user()
    and sr_id = auth.uid()
    and public.is_customer_assigned_to_me(customer_id)
  );

-- 5. Admin Broadcast Announcements / Offer Banners
create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  message text not null,
  is_active boolean not null default true,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

alter table public.announcements enable row level security;

create policy "Active users read active announcements" on public.announcements
  for select using (public.is_active_user() and (is_active = true or public.is_admin()));

create policy "Admins manage announcements" on public.announcements
  for all using (public.is_admin()) with check (public.is_admin());

-- 6. SR Daily Start & End Shift Attendance
create table if not exists public.sr_attendance (
  id uuid primary key default gen_random_uuid(),
  sr_id uuid not null references public.profiles(id) on delete cascade,
  work_date date not null default current_date,
  started_at timestamptz not null default now(),
  ended_at timestamptz,
  notes text default '',
  unique (sr_id, work_date)
);

alter table public.sr_attendance enable row level security;

create policy "Admins read all sr_attendance" on public.sr_attendance
  for select using (public.is_admin());

create policy "SRs manage own sr_attendance" on public.sr_attendance
  for all using (public.is_active_user() and sr_id = auth.uid())
  with check (public.is_active_user() and sr_id = auth.uid());

-- 7. Update submit_order_secure to respect Customer Price Tier (Dealer/Workshop/Retail)
create or replace function public.submit_order_secure(
  p_customer_id uuid,
  p_items jsonb,
  p_discount_amount numeric default 0,
  p_delivery_charge numeric default 0,
  p_notes text default '',
  p_idempotency_key text default null
)
returns public.orders
language plpgsql
security definer
set search_path = public
as $$
declare
  v_user_id uuid := auth.uid();
  v_profile public.profiles;
  v_customer public.customers;
  v_existing public.orders;
  v_order public.orders;
  v_item jsonb;
  v_product public.products;
  v_qty integer;
  v_unit_price numeric(12, 2);
  v_subtotal numeric(12, 2) := 0;
  v_discount numeric(12, 2) := greatest(0, coalesce(p_discount_amount, 0));
  v_delivery numeric(12, 2) := greatest(0, coalesce(p_delivery_charge, 0));
  v_discount_status text := 'none';
begin
  select * into v_profile from public.profiles where id = v_user_id and status = 'active';
  if not found then
    raise exception 'Unauthorized or inactive account';
  end if;

  select * into v_customer from public.customers where id = p_customer_id;
  if not found then
    raise exception 'Customer not found';
  end if;

  if v_profile.role = 'sr' and not public.is_customer_assigned_to_me(p_customer_id) then
    raise exception 'Customer is not assigned to this SR';
  end if;

  if p_idempotency_key is not null then
    select * into v_existing from public.orders where idempotency_key = p_idempotency_key;
    if found then
      return v_existing;
    end if;
  end if;

  if jsonb_array_length(p_items) = 0 then
    raise exception 'Order must contain at least one item';
  end if;

  if v_discount > 0 then
    if v_profile.role = 'admin' then
      v_discount_status := 'approved';
    elsif v_profile.can_request_discount then
      v_discount_status := 'pending_approval';
    else
      raise exception 'Discount requests are not permitted for this account';
    end if;
  end if;

  insert into public.orders (
    order_number, customer_id, sr_id, status, subtotal, discount_amount,
    discount_status, delivery_charge, grand_total, notes, idempotency_key, created_by
  ) values (
    '', p_customer_id, v_user_id, 'pending_review', 0, v_discount,
    v_discount_status, v_delivery, 0, coalesce(p_notes, ''), p_idempotency_key, v_user_id
  )
  returning * into v_order;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::integer;
    if v_qty <= 0 then
      raise exception 'Invalid item quantity';
    end if;

    select * into v_product from public.products
    where id = (v_item->>'product_id')::uuid and is_active = true;
    if not found then
      raise exception 'Product not found or inactive';
    end if;

    -- 1. Check customer-specific price override
    select coalesce(
      cp.custom_price,
      round(v_product.selling_price * (1 - coalesce(cp.discount_pct, 0) / 100.0), 2)
    )
    into v_unit_price
    from public.customer_prices cp
    where cp.customer_id = p_customer_id
      and cp.product_id = v_product.id
      and cp.is_active = true
    limit 1;

    -- 2. Otherwise use customer price_tier (dealer / workshop / retail)
    if v_unit_price is null then
      if v_customer.price_tier = 'dealer' and v_product.dealer_price is not null then
        v_unit_price := v_product.dealer_price;
      elsif v_customer.price_tier = 'workshop' and v_product.workshop_price is not null then
        v_unit_price := v_product.workshop_price;
      else
        v_unit_price := v_product.selling_price;
      end if;
    end if;

    insert into public.order_items (
      order_id, product_id, product_name_snapshot, sku_snapshot,
      quantity, unit_price, line_total
    ) values (
      v_order.id, v_product.id, v_product.name, v_product.sku,
      v_qty, v_unit_price, round(v_unit_price * v_qty, 2)
    );

    v_subtotal := v_subtotal + round(v_unit_price * v_qty, 2);
  end loop;

  update public.orders
  set subtotal = v_subtotal,
      grand_total = greatest(0, v_subtotal - v_discount + v_delivery),
      updated_at = now()
  where id = v_order.id
  returning * into v_order;

  insert into public.audit_logs (actor_id, actor_role, action, entity_type, entity_id, details)
  values (
    v_user_id, v_profile.role, 'order_submitted', 'order', v_order.id::text,
    jsonb_build_object('order_number', v_order.order_number, 'grand_total', v_order.grand_total)
  );

  return v_order;
end;
$$;
